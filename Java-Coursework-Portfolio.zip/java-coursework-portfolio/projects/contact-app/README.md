# Early Contact App

Earlier Swing contact application with registration, sign-in, and contact storage in SQLite.

**Context:** Java coursework and guided learning. Original folder: `JavaTerm3`.

## What the code demonstrates

Login flow, SQL filtering, and lessons in access control. The original implementation and learning comments are retained; the portfolio packaging is documented in [provenance](../../docs/PROVENANCE.md).

## Run

From the repository root, with Python 3 and a JDK installed:

```sh
python3 tools/portfolio.py build contact-app
python3 tools/portfolio.py run contact-app
```

Windows users can use `py` instead of `python3`. 

Database examples also require the SQLite JDBC runtime described in [setup](../../docs/RUNNING.md). Run each collection separately: several use the same class names.

## Known limitations

Passwords are stored in plaintext. Search, update, and delete queries do not consistently restrict records to the signed-in user. Use only disposable demo data.

## Learning notes

The useful code-reading focus here is login flow, sql filtering, and lessons in access control. This README describes the submitted implementation; it does not claim every component was written independently. Personal reflections can be added after reviewing the source.

See [validation](../../docs/VALIDATION.md) for the exact scope of checks.

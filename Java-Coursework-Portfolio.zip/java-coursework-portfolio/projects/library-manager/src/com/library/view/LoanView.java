package com.library.view;

import com.library.model.Loan;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Window;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class LoanView extends JPanel {

    private final DefaultTableModel tableModel =
            new DefaultTableModel(new Object[]{
                    "ID", "Book", "Member", "Issued", "Due", "Returned", "Fine", "Status"}, 0) {
                @Override public boolean isCellEditable(int r, int c) { return false; }
            };
    private final JTable table = new JTable(tableModel);

    private final JButton issueBtn = new JButton("Issue Book");
    private final JButton returnBtn = new JButton("Return Book");
    private final JButton allBtn = new JButton("Show All Active");
    private final JButton overdueBtn = new JButton("Show Overdue");

    public LoanView() {
        setLayout(new BorderLayout(8, 8));
        setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT));
        bar.add(issueBtn);
        bar.add(returnBtn);
        bar.add(allBtn);
        bar.add(overdueBtn);
        add(bar, BorderLayout.NORTH);

        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        add(new JScrollPane(table), BorderLayout.CENTER);
    }

    // ---- controller wiring ----

    public void setOnIssue(Runnable r)         { issueBtn.addActionListener(e -> r.run()); }
    public void setOnReturn(Runnable r)        { returnBtn.addActionListener(e -> r.run()); }
    public void setOnShowAllActive(Runnable r) { allBtn.addActionListener(e -> r.run()); }
    public void setOnShowOverdue(Runnable r)   { overdueBtn.addActionListener(e -> r.run()); }

    // ---- state the controller pushes back in ----

    public void populate(List<LoanRow> rows) {
        tableModel.setRowCount(0);
        for (LoanRow r : rows) {
            tableModel.addRow(new Object[]{ r.id, r.book, r.member, r.issued, r.due, r.returned, r.fine, r.status });
        }
    }

    // ---- Issue Book dialog ----

    public Optional<IssueRequest> showIssueDialog(IntLookup memberLookup, IntLookup bookLookup) {
        JTextField memberIdField = new JTextField(6);
        JLabel memberInfoLabel = new JLabel(" ");
        JTextField bookIdField = new JTextField(6);
        JLabel bookInfoLabel = new JLabel(" ");

        wireLiveLookup(memberIdField, memberInfoLabel, memberLookup);
        wireLiveLookup(bookIdField, bookInfoLabel, bookLookup);

        JPanel form = new JPanel(new GridLayout(4, 2, 6, 6));
        form.add(new JLabel("Member ID:")); form.add(memberIdField);
        form.add(new JLabel(""));           form.add(memberInfoLabel);
        form.add(new JLabel("Book ID:"));   form.add(bookIdField);
        form.add(new JLabel(""));           form.add(bookInfoLabel);

        int result = JOptionPane.showConfirmDialog(this, form, "Issue Book",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result != JOptionPane.OK_OPTION) return Optional.empty();

        Integer memberId = parseId(memberIdField.getText());
        if (memberId == null) { showWarning("Enter a valid numeric member ID."); return Optional.empty(); }
        Integer bookId = parseId(bookIdField.getText());
        if (bookId == null) { showWarning("Enter a valid numeric book ID."); return Optional.empty(); }

        return Optional.of(new IssueRequest(memberId, bookId));
    }

    // ---- Return Book dialog ----

    public Optional<Integer> showReturnDialog(IntLookup memberLookup, MemberLoansLookup loansLookup) {
        JTextField memberIdField = new JTextField(6);
        JLabel memberInfoLabel = new JLabel(" ");
        JComboBox<Loan> loanBox = new JComboBox<>();

        AtomicInteger seq = new AtomicInteger();
        memberIdField.getDocument().addDocumentListener(onChange(() -> {
            int ticket = seq.incrementAndGet();
            loanBox.removeAllItems();
            Integer id = parseId(memberIdField.getText());
            if (id == null) { memberInfoLabel.setText(" "); return; }
            runAsync(seq, ticket, () -> loansLookup.lookup(id), result -> {
                memberInfoLabel.setText(result.labelText);
                for (Loan l : result.loans) loanBox.addItem(l);
                repackDialogFor(memberInfoLabel);
            });
        }));

        JPanel form = new JPanel(new GridLayout(3, 2, 6, 6));
        form.add(new JLabel("Member ID:")); form.add(memberIdField);
        form.add(new JLabel(""));           form.add(memberInfoLabel);
        form.add(new JLabel("Loan:"));      form.add(loanBox);

        int result = JOptionPane.showConfirmDialog(this, form, "Return Book",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result != JOptionPane.OK_OPTION) return Optional.empty();

        Loan loan = (Loan) loanBox.getSelectedItem();
        if (loan == null) { showWarning("Select a loan to return."); return Optional.empty(); }
        return Optional.of(loan.getId());
    }

    // ---- shared dialog plumbing ----

    private void wireLiveLookup(JTextField idField, JLabel infoLabel, IntLookup lookup) {
        AtomicInteger seq = new AtomicInteger();
        idField.getDocument().addDocumentListener(onChange(() -> {
            int ticket = seq.incrementAndGet();
            Integer id = parseId(idField.getText());
            if (id == null) { infoLabel.setText(" "); return; }
            runAsync(seq, ticket, () -> lookup.describe(id), text -> {
                infoLabel.setText(text);
                repackDialogFor(infoLabel);
            });
        }));
    }

    private static Integer parseId(String text) {
        try {
            return Integer.parseInt(text.trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /**
     * Runs {@code work} on a background thread so DB access never blocks the EDT
     * (a synchronous JDBC call inside a DocumentListener freezes the whole UI while
     * typing). {@code apply} runs back on the EDT, and is skipped if a newer
     * keystroke has already superseded this request.
     */
    private <T> void runAsync(AtomicInteger seq, int ticket, Supplier<T> work, Consumer<T> apply) {
        new SwingWorker<T, Void>() {
            @Override protected T doInBackground() { return work.get(); }
            @Override protected void done() {
                if (seq.get() != ticket) return;
                try { apply.accept(get()); } catch (Exception ignored) { }
            }
        }.execute();
    }

    /**
     * Re-fits the enclosing dialog to its content. JOptionPane sizes its dialog once,
     * when first shown; if a label or combo box grows afterward (e.g. a longer member
     * name/status appearing), the layout can end up wider than the dialog, pushing
     * fields past the visible window edge instead of resizing it.
     */
    private static void repackDialogFor(Component inDialog) {
        Window window = SwingUtilities.getWindowAncestor(inDialog);
        if (window != null) window.pack();
    }

    /** Runs the given action on every document edit (insert, remove, or attribute change). */
    private static DocumentListener onChange(Runnable action) {
        return new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { action.run(); }
            @Override public void removeUpdate(DocumentEvent e) { action.run(); }
            @Override public void changedUpdate(DocumentEvent e) { action.run(); }
        };
    }

    public void showInfo(String m)    { JOptionPane.showMessageDialog(this, m, "Success", JOptionPane.INFORMATION_MESSAGE); }
    public void showWarning(String m) { JOptionPane.showMessageDialog(this, m, "Notice", JOptionPane.WARNING_MESSAGE); }
    public void showError(String m)   { JOptionPane.showMessageDialog(this, m, "Error", JOptionPane.ERROR_MESSAGE); }

    // ---- callback interfaces the controller implements ----

    /** Synchronous lookup (run off the EDT by this view) turning an id into display text. */
    public interface IntLookup {
        String describe(int id);
    }

    /** Synchronous lookup of a member's info plus their active loans. */
    public interface MemberLoansLookup {
        LoanLookupResult lookup(int memberId);
    }

    // ---- small data carriers passed across the View/Controller boundary ----

    public static final class LoanLookupResult {
        public final String labelText;
        public final List<Loan> loans;
        public LoanLookupResult(String labelText, List<Loan> loans) {
            this.labelText = labelText;
            this.loans = loans;
        }
    }

    public static final class IssueRequest {
        public final int memberId;
        public final int bookId;
        public IssueRequest(int memberId, int bookId) {
            this.memberId = memberId;
            this.bookId = bookId;
        }
    }

    public static final class LoanRow {
        final int id;
        final String book, member, issued, due, returned, fine, status;
        public LoanRow(int id, String book, String member, String issued, String due,
                       String returned, String fine, String status) {
            this.id = id;
            this.book = book;
            this.member = member;
            this.issued = issued;
            this.due = due;
            this.returned = returned;
            this.fine = fine;
            this.status = status;
        }
    }
}

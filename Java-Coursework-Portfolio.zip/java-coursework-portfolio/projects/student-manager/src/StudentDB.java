import java.sql.*;
import java.util.ArrayList;

public class StudentDB {

    private static Connection getConnection() throws SQLException {
        String url = "jdbc:sqlite:student.db";
        Connection conn = DriverManager.getConnection(url);
        return conn;
    }

    public static void createStudentTable() {
        String sql = "CREATE TABLE IF NOT EXISTS Students (" +
                " id TEXT PRIMARY KEY, " +
                " fullname TEXT NOT NULL," +
                " age INT," +
                " grade INT);";

        try (Connection conn = getConnection()) {
            Statement stmt = conn.createStatement();
            stmt.execute(sql);

            System.out.println("student table is created");
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    public static ArrayList<Student> selectAllStudents() {
        String sql = "SELECT id, fullname, age, grade " +
                "FROM Students ORDER by id ASC";
        var students = new ArrayList<Student>();


        try (Connection conn = getConnection()) {
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String id = rs.getString("id");
                String fullname = rs.getString("fullName");
                int age = rs.getInt("age");
                int grade = rs.getInt("grade");
                Student s = new Student(id, fullname, age, grade);
                students.add(s);
            }

            return students;

        } catch (SQLException e) {
            System.out.println(e);
            return null;
        }
    }

    public static Student selectStudentById (String id) {
        String sql = "SELECT id, fullname, age, grade FROM Students WHERE id = ?";
        try (Connection conn = getConnection()) {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                String fullname = rs.getString("fullname");
                int age = rs.getInt("age");
                int grade = rs.getInt("grade");
                Student student = new Student(id, fullname, age, grade);
                return student;
            } else {
                System.out.println("No student with the given id: " + id);
                return null;
            }
        } catch (SQLException e) {
            System.out.println(e);
            return null;
        }
    }

    public static boolean addStudent(Student student) {
        String sql = "INSERT INTO Students (id, fullname, age, grade)" +
                "VALUES (?,?,?,?)";
        try (Connection conn = getConnection()) {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, student.getId());
            ps.setString(2, student.getFullname());
            ps.setInt(3, student.getAge());
            ps.setInt(4, student.getAge());
            ps.executeUpdate();
            return true;
        } catch (SQLException e ) {
            System.out.println(e);
            return false;
        }
    }

    public static void deleteStudent(Student student) {
        String sql = "DELETE FROM Students WHERE id = ?";
        try (Connection conn = getConnection()) {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, student.getId());
            ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    public static boolean updateStudent(Student student) {
        String sql = "UPDATE Students SET fullname = ?, age = ?, grade = ?"
                + "WHERE id = ?";
        try (Connection conn = getConnection()) {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, student.getFullname());
            ps.setInt(2, student.getAge());
            ps.setInt(3, student.getGrade());
            ps.setString(4, student.getId());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println(e);
            return false;
        }
    }
}



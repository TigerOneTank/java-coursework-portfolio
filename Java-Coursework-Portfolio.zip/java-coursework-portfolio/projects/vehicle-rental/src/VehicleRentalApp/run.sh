#!/bin/sh
# Compile and run the Swing app without Maven or Gradle.
#
#   ./run.sh          compile then launch
#   ./run.sh clean    delete out/ and the database, then compile and launch
#
# Everything is compiled against the source root (FinalProject/src) so the
# package names VehicleRentalApp.* line up.

set -e
APP_DIR=$(cd "$(dirname "$0")" && pwd)
SRC_ROOT=$(cd "$APP_DIR/.." && pwd)            # .../FinalProject/src
OUT="$APP_DIR/out"
JAR="$APP_DIR/lib/sqlite-jdbc-3.51.1.0.jar"

if [ "$1" = "clean" ]; then
    rm -rf "$OUT" "$APP_DIR/data/rental.db"
    echo "Cleaned out/ and data/rental.db"
fi

mkdir -p "$OUT"
echo "Compiling..."
find "$APP_DIR" -name '*.java' -print0 | xargs -0 \
    javac -encoding UTF-8 -d "$OUT" -cp "$JAR" -sourcepath "$SRC_ROOT"

echo "Starting..."
cd "$APP_DIR"                                   # so data/rental.db lands here
java --enable-native-access=ALL-UNNAMED -cp "$OUT:$JAR" VehicleRentalApp.App

# Source provenance

Imported from the Java coursework folders supplied by the portfolio owner in November 2026. This is an import date, not a project creation date.

- 171 Java source files are preserved across 18 source collections, including two versions of one vehicle-rental assignment and one reference collection.
- Duplicate Drive entries at the same original path had identical bytes and were copied once. Distinct original folders remain distinct, including the earlier vehicle-rental version.
- Original class/package names, learning comments, assignment scaffolding, and form resources are retained. Original guides are included where supplied.
- Existing databases, contact photos, downloaded dependency binaries, compiled output, and machine-specific IDE files were excluded from publication. Originals in Drive were not changed.
- Source email examples were replaced with reserved example.com addresses. Library member fixture names/phone numbers were replaced with fictional values. A local Windows image path became resources/example.jpg.
- Documentation, the build/run helper, and review checks were added with AI assistance during organization. They are not represented as original coursework features or historical work.
- The vehicle assignment contains explicit GIVEN/YOUR TASK scaffolding. The exact division of teacher and student contributions has not been independently established. The reference collection remains labeled as reference material.
- No blanket license was added because the rights to supplied classroom/reference material have not been established.

The [source manifest](source-manifest.json) maps original relative paths to published paths and records SHA-256 checksums. Private Drive IDs are not published.

## Sanitized source files

- `projects/library-manager/src/com/library/dao/Database.java` — Demo contact details or machine-specific image path sanitized.
- `projects/student-mvc/src/com/learnmvc/model/Database.java` — Demo contact details or machine-specific image path sanitized.
- `exercises/collections/src/Week1/IntroToHashMap.java` — Demo contact details or machine-specific image path sanitized.
- `exercises/swing-components/src/Main.java` — Demo contact details or machine-specific image path sanitized.

package VehicleRentalApp.controller;

import VehicleRentalApp.dao.CustomerDao;
import VehicleRentalApp.dao.Database;
import VehicleRentalApp.dao.RentalDao;
import VehicleRentalApp.dao.VehicleDao;
import VehicleRentalApp.model.Customer;
import VehicleRentalApp.model.Rental;
import VehicleRentalApp.model.Vehicle;
import VehicleRentalApp.model.VehicleNotAvailableException;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

/*
 * RentalController.java  -- YOUR TASK  (Step 7)
 *
 * This is everything RentalShop.rentVehicle() used to do, except it writes to
 * SQLite instead of to an ArrayList. It is the hardest file in the project.
 * Do Steps 1 to 6 first.
 *
 * THE NEW IDEA HERE: A TRANSACTION
 *
 * Renting one vehicle changes THREE tables:
 *      customers -- the loyalty counter goes up
 *      rentals   -- a new row
 *      vehicles  -- available flips to 0
 *
 * If the app died between the second and the third write, the vehicle would
 * still look free and you would rent it to two people. In the console version
 * you could not do anything about that. A database can:
 *
 *      conn.setAutoCommit(false);   // stop saving after every statement
 *      ... the three writes ...
 *      conn.commit();               // now all three land, together
 *      // or on failure:
 *      conn.rollback();             // none of them land
 *
 * All or nothing. That is a transaction, and it is the grown-up answer to the
 * classic "forgot to set available = false" bug.
 */
public class RentalController {

    private final RentalDao rentalDao = new RentalDao();
    private final VehicleDao vehicleDao = new VehicleDao();
    private final CustomerDao customerDao = new CustomerDao();

    // ---- GIVEN -----------------------------------------------------------

    public List<Rental> listAll() throws SQLException {
        return rentalDao.findAll();
    }

    public Rental find(String rentalId) throws SQLException {
        return rentalDao.findById(rentalId);
    }

    // ---- YOUR TASK -------------------------------------------------------

    /**
     * Attempts to book a vehicle for a customer.
     *
     * @return the newly created Rental, ready to display as a receipt
     * @throws VehicleNotAvailableException when the id does not exist OR is out
     * @throws IllegalArgumentException     when the form data makes no sense
     */
    public Rental rentVehicle(String vehicleId, String customerName, int days)
            throws VehicleNotAvailableException, IllegalArgumentException, SQLException {

        /*
         * TODO 7.1: validate, and throw the RIGHT exception for each problem.
         *
         *   customerName null or blank -> IllegalArgumentException
         *                                 "Customer name is required."
         *   days <= 0                  -> IllegalArgumentException
         *                                 "Days must be at least 1."
         *
         * TODO 7.2: look the vehicle up with vehicleDao.findById(vehicleId).
         *
         *   not found        -> throw new VehicleNotAvailableException(
         *                           vehicleId, "No such vehicle: " + vehicleId)
         *   !v.isAvailable() -> throw new VehicleNotAvailableException(
         *                           vehicleId, "Already rented out: " + vehicleId)
         *
         * WHY TWO DIFFERENT EXCEPTION TYPES?
         * VehicleNotAvailableException is CHECKED (it extends Exception), so
         * the compiler refuses to build any caller that neither catches it nor
         * declares it. "This vehicle is out" is a normal thing that happens in
         * a rental shop, and the shop must never be able to ignore it.
         * IllegalArgumentException is unchecked, because an empty form field
         * is a programming/user slip, not a business event.
         *
         * Look at RentalPanel.rent() -- it has a separate catch block for each
         * one, showing a different message. That is only possible because you
         * threw two different types here.
         */

        if (customerName == null || customerName.isBlank()) {
            throw new IllegalArgumentException("Customer name is required.");
        }
        if (days <= 0) {
            throw new IllegalArgumentException("Days must be at least 1.");
        }

        Vehicle vehicle = vehicleDao.findById(vehicleId);
        if (vehicle == null) {
            throw new VehicleNotAvailableException(vehicleId, "No such vehicle: " + vehicleId);
        }
        if (!vehicle.isAvailable()) {
            throw new VehicleNotAvailableException(vehicleId, "Already rented out: " + vehicleId);
        }

        // ---- the transaction ----------------------------------------------

        Connection conn = Database.getConnection();
        boolean autoCommit = conn.getAutoCommit();
        conn.setAutoCommit(false);          // GIVEN: from here, nothing saves
        try {

            /*
             * TODO 7.3: get or create the customer, and count the rental.
             *
             *      Customer customer = customerDao.findOrCreate(customerName.trim());
             *      customer.recordRental();
             *      customerDao.updateRentalCount(customer);
             *
             * ORDER MATTERS. Count the rental BEFORE building the Rental
             * below. The Rental constructor freezes the discount from the
             * customer's count at that moment, so counting afterwards would
             * make the discount land on the 4th rental instead of the 3rd.
             * Get this wrong and the app still runs -- it is just quietly
             * wrong by one, which is the worst kind of bug.
             */

            Customer customer = customerDao.findOrCreate(customerName.trim());
            customer.recordRental();
            customerDao.updateRentalCount(customer);

            /*
             * TODO 7.4: build the Rental and save it.
             *
             *      Rental r = new Rental(rentalDao.nextRentalId(), customer, v, days);
             *      rentalDao.insert(r);
             *
             * Use the 4-argument constructor here -- this is a NEW booking, so
             * the discount SHOULD be calculated fresh. (RentalDao.map() uses
             * the long one, because a stored rental keeps the price it was
             * given. Two constructors, two different jobs.)
             */

            Rental rental = new Rental(rentalDao.nextRentalId(), customer, vehicle, days);
            rentalDao.insert(rental);

            /*
             * TODO 7.5: mark the vehicle as taken, in the database AND in the
             * object you are about to hand back:
             *
             *      vehicleDao.updateAvailability(v.getId(), false);
             *      v.setAvailable(false);
             *
             * Both lines. The first is the permanent record; the second keeps
             * the object in memory honest, because the panel is holding it.
             */

            vehicleDao.updateAvailability(vehicle.getId(), false);
            vehicle.setAvailable(false);

            conn.commit();                  // GIVEN: now all three writes land
            // TODO 7.6: return the Rental you built in 7.4
            return rental;

        } catch (SQLException e) {
            conn.rollback();                // GIVEN: undo everything above
            throw e;
        } finally {
            conn.setAutoCommit(autoCommit); // GIVEN: always restore the mode
        }
    }

    /**
     * Takes a vehicle back.
     *
     * @param actualDays days the customer actually kept it; more than booked
     *                   means a late fee
     * @return the updated rental, or null if the id is unknown or already back
     */
    public Rental returnVehicle(String rentalId, int actualDays) throws SQLException {

        /*
         * TODO 7.7: find the rental and refuse the silly cases.
         *
         *      Rental r = rentalDao.findById(rentalId);
         *      if (r == null || r.isReturned()) { return null; }
         *
         * The isReturned() check is not decoration. Without it a second click
         * on "Return selected" charges the customer a second late fee.
         *
         * Then, if actualDays <= 0, fall back to r.getDays() -- the user just
         * pressed Enter, so assume they kept it exactly as booked.
         */

        Rental rental = rentalDao.findById(rentalId);
        if (rental == null || rental.isReturned()) {
            return null;
        }

        if (actualDays <= 0) {
            actualDays = rental.getDays();
        }

        /*
         * TODO 7.8: two writes, so it is a transaction again. Copy the shape
         * from rentVehicle():
         *
         *      conn.setAutoCommit(false)
         *          rentalDao.markReturned(rentalId, actualDays);
         *          vehicleDao.updateAvailability(r.getVehicle().getId(), true);
         *      conn.commit()      / rollback on SQLException
         *      finally: restore autoCommit
         *
         * TODO 7.9: update the in-memory object too, then return it:
         *
         *      r.markReturned(actualDays);
         *      r.getVehicle().setAvailable(true);
         *      return r;
         *
         * The panel immediately calls r.toReceipt() on what you return, and
         * the late fee only appears if markReturned() has been called.
         */

        Connection conn = Database.getConnection();
        boolean autoCommit = conn.getAutoCommit();
        conn.setAutoCommit(false);
        try {
            rentalDao.markReturned(rentalId, actualDays);
            vehicleDao.updateAvailability(rental.getVehicle().getId(), true);
            conn.commit();
        } catch (SQLException e) {
            conn.rollback();
            throw e;
        } finally {
            conn.setAutoCommit(autoCommit);
        }

        rental.markReturned(actualDays);
        rental.getVehicle().setAvailable(true);
        return rental;
    }
}

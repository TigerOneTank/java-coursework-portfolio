package com.library.view;

import com.library.model.Book;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.util.List;


public class BookView extends JPanel {

    private final DefaultTableModel tableModel =
            new DefaultTableModel(new Object[]{"ID", "Title", "Author", "ISBN", "Category", "Avail", "Total"}, 0) {
                @Override public boolean isCellEditable(int r, int c) { return false; }
            };
    private final JTable table = new JTable(tableModel);

    private final JTextField searchField = new JTextField(18);
    private final JTextField titleField = new JTextField(14);
    private final JTextField authorField = new JTextField(14);
    private final JTextField isbnField = new JTextField(14);
    private final JTextField categoryField = new JTextField(14);
    private final JTextField totalField = new JTextField(4);

    private final JButton searchBtn = new JButton("Search");
    private final JButton refreshBtn = new JButton("Refresh");
    private final JButton addBtn = new JButton("Add");
    private final JButton updateBtn = new JButton("Update");
    private final JButton deleteBtn = new JButton("Delete");
    private final JButton clearBtn = new JButton("Clear");

    public BookView() {
        setLayout(new BorderLayout(8, 8));
        setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        add(buildSearchBar(), BorderLayout.NORTH);

        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getSelectionModel().addListSelectionListener(e -> fillFormFromSelection());
        add(new JScrollPane(table), BorderLayout.CENTER);

        add(buildForm(), BorderLayout.SOUTH);
        clearBtn.addActionListener(e -> clearForm());
    }

    private JPanel buildSearchBar() {
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT));
        bar.add(new JLabel("Search:"));
        bar.add(searchField);
        bar.add(searchBtn);
        bar.add(refreshBtn);
        return bar;
    }

    private JPanel buildForm() {
        JPanel wrapper = new JPanel(new BorderLayout(6, 6));

        JPanel fields = new JPanel(new GridLayout(2, 6, 6, 6));
        fields.add(new JLabel("Title:"));   fields.add(titleField);
        fields.add(new JLabel("Author:"));  fields.add(authorField);
        fields.add(new JLabel("ISBN:"));    fields.add(isbnField);
        fields.add(new JLabel("Category:")); fields.add(categoryField);
        fields.add(new JLabel("Total copies:")); fields.add(totalField);
        fields.add(new JLabel(""));         fields.add(new JLabel(""));
        wrapper.add(fields, BorderLayout.CENTER);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttons.add(clearBtn);
        buttons.add(addBtn);
        buttons.add(updateBtn);
        buttons.add(deleteBtn);
        wrapper.add(buttons, BorderLayout.SOUTH);
        return wrapper;
    }

    private void fillFormFromSelection() {
        int row = table.getSelectedRow();
        if (row < 0) return;
        titleField.setText(str(tableModel.getValueAt(row, 1)));
        authorField.setText(str(tableModel.getValueAt(row, 2)));
        isbnField.setText(str(tableModel.getValueAt(row, 3)));
        categoryField.setText(str(tableModel.getValueAt(row, 4)));
        totalField.setText(str(tableModel.getValueAt(row, 6)));
    }

    // ---- controller wiring ----

    public void setOnSearch(Runnable r)  { searchBtn.addActionListener(e -> r.run()); }
    public void setOnRefresh(Runnable r) { refreshBtn.addActionListener(e -> { searchField.setText(""); r.run(); }); }
    public void setOnAdd(Runnable r)     { addBtn.addActionListener(e -> r.run()); }
    public void setOnUpdate(Runnable r)  { updateBtn.addActionListener(e -> r.run()); }
    public void setOnDelete(Runnable r)  { deleteBtn.addActionListener(e -> r.run()); }

    // ---- raw input the controller reads ----

    public String getSearchText()      { return searchField.getText().trim(); }
    public String getTitleText()       { return titleField.getText(); }
    public String getAuthorText()      { return authorField.getText(); }
    public String getIsbnText()        { return isbnField.getText(); }
    public String getCategoryText()    { return categoryField.getText(); }
    public String getTotalCopiesText() { return totalField.getText(); }

    public boolean hasSelection()        { return table.getSelectedRow() >= 0; }
    public int getSelectedId()           { return (int) tableModel.getValueAt(table.getSelectedRow(), 0); }
    public int getSelectedAvailable()    { return (int) tableModel.getValueAt(table.getSelectedRow(), 5); }
    public int getSelectedTotal()        { return (int) tableModel.getValueAt(table.getSelectedRow(), 6); }

    // ---- state the controller pushes back in ----

    public void populate(List<Book> books) {
        tableModel.setRowCount(0);
        for (Book b : books) {
            tableModel.addRow(new Object[]{
                    b.getId(), b.getTitle(), b.getAuthor(), b.getIsbn(),
                    b.getCategory(), b.getAvailableCopies(), b.getTotalCopies()});
        }
        clearForm();
    }

    public void clearForm() {
        titleField.setText("");
        authorField.setText("");
        isbnField.setText("");
        categoryField.setText("");
        totalField.setText("");
        table.clearSelection();
    }

    public boolean confirmDelete(int id) {
        return JOptionPane.showConfirmDialog(this, "Delete book #" + id + "?",
                "Confirm delete", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION;
    }

    public void showInfo(String m)    { JOptionPane.showMessageDialog(this, m, "Success", JOptionPane.INFORMATION_MESSAGE); }
    public void showWarning(String m) { JOptionPane.showMessageDialog(this, m, "Notice", JOptionPane.WARNING_MESSAGE); }
    public void showError(String m)   { JOptionPane.showMessageDialog(this, m, "Error", JOptionPane.ERROR_MESSAGE); }

    private static String str(Object o) { return o == null ? "" : o.toString(); }
}

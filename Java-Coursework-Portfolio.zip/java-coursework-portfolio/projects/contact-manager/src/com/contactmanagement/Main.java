package com.contactmanagement;

import com.contactmanagement.controller.ContactController;
import com.contactmanagement.model.ContactDAO;
import com.contactmanagement.view.MainFrame;

import javax.swing.SwingUtilities;

public class Main {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MainFrame view = new MainFrame();
            ContactDAO model = new ContactDAO();
            new ContactController(view, new ContactDAO());
            view.setVisible(true);
        });
    }
}

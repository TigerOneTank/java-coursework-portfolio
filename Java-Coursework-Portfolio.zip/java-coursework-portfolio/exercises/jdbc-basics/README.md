# JDBC Basics

Separate console examples for connecting to SQLite and creating, inserting, reading, updating, and deleting product records.

**Context:** Java coursework and guided learning. Original folder: `JavaDatabase`.

## What the code demonstrates

Connections, SQL statements, and persistent records. The original implementation and learning comments are retained; the portfolio packaging is documented in [provenance](../../docs/PROVENANCE.md).

## Run

From the repository root, with Python 3 and a JDK installed:

```sh
python3 tools/portfolio.py build jdbc-basics
python3 tools/portfolio.py run jdbc-basics
```

Windows users can use `py` instead of `python3`. 

Database examples also require the SQLite JDBC runtime described in [setup](../../docs/RUNNING.md). Run each collection separately: several use the same class names.

## Known limitations

Run CreateTable once before InsertRecords and PrintRecords. UpdateRecords/DeleteRecord mutate the demo database; read their fixed identifiers before running them.

## Learning notes

The useful code-reading focus here is connections, sql statements, and persistent records. This README describes the submitted implementation; it does not claim every component was written independently. Personal reflections can be added after reviewing the source.

See [validation](../../docs/VALIDATION.md) for the exact scope of checks.

# Library Manager

Swing library application with books, members, login roles, and issue/return services backed by SQLite.

**Context:** Java coursework and guided learning. Original folder: `NewProject`.

## What the code demonstrates

Service layers, relational data, borrowing rules, and transaction boundaries. The original implementation and learning comments are retained; the portfolio packaging is documented in [provenance](../../docs/PROVENANCE.md).

## Run

From the repository root, with Python 3 and a JDK installed:

```sh
python3 tools/portfolio.py build library-manager
python3 tools/portfolio.py run library-manager
```

Windows users can use `py` instead of `python3`. 

Database examples also require the SQLite JDBC runtime described in [setup](../../docs/RUNNING.md). Run each collection separately: several use the same class names.

## Known limitations

FineCalculator currently returns zero. Repeated returns can inflate available copies; return errors lack explicit rollback. BookController passes total/available counts in reverse order when editing. Demo authentication uses salted SHA-256, not a password-specific KDF.

## Learning notes

The useful code-reading focus here is service layers, relational data, borrowing rules, and transaction boundaries. This README describes the submitted implementation; it does not claim every component was written independently. Personal reflections can be added after reviewing the source.

See [validation](../../docs/VALIDATION.md) for the exact scope of checks.

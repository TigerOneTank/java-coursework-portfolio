import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DeleteRecord {
    public static void main(String[] args) {
        String sql = "DELETE FROM products WHERE id = ?";
        var url = "jdbc:sqlite:java_db.db";

        try (var conn = DriverManager.getConnection(url);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, 3);
            stmt.executeUpdate();
            System.out.println("product is deleted.");

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}
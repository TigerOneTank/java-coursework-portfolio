package com.learnmvc.controller;

import com.learnmvc.model.Student;
import com.learnmvc.model.StudentDAO;
import com.learnmvc.view.StudentView;
import javax.swing.event.ListSelectionEvent;

public class StudentController {

    private final StudentView view;
    private final StudentDAO dao;

    public StudentController(StudentView view, StudentDAO dao) {
        this.view = view;
        this.dao = dao;

        this.view.addClearListener(e -> view.clearForm());
        this.view.addTableSelectionListener(e -> onRowSelected(e));
        this.view.addDeleteListener(e -> deleteStudent());
        this.view.addSaveListener(e -> addStudent());
        this.view.addUpdateListener(e -> updateStudent());

        // Initial load: pull data from the Model and hand it to the View.
        refresh();
    }

    private void refresh() {
        view.setStudents(dao.findAll());
        view.clearForm();
    }

    /** CREATE: validate input, insert via DAO, refresh the table. */
    private void addStudent() {
        String name = view.getName();
        if (name.isEmpty()) {
            view.showMessage("Name is required");
            return;
        }
        String email = view.getEmail();
        String major = view.getMajor();
        Student s = new Student(0, name, email, major);
        dao.insert(s);
        view.showMessage("Student is added");
        refresh();
    }

    /** UPDATE: needs a selected row; save edits via DAO. */
    private void updateStudent() {
        int id = view.getSelectedId();
        System.out.println(id);
        if (id == -1) {
            view.showMessage("Select a student row in the table first");
            return;
        }
        String name = view.getName();
        if (name.isEmpty()) {
            view.showMessage("Name is required.");
            return;
        }
        Student s = new Student(id, name, view.getEmail(), view.getMajor());
        dao.update(s);
        view.showMessage("Student is updated.");
        refresh();
    }

    /** DELETE: needs a selected row; remove via DAO. */
    private void deleteStudent() {
        int id = view.getSelectedId();
        if (id == -1) {
            view.showMessage("Select a student in the table first.");
            return;
        }
        dao.delete(id);
        view.showMessage("Student deleted");
        refresh();
    }

    /** When the user picks a row, copy its values into the form for editing. */
    private void onRowSelected(ListSelectionEvent e) {
        if (e.getValueIsAdjusting()) return;
        if (view.getSelectedId() == -1) return;
        view.fillForm(
                view.getSelectedId(),
                view.getSelectedValue(1),
                view.getSelectedValue(2),
                view.getSelectedValue(3)
        );
    }
}

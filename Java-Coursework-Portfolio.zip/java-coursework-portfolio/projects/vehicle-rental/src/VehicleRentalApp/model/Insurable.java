package VehicleRentalApp.model;

/**
 * Contract signed by vehicles the shop is willing to insure (Car, Truck).
 * Motorbike and Bicycle deliberately do NOT sign it.
 */
public interface Insurable {

    /** Cost of insurance cover for the given number of days. */
    double calculateInsurance(int days);

    /** Name of the policy shown on the receipt. */
    String getPolicyName();
}

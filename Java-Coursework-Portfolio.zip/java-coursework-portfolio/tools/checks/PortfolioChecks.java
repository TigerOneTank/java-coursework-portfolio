import VehicleRentalApp.model.*;
import com.library.service.FineCalculator;
import com.library.service.LoanService;
import com.library.dao.Database;
import java.time.LocalDate;

public class PortfolioChecks {
    static void equal(double actual, double expected, String label) {
        if (Math.abs(actual - expected) > 0.00001) throw new AssertionError(label + ": " + actual);
        System.out.println("PASS " + label);
    }
    public static void main(String[] args) throws Exception {
        Car car = new Car("TEST-CAR", "Demo", "Model", 33, 4, true);
        Customer customer = new Customer(1, "Demo Customer", 3);
        Rental rental = new Rental("TEST-RENTAL", customer, car, 3);
        equal(rental.getSubtotal(), 114.9, "rental subtotal includes GPS and insurance");
        equal(rental.getDiscountAmount(), 11.49, "loyalty discount");
        equal(rental.getLateFee(), 0, "no late fee before return");
        rental.markReturned(5);
        equal(rental.getTotalCost(), 182.61, "late return total");
        VehicleRentalApp.dao.Database.init();
        try (var st = VehicleRentalApp.dao.Database.getConnection().createStatement(); var rs=st.executeQuery("SELECT count(*) FROM vehicles")) {
            rs.next(); equal(rs.getInt(1),6,"vehicle schema and six seed vehicles");
        }
        equal(new FineCalculator().calculate(LocalDate.of(2026,1,1),LocalDate.of(2026,1,5)),0,"known limitation: late fine remains zero");
        Database.initialize();
        LoanService loans = new LoanService();
        var loan = loans.issueBook(1,1);
        loans.returnBook(loan.getId());
        loans.returnBook(loan.getId());
        try (var c=Database.getConnection();var st=c.createStatement();var rs=st.executeQuery("SELECT available_copies,total_copies FROM books WHERE id=1")) {
            rs.next(); equal(rs.getInt(1),rs.getInt(2)+1,"known limitation: duplicate return inflates stock");
        }
    }
}

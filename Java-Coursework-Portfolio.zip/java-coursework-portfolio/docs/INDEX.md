# Collection index

Each row is a source collection, not a claim of an independently authored finished project.

| Original folder | Portfolio location | Entry point |
| --- | --- | --- |
| `Final-Project` | [Vehicle Rental](../projects/vehicle-rental) | `VehicleRentalApp.App` |
| `CONTACTMNG-MVC` | [Contact Manager](../projects/contact-manager) | `com.contactmanagement.Main` |
| `NewProject` | [Library Manager](../projects/library-manager) | `com.library.Main` |
| `MiniMart` | [Mini Mart](../projects/mini-mart) | `SignInScreen` |
| `LearnMVCPattern` | [Student MVC](../projects/student-mvc) | `com.learnmvc.Main` |
| `StudentManagement` | [Student Manager CLI](../projects/student-manager) | `Main` |
| `FinalTest` | [CoursePal CLI](../projects/course-pal) | `Main` |
| `myToDoList` | [To-do CLI](../projects/todo-list) | `Main` |
| `JavaTerm3` | [Early Contact App](../projects/contact-app) | `contactApp.Main` |
| `JavaTerm4` | [Collections Practice](../exercises/collections) | `Week4.BusRoute` |
| `JavaDatabase` | [JDBC Basics](../exercises/jdbc-basics) | `CreateTable` |
| `JavaInterLevel2` | [Swing Components](../exercises/swing-components) | `Main` |
| `JavaGuiExam` | [Course Registration Form](../exercises/course-registration) | `CCKHSystemStarter` |
| `SwingFX` | [Swing Labs](../exercises/swing-labs) | `Main` |
| `JavaIntermediateLevel2` | [JavaFX Starter](../exercises/javafx-starter) | `com.example.javaintermediatelevel2.HelloApplication` |
| `JavaIntermediateCourse` | [Hello Java](../exercises/hello-java) | `Main` |
| `Final-Project-Original` | [Vehicle Rental — Earlier Copy](../versions/vehicle-rental-original) | `VehicleRentalApp.App` |
| `Reference - Rephrased/SwingJavaFX` | [Swing Navigation Reference](../references/swing-navigation) | `Main` |

package Week4;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class CanteenOrders {

    public static void main(String[] args) {
        Map<String, ArrayList<String>> orders = new HashMap<>();

        addOrder(orders, "Alice", "Burger");
        addOrder(orders, "Bob", "Pizza");
        addOrder(orders, "Alice", "Fries");
        addOrder(orders, "Charlie", "Sandwich");
        addOrder(orders, "Bob", "Soda");
        addOrder(orders, "Alice", "Juice");
        addOrder(orders, "David", "Salad");
        addOrder(orders, "Bob", "Ice Cream");

        System.out.println("--- Canteen Orders ---");
        for (Map.Entry<String, ArrayList<String>> entry : orders.entrySet()) {
            String studentName = entry.getKey();
            ArrayList<String> items = entry.getValue();
            int itemCount = items.size();

            System.out.println("Student: " + studentName);
            System.out.println("Items ordered: " + itemCount);
            System.out.println("List: " + items);
            System.out.println("----------------------");
        }
    }

    public static void addOrder(Map<String, ArrayList<String>> orders, String student, String item) {

        if (!orders.containsKey(student)) {
            orders.put(student, new ArrayList<>());
        }
        orders.get(student).add(item);
        System.out.println("Added " + item + " to " + student);
    }
}
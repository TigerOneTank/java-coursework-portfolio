# Vehicle Rental Shop — System Analysis

**Read this before you write any code.** The Student Guide tells you *how* to
build the system. This document explains *what* you are building and *why* the
rules are what they are. Programmers who skip this step write code that
compiles and still solves the wrong problem.

---

## 1. The business

Chariya runs a small vehicle rental shop in Phnom Penh. She owns six vehicles —
two cars, two motorbikes, a truck and a bicycle — and rents them by the day to
walk-in customers.

Today she runs the shop on paper. A customer walks in, she flips through a
notebook to see what is free, writes down the name and the number of days,
works the price out on a calculator, and takes a deposit. When the vehicle
comes back she works out whether anything extra is owed.

Three things go wrong often enough to be worth fixing:

1. **Double booking.** She forgets to cross a vehicle off, and promises the
   same car to two customers on the same day.
2. **Pricing mistakes.** Every vehicle type is priced differently, and the
   arithmetic is done by hand, under pressure, while the customer waits.
3. **No memory.** She wants to reward regulars with a discount, but she cannot
   remember who is a regular. The notebook is a list of rentals, not a list of
   people.

She has asked for a desktop application that removes all three.

### What success looks like

> Chariya can see at a glance what is free, rent it in under thirty seconds
> with the price calculated for her, take it back and be told exactly what is
> owed — and none of it is lost when she closes the program.

---

## 2. Scope

**In scope**

- Recording the fleet and whether each vehicle is currently out
- Renting a vehicle to a named customer for a whole number of days
- Calculating the price, including insurance, loyalty discount and late fees
- Taking a vehicle back and charging for extra days
- Recognising returning customers and applying a loyalty discount
- A daily report of takings
- Storing all of it so it survives closing the application

**Out of scope** (say so in your report if you are asked — knowing what you
did *not* build is part of analysis)

- Money: no payments, deposits, refunds or receipts printing
- Calendar booking: rentals start "today", there is no reserving next Tuesday
- Users and passwords: one member of staff, no login
- Damage, fuel, mileage, servicing
- Multiple branches, delivery, or anything over a network

---

## 3. Who uses it

| Actor | Type | What they need |
|---|---|---|
| **Shop staff** (Chariya) | primary, human | The only person who touches the app. Rents, returns, checks the fleet, reads the report. |
| **Customer** | secondary, human | Never touches the app. Is *represented in* it — they are the reason the loyalty counter exists. |
| **The database** | supporting, system | Remembers everything between sessions. |

There is exactly one human user, and that is a deliberate simplification. It is
why there is no login screen and no permissions.

---

## 4. What the system must do

| # | Requirement | Priority |
|---|---|---|
| FR-1 | Show every vehicle with its type, rate, details and whether it is available | Must |
| FR-2 | Filter the fleet to only what is free right now | Must |
| FR-3 | Sort the fleet by daily rate | Should |
| FR-4 | Add a new vehicle of any of the four types | Should |
| FR-5 | Remove a vehicle, unless it has rental history | Could |
| FR-6 | Rent an available vehicle to a named customer for N days | Must |
| FR-7 | Show a priced receipt at the moment of renting | Must |
| FR-8 | Take a vehicle back, recording how many days it was actually kept | Must |
| FR-9 | Charge a penalty when it comes back late | Must |
| FR-10 | Recognise a returning customer and count their rentals | Must |
| FR-11 | Apply a loyalty discount once a customer qualifies | Must |
| FR-12 | Show rental history with each rental's status | Must |
| FR-13 | Report takings, discounts given, late fees and fleet statistics | Should |
| FR-14 | Keep all data between runs of the program | Must |

**Non-functional**

| # | Requirement |
|---|---|
| NFR-1 | A rental must never be half-saved. Either the whole rental is recorded or nothing is. |
| NFR-2 | The pricing rules must exist in exactly one place, so a price change is a one-line edit. |
| NFR-3 | Adding a fifth vehicle type must not require changing the rental or reporting logic. |
| NFR-4 | A failed operation must explain itself to the user, not crash. |
| NFR-5 | The database must be swappable (SQLite → MySQL) without touching the screens. |

NFR-2 and NFR-3 are why the design uses an abstract class and interfaces
rather than a `type` field and a chain of `if` statements. NFR-5 is why there
are four layers.

---

## 5. The things in the system

```
        <<abstract>>                        <<interface>>
          Vehicle  - - - - - - - - - - - -   Insurable
        ------------------                  -------------------
        id, brand, model                    calculateInsurance(days)
        dailyRate, available                getPolicyName()
        ------------------                        ^
        calculateRentalCost(days)                 | signed by
        getType()                                 |
              ^                                   |
              | IS-A                              |
    +---------+---------+---------+               |
   Car    Motorbike   Truck   Bicycle             |
    |                   |                         |
    +-------------------+-------------------------+


                                             <<interface>>
        Customer  - - - - - - - - - - - - -  Discountable
        ------------------                  --------------------
        id, name, rentalCount               qualifiesForDiscount()
                                            getDiscountRate()
                                            getDiscountLabel()

        Rental
        --------------------------------
        rentalId, days, returned, actualDays, discountRate
        HAS-A Customer      HAS-A Vehicle
        --------------------------------
        getSubtotal()  getDiscountAmount()  getLateFee()  getTotalCost()
```

**Two relationships to keep straight**

| | Question | Example |
|---|---|---|
| **IS-A** → inheritance | "Is a Truck a kind of Vehicle?" Yes → `extends` | `Truck extends Vehicle` |
| **HAS-A** → composition | "Does a Rental contain a Vehicle?" Yes → a field | `Rental` has a `Vehicle` |

A `Rental` is **not** a kind of Vehicle. It must never `extend Vehicle`.

**Why two interfaces and not two more fields?** Because neither behaviour
belongs to everyone. A motorbike is not insurable, so putting
`calculateInsurance()` on `Vehicle` would force `Motorbike` to inherit
something meaningless. And `Discountable` is signed by `Customer` — a
completely unrelated family — which proves an interface is a contract you
attach where it applies, not a second kind of parent.

---

## 6. Business rules

This is the heart of the analysis. Every rule below is a decision the *business*
made, not a decision the programmer made. Your code has to implement all of
them, and your marks depend on getting them exactly right.

### Pricing

| # | Rule |
|---|---|
| **BR-01** | Every rental is priced for a whole number of days, minimum 1. |
| **BR-02** | **Car**: `dailyRate × days`, plus `$2.00 × days` if it has GPS. |
| **BR-03** | **Motorbike**: `dailyRate × days`, plus a **one-off** `$3.00` helmet fee — not per day. |
| **BR-04** | **Truck**: `dailyRate × days`, plus `$5.00 × loadTons × days`. |
| **BR-05** | **Bicycle**: `dailyRate × days`. Every bicycle is a flat `$5.00/day`; the rate is not chosen per bicycle. |

> Four types, four formulas, one method name. This is the definition of
> polymorphism, and it is the reason `Rental` can price any vehicle without
> asking what type it is.

### Insurance

| # | Rule |
|---|---|
| **BR-06** | Only cars and trucks can be insured. Motorbikes and bicycles cannot — the customer signs a waiver. |
| **BR-07** | **Car**: `dailyRate × 10% × days`. Policy name "Standard Car Cover". |
| **BR-08** | **Truck**: `dailyRate × 15% × days`, plus a one-off `$20.00` paperwork fee. Policy name "Commercial Truck Cover". |
| **BR-09** | An uninsurable vehicle contributes `$0.00` and shows the cover as "no cover". |

> BR-09 matters more than it looks. The system must not ask "is this a
> Motorbike?" — it must ask "did this vehicle sign the insurance contract?".
> Get that right and BR-06 keeps working when a fifth vehicle type appears.

### Loyalty

| # | Rule |
|---|---|
| **BR-10** | A customer is identified by name. "sokha" and "Sokha" are the **same person**. |
| **BR-11** | Every rental increases that customer's rental count by one. |
| **BR-12** | A customer qualifies for the loyalty discount once their count reaches **3** — the discount applies **on** the third rental, not after it. |
| **BR-13** | The discount is **10% off the whole subtotal**, insurance included. |
| **BR-14** | The rate is fixed at the moment of booking and never changes afterwards. |

> **BR-14 is the subtle one.** Suppose Sokha's first rental is still in the
> history when she earns her discount on her third. If the system recalculated
> the discount every time it displayed a receipt, that first rental would
> retroactively get 10% cheaper — and the day's takings would change by
> themselves. The rate is therefore *stored on the rental*, not recomputed.

### Returns and lateness

| # | Rule |
|---|---|
| **BR-15** | A rental records days **booked** and, once back, days **actually kept**. |
| **BR-16** | Kept ≤ booked → no penalty. There is no refund for bringing it back early. |
| **BR-17** | Kept > booked → each extra day costs `dailyRate × 1.20` (the daily rate plus a 20% penalty). |
| **BR-18** | A vehicle can only be returned once. A second attempt must be refused, never charged twice. |
| **BR-19** | **Total = subtotal − discount + late fee.** |

### Availability

| # | Rule |
|---|---|
| **BR-20** | A vehicle is either available or out. It cannot be rented while it is out. |
| **BR-21** | Renting marks it out; returning marks it available. |
| **BR-22** | A vehicle that has ever been rented cannot be deleted from the fleet — its receipts would be left pointing at nothing. |
| **BR-23** | Vehicle IDs are unique and chosen by the shop (`C01`, `M02`). Customer IDs are invented by the system. |

### Integrity

| # | Rule |
|---|---|
| **BR-24** | Renting is **all or nothing**. It updates the customer's count, creates the rental and marks the vehicle out — if any of the three fails, none of them happen. |
| **BR-25** | Takings are the sum of every rental's total, discounts and late fees included. |

> **BR-24 is the fix for Chariya's double-booking problem.** On paper, "write
> it down" and "cross the vehicle off" are two actions and she sometimes did
> only the first. In the system they are one action that either completes or
> does not.

---

## 7. How a vehicle moves through the system

```
                  rent (BR-20, BR-21)
        +-----------+  ------------->  +-------------+
        | AVAILABLE |                  | RENTED OUT  |
        +-----------+  <-------------  +-------------+
              ^            return
              |
        added to fleet            a vehicle with history
        (starts available)        can never be deleted (BR-22)
```

And a rental:

```
        created  ---->  OPEN  ---->  RETURNED  ---->  (final, BR-18)
                          |             |
                     vehicle is out     +-- on time  : no penalty
                     counted in         +-- late     : penalty (BR-17)
                     "currently out"
```

---

## 8. The two main processes

### Renting a vehicle

| Step | What happens | Rule |
|---|---|---|
| 1 | Staff picks a vehicle from the list of available ones, types a customer name and a number of days | |
| 2 | System checks the days make sense | BR-01 |
| 3 | System checks the vehicle exists and is free | BR-20 |
| 4 | System finds the customer by name, or creates them if new | BR-10 |
| 5 | System increases their rental count | BR-11 |
| 6 | System works out the discount rate **now** and freezes it | BR-12, BR-14 |
| 7 | System creates the rental and prices it | BR-02…BR-09, BR-19 |
| 8 | System marks the vehicle out | BR-21 |
| 9 | Steps 5, 7 and 8 all succeed, or none of them do | BR-24 |
| 10 | Staff sees the priced receipt | FR-7 |

**Things that can go wrong**

| Situation | What the system does |
|---|---|
| Days is blank or not a number | Refuse, explain, change nothing |
| Days is 0 or negative | Refuse: "Days must be at least 1." |
| Customer name is blank | Refuse: "Customer name is required." |
| Vehicle is already out | Refuse: "Already rented out: C01" |
| Database write fails midway | Roll back; the shop is exactly as it was |

> **Step 5 before step 6 — order matters.** Count the rental *first*, so the
> third rental is the one that earns the discount (BR-12). Do it the other way
> round and the discount lands on the fourth. The program still runs; it is
> just quietly wrong by one, which is the hardest kind of bug to notice.

### Taking a vehicle back

| Step | What happens | Rule |
|---|---|---|
| 1 | Staff selects the rental and enters days actually kept | BR-15 |
| 2 | System refuses if it is already back | BR-18 |
| 3 | System records the actual days | BR-15 |
| 4 | System works out any late penalty | BR-16, BR-17 |
| 5 | System marks the vehicle available | BR-21 |
| 6 | Staff sees the final bill | BR-19 |

---

## 9. The data

### Vehicle

| Field | Type | Notes |
|---|---|---|
| id | text | Chosen by the shop, unique: `C01`, `M02`, `T01` |
| type | text | Car, Motorbike, Truck, Bicycle |
| brand, model | text | "Toyota", "Vios" |
| dailyRate | money | Base price per day |
| available | yes/no | False while out with a customer |
| seats, hasGps | Car only | |
| loadTons | Truck only | |
| engineCc | Motorbike only | |
| gears | Bicycle only | |

### Customer

| Field | Type | Notes |
|---|---|---|
| id | number | Invented by the system (BR-23) |
| name | text | Unique, case-insensitive (BR-10) |
| rentalCount | number | Drives the loyalty discount (BR-11, BR-12) |

### Rental

| Field | Type | Notes |
|---|---|---|
| rentalId | text | `R1`, `R2`, … in order |
| customer | → Customer | Which person |
| vehicle | → Vehicle | Which vehicle |
| days | number | Booked |
| returned | yes/no | |
| actualDays | number | Kept; 0 until returned |
| discountRate | fraction | **Frozen at booking** (BR-14) |

**Notice what a Rental does *not* store: any money.** No subtotal, no total, no
insurance figure. All of it is recalculated from the rules whenever it is
needed, because the rules live in the vehicle classes. Storing the total as
well would create a second version of the truth (NFR-2).

The one exception is `discountRate`, and BR-14 explains why: that one is not a
calculation, it is a *decision the shop made on that day*.

---

## 10. A worked example

Start with an empty system and the six starting vehicles. Then:

1. Sokha rents **C01** (Toyota Vios, $33/day, with GPS) for **3 days**
2. Dara rents **M01** (Honda Dream, $8/day) for **2 days**
3. Sokha rents **M02** (Yamaha NMAX, $12/day) for **1 day**
4. Sokha rents **T01** (Isuzu NPR, $75/day, 3.5 tons) for **2 days**
5. Sokha brings C01 back after **5 days** — two days late

| Rental | Customer | Vehicle | Days | Rental | Insurance | Subtotal | Discount | Late | **Total** |
|---|---|---|---|---|---|---|---|---|---|
| R1 | Sokha | C01 | 3 | 105.00 | 9.90 | 114.90 | 0.00 | 79.20 | **194.10** |
| R2 | Dara | M01 | 2 | 19.00 | 0.00 | 19.00 | 0.00 | 0.00 | **19.00** |
| R3 | Sokha | M02 | 1 | 15.00 | 0.00 | 15.00 | 0.00 | 0.00 | **15.00** |
| R4 | Sokha | T01 | 2 | 185.00 | 42.50 | 227.50 | 22.75 | 0.00 | **204.75** |
| | | | | | | | | **Takings** | **432.85** |

Work through every number by hand before you trust your program:

- **R1 rental** `33 × 3 = 99`, plus GPS `2 × 3 = 6` → `105.00` (BR-02)
- **R1 insurance** `33 × 10% × 3 = 9.90` (BR-07)
- **R1 late** 2 extra days × `33 × 1.20` = `79.20` (BR-17)
- **R2 rental** `8 × 2 = 16`, plus the one-off helmet fee `3.00` → `19.00` (BR-03)
- **R2 insurance** `0.00` — a motorbike is not insurable (BR-06)
- **R3** is Sokha's *second* rental, so still **no discount** (BR-12)
- **R4 rental** `75 × 2 = 150`, plus load `5 × 3.5 × 2 = 35` → `185.00` (BR-04)
- **R4 insurance** `75 × 15% × 2 = 22.50`, plus paperwork `20.00` → `42.50` (BR-08)
- **R4 discount** Sokha's *third* rental, so 10% of `227.50` = `22.75` (BR-12, BR-13)

Notice R1's discount is **0.00** even though Sokha is now a loyal customer.
That is BR-14 doing its job: the rate was frozen when R1 was created.

---

## 11. Why the design looks like this

| Decision | Reason |
|---|---|
| `Vehicle` is abstract | You cannot rent "a vehicle" — only a Car, a Truck, a Motorbike or a Bicycle. A plain Vehicle has no price rule, so it must not be creatable. |
| `Insurable` is an interface, not a field on `Vehicle` | Only some vehicles are insurable (BR-06). A field would force motorbikes to carry something meaningless. |
| `Discountable` is a second interface | It is signed by `Customer`, an unrelated family. Same mechanism, different hierarchy — that is what proves an interface is a contract, not a parent. |
| All four types in one database table | So "list every vehicle" is one query. The extra columns are left empty for the types that do not have them. |
| `discountRate` is stored | BR-14. It is a historical fact, not a calculation. |
| Totals are **not** stored | NFR-2. The rules live in the vehicle classes; a stored copy would drift. |
| Renting is one transaction | BR-24. Chariya's double-booking problem. |
| Four layers (view → controller → dao → model) | NFR-5 and testability. The pricing rules can be checked without opening a window, and the database can be replaced without touching the screens. |

---

## 12. From rule to code

Use this to check you have implemented everything. "given" means it is already
written for you.

| Rule | Where it lives | TODO |
|---|---|---|
| BR-01 minimum 1 day | `RentalController.rentVehicle` | 7.1 |
| BR-02 car pricing | `Car.calculateRentalCost` | given |
| BR-03 motorbike pricing | `Motorbike.calculateRentalCost` | given |
| BR-04 truck pricing | `Truck.calculateRentalCost` | given |
| BR-05 bicycle flat rate | `Bicycle` | given |
| BR-06, BR-09 who is insurable | `Rental.getInsuranceCost`, `getPolicyLabel` | 5.1, 5.2 |
| BR-07 car insurance | `Car.calculateInsurance` | given |
| BR-08 truck insurance | `Truck.calculateInsurance` | given |
| BR-10 one customer per name | `customers.name COLLATE NOCASE UNIQUE`, `CustomerDao.findOrCreate` | given |
| BR-11 count the rental | `Customer.recordRental` + `RentalController` | 4.1, 7.3 |
| BR-12 threshold of 3 | `Customer.qualifiesForDiscount` | 4.2 |
| BR-13 10% off subtotal | `Customer.getDiscountRate`, `Rental.getDiscountAmount` | 4.3, 5.4 |
| BR-14 freeze the rate | `Rental` constructor, `rentals.discount_rate` | given + 3.3, 3.5 |
| BR-15 booked vs kept | `Rental.markReturned` | given |
| BR-16, BR-17 late fee | `Rental.getExtraDays`, `getLateFee` | 5.5, 5.6 |
| BR-18 no double return | `RentalController.returnVehicle` | 7.7 |
| BR-19 total | `Rental.getTotalCost` | 5.7 |
| BR-20 cannot rent what is out | `RentalController.rentVehicle` | 7.2 |
| BR-21 flip availability | `VehicleDao.updateAvailability` | 2.6, 7.5, 7.8 |
| BR-22 protect history | `VehicleDao.delete` | given |
| BR-23 unique vehicle id | `VehicleController.addVehicle` | 6.1 |
| BR-24 all or nothing | `RentalController` transaction | given skeleton |
| BR-25 takings | `ReportController.build` | 8.1 |

---

## 13. Check your understanding

Answer these before you start Step 2. They are the kind of question you will be
asked about your project.

1. A customer books a car for 3 days and brings it back after 2. What do they
   pay, and which rule tells you?
2. Sokha has rented twice. She rents a truck. Does she get the discount?
3. Why is the discount stored on the rental instead of worked out from the
   customer's count each time it is displayed?
4. The shop starts renting **vans**, which are insurable at 12%. List every
   file that has to change. Which files definitely do **not**?
5. Why can a `Motorbike` not be passed to a method that expects an `Insurable`,
   even though a `Truck` can?
6. A rental is saved but the vehicle is not marked as out. Which rule was
   broken, and what mechanism is supposed to prevent it?
7. Why does the system store `days` and `actualDays` separately instead of just
   overwriting `days` on return?
8. Chariya asks for a 5% discount for students, on top of loyalty. Which class
   would you change, and which classes would not need to change at all?

---

## 14. Glossary

| Term | Meaning here |
|---|---|
| **Subtotal** | Rental cost + insurance, before any discount or penalty |
| **Total** | Subtotal − discount + late fee. What the customer pays |
| **Booked days** | What the customer asked for and was priced on |
| **Actual days** | What they really kept it for; only known on return |
| **Loyalty threshold** | 3 rentals — the point the discount switches on |
| **Available** | In the shop right now, rentable |
| **Out** | With a customer on an unreturned rental |
| **Insurable** | Cars and trucks. A contract, not a vehicle type |
| **Surrogate key** | An id the system invents (customer id) as opposed to one the business already uses (vehicle id) |
| **Transaction** | A group of database writes that all succeed or all fail together |

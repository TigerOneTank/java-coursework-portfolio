import java.util.ArrayList;

public class Library {
    private static ArrayList<Book> books;

    public Library() {
        books = new ArrayList<>();
    }

    public static void addBook(Book book) {
        books.add(book);
    }

    public static void displayAllBooks() {
        System.out.println("----------------------------");
        System.out.println("Here are all books");
        for (Book eachBook : books) {
            System.out.println(eachBook);
        }
        System.out.println("----------------------------");
    }
}
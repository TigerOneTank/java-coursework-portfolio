package com.library.service;

import com.library.dao.BookDAO;
import com.library.dao.LoanDAO;
import com.library.dao.MemberDAO;
import com.library.model.Book;
import com.library.model.Loan;
import com.library.model.Member;

import java.util.List;
import java.util.Optional;


public class LibraryService {

    private final BookDAO bookDAO = new BookDAO();
    private final MemberDAO memberDAO = new MemberDAO();
    private final LoanDAO loanDAO = new LoanDAO();

    public List<Book> allBooks() { return bookDAO.findAll(); }
    public List<Book> searchBooks(String kw) { return bookDAO.search(kw); }
    public List<Book> availableBooks() { return bookDAO.findAvailable(); }
    public Optional<Book> findBookById(int id) { return bookDAO.findById(id); }
    public int addBook(Book b) { return bookDAO.insert(b); }
    public void updateBook(Book b) { bookDAO.update(b); }
    public void deleteBook(int id) {
        int outstanding = loanDAO.countOutstandingByBook(id);
        if (outstanding > 0) {
            throw new IllegalStateException(
                    "This book still has " + outstanding + (outstanding == 1 ? " copy" : " copies")
                    + " out on loan. Return it before deleting the book.");
        }
        bookDAO.delete(id);
    }

    // ---- Members ----
    public List<Member> allMembers() { return memberDAO.findAll(); }
    public List<Member> searchMembers(String kw) { return memberDAO.search(kw); }
    public Optional<Member> findMemberById(int id) { return memberDAO.findById(id); }
    public int addMember(Member m) { return memberDAO.insert(m); }
    public void updateMember(Member m) { memberDAO.update(m); }
    public void deleteMember(int id) { memberDAO.delete(id); }

    // ---- Loans ----
    public List<Loan> allLoans() { return loanDAO.findAll(); }
    public List<Loan> activeLoans() { return loanDAO.findActive(); }
    public List<Loan> overdueLoans() { return loanDAO.findOverdue(); }
}

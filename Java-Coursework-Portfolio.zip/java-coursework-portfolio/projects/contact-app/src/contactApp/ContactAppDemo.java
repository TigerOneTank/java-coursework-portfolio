package contactApp;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.TableColumn;
import java.awt.*;
import java.util.List;

public class ContactAppDemo extends JFrame {

    // Widgets
    private JTextField tfName, tfEmail, tfPhone;
    private JButton btnAdd, btnUpdate, btnDelete, btnClear, btnSignOut;
    private JTable table;
    private ContactTableModel tableModel;
    private JLabel lblStatus;

    // Database
    private final ContactManager db;
    private int selectedId = -1;
    private final String username;
    private final int userId;

    // Constructor
    public ContactAppDemo(ContactManager db, int userId, String username) {
        this.db = db;
        this.userId = userId;
        this.username = username;

        setTitle("Contact App");
        setSize(500, 560);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        initUI();
        refreshTable();
        setVisible(true);
    }

    private void initUI() {
        JPanel root = new JPanel(new BorderLayout(8, 8));
        root.setBorder(new EmptyBorder(10, 10, 10, 10));

        root.add(buildTopSection(), BorderLayout.NORTH);
        root.add(buildTableSection(), BorderLayout.CENTER);
        root.add(buildStatusBar(), BorderLayout.SOUTH);

        setContentPane(root);
    }

    private void refreshTable() {
        List<Contact> all = db.getAllContacts(userId);
        tableModel.setContacts(all);
        lblStatus.setText(all.size() + " contact(s)");
    }

    private JPanel buildTopSection() {
        JPanel top = new JPanel(new BorderLayout(0, 4));

        // Title block
        JLabel lblTitle = new JLabel("Contact App");
        lblTitle.setFont(lblTitle.getFont().deriveFont(Font.BOLD, 16f));
        JLabel lblSub = new JLabel("Manage your friend's contact");

        JPanel titlePanel = new JPanel(new GridLayout(2, 1));
        titlePanel.add(lblTitle);
        titlePanel.add(lblSub);
        top.add(titlePanel, BorderLayout.NORTH);

        // Form inside a titled border
        JPanel formCard = new JPanel(new GridBagLayout());
        formCard.setBorder(BorderFactory.createTitledBorder("Contact Detail"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 6, 4, 6);
        gbc.anchor = GridBagConstraints.WEST;

        // Row 0 – Fullname
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.NONE;
        gbc.weightx = 0;
        formCard.add(new JLabel("Fullname"), gbc);

        tfName = new JTextField(28);
        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;
        formCard.add(tfName, gbc);

        // Row 1 – Email
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.fill = GridBagConstraints.NONE;
        gbc.weightx = 0;
        formCard.add(new JLabel("Email"), gbc);

        tfEmail = new JTextField(28);
        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;
        formCard.add(tfEmail, gbc);

        // Row 2 – Phone number
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.fill = GridBagConstraints.NONE;
        gbc.weightx = 0;
        formCard.add(new JLabel("Phone number"), gbc);

        tfPhone = new JTextField(28);
        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;
        formCard.add(tfPhone, gbc);

        // Row 3 – Buttons
        btnAdd = new JButton("Add");
        btnUpdate = new JButton("Update");
        btnDelete = new JButton("Delete");
        btnClear = new JButton("Clear");
        btnSignOut = new JButton("Sign Out");
        btnUpdate.setEnabled(false);
        btnDelete.setEnabled(false);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        btnPanel.add(btnAdd);
        btnPanel.add(btnUpdate);
        btnPanel.add(btnDelete);
        btnPanel.add(btnClear);
        btnPanel.add(btnSignOut);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;
        gbc.insets = new Insets(8, 2, 4, 6);
        formCard.add(btnPanel, gbc);

        top.add(formCard, BorderLayout.CENTER);

        btnAdd.addActionListener(e -> addContact());
        btnClear.addActionListener(e -> clearForm());
        btnUpdate.addActionListener(e -> updateRecord());
        btnDelete.addActionListener(e -> deleteRecord());
        btnSignOut.addActionListener(e -> signOut());


        return top;
    }

    private void signOut() {
        dispose();
        new WelcomeScreen(db);
    }

    private void updateRecord() {
        if (selectedId < 0) {
            showError("Please Select A Contact To Update");
            return;
        }
        Contact contact = new Contact(selectedId, tfName.getText(), tfEmail.getText(), tfPhone.getText());
        if (db.updateContact(contact)) {
            lblStatus.setText(contact.getName() + " 's contact is updated.");
            clearForm();
            refreshTable();
        } else {
            lblStatus.setText("Fail to update the contact.");
        }
    }

    private void deleteRecord() {
        if (selectedId < 0) {
            showError("Select a contact to update");
            return;
        }

        String name = tfName.getText();
        int confirm = JOptionPane.showConfirmDialog(this, "Delete contact " + name + "?", "Confirm Delete", JOptionPane.YES_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            if (db.deleteContact(selectedId)) {
                lblStatus.setText("Contact is deleted");
                clearForm();
                refreshTable();
            } else {
                lblStatus.setText("Failed to delete");
            }
        }
    }

    private void addContact() {
        String name = tfName.getText();
        String email = tfEmail.getText();
        String phone = tfPhone.getText();

        Contact newContact = new Contact(name, email, phone);

        if (db.addContact(newContact, userId)) {
            lblStatus.setText("Contact added: " + newContact.getName());
            clearForm();
            refreshTable();
        } else {
            lblStatus.setText("Failed to add new contact.");
        }
    }

    private JScrollPane buildTableSection() {
        tableModel = new ContactTableModel();
        table = new JTable(tableModel) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };

        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getTableHeader().setReorderingAllowed(false);

        setColumnWidth(table, 0, 40, 40, 40);
        setColumnWidth(table, 1, 120, 120, 160);
        setColumnWidth(table, 2, 160, 160, 200);
        setColumnWidth(table, 3, 110, 110, 150);

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) populateForm();
        });

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        return scroll;
    }

    private JLabel buildStatusBar() {
        lblStatus = new JLabel(" ");
        return lblStatus;
    }

    private static void setColumnWidth(JTable t, int col, int min, int pref, int max) {
        TableColumn tc = t.getColumnModel().getColumn(col);
        tc.setMinWidth(min);
        tc.setPreferredWidth(pref);
        tc.setMaxWidth(max);
    }

    private void populateForm() {
        // Logic for filling fields when a table row is selected
        int row = table.getSelectedRow();
        if (row < 0) return;
        Contact selected = tableModel.getContactAt(row);
        selectedId = selected.getId();
        System.out.println(selected);
        System.out.println(selectedId);
        tfName.setText(selected.getName());
        tfEmail.setText(selected.getEmail());
        tfPhone.setText(selected.getPhone());

        btnUpdate.setEnabled(true);
        btnDelete.setEnabled(true);
        btnAdd.setEnabled(false);

    }

    private void clearForm() {
        selectedId = -1;
        tfName.setText("");
        tfEmail.setText("");
        tfPhone.setText("");
        table.clearSelection();
        btnAdd.setEnabled(true);
        btnUpdate.setEnabled(false);
        btnDelete.setEnabled(false);
    }

    private void showError(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }

//    public static void main(String[] args) {
//        new ContactAppDemo();
//    }
}
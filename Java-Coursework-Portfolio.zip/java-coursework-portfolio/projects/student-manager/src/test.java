

public class test {

    static void drawCircle(int xPos, int yPos, int rad) {
        System.out.println("Drawing circle at (" + xPos + ", " + yPos + ") with radius " + rad);
    }

    public static void main(String[] args) {

        int x = 2;
        int y = 2;
        int r = 1;

        // Top left circle
        drawCircle(x, y + 3, r);

        // Top right circle
        drawCircle(x + 3, y + 3, r);

        // Bottom left circle
        drawCircle(x, y, r);

        // Bottom right circle
        drawCircle(x + 3, y, r);
    }

}

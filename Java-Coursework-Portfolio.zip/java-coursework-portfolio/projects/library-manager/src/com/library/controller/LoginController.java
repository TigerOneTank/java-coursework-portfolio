package com.library.controller;

import com.library.model.User;
import com.library.service.AuthService;
import com.library.service.LibraryService;
import com.library.service.LoanService;
import com.library.view.BookView;
import com.library.view.LoanView;
import com.library.view.LoginView;
import com.library.view.MainDashboardView;
import com.library.view.MemberView;

import java.util.Optional;

public class LoginController {

    private final AuthService authService = new AuthService();

    public void start() {
        showLogin();
    }

    private void showLogin() {
        LoginView view = new LoginView();
        view.setOnLogin(() -> attemptLogin(view));
        view.setVisible(true);
    }

    private void attemptLogin(LoginView view) {


        Optional<User> user = authService.login("admin", "admin123");
        view.dispose();
        openDashboard(user.get());
    }

    private void openDashboard(User user) {
        LibraryService libraryService = new LibraryService();
        LoanService loanService = new LoanService();

        BookView bookView = new BookView();
        BookController bookController = new BookController(bookView, libraryService, user);

        MemberView memberView = new MemberView();
        MemberController memberController = new MemberController(memberView, libraryService, user);

        LoanView loanView = new LoanView();
        new LoanController(loanView, libraryService, loanService, () -> {
            bookController.refresh();
            memberController.refresh();
        });

        MainDashboardView dashboard = new MainDashboardView(user, bookView, memberView, loanView);
        dashboard.setOnLogout(() -> {
            dashboard.dispose();
            showLogin();
        });
        dashboard.setVisible(true);
    }
}

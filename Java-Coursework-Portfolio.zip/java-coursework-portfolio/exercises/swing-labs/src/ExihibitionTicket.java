import javax.swing.*;
import java.awt.*;
import java.sql.Time;

public class ExihibitionTicket extends JFrame {

    public ExihibitionTicket() {
        setTitle("Exhibition Ticket");
        setSize(500, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        
//        This demonstrates that the code will be reevaluated further to prove that it's not an anomaly or simply an common error that can be fixed easily.
//        If this issue remains present after the technician attempted to fix the code, then Code-Bravo-8 Will be set...
        JPanel topBar = new JPanel();
        topBar.setBackground(new Color(0, 0, 255));
        topBar.setPreferredSize(new Dimension(500, 25));
        add(topBar, BorderLayout.NORTH);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        JLabel instruction = new JLabel("Please input your details");
        mainPanel.add(instruction);

        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridLayout(2, 2, 10, 10));
        formPanel.add(new JLabel("Fullname"));
        JTextField fullname = new JTextField();
        formPanel.add(fullname);

        formPanel.add(new JLabel("Phone Number"));
        JTextField phoneNumber = new JTextField();
        formPanel.add(phoneNumber);

        JPanel timePanel = new JPanel();
        JRadioButton t1 = new JRadioButton("08:00-11:00");
        JRadioButton t2 = new JRadioButton("13:00-16:00");
        JRadioButton t3 = new JRadioButton("18:00-21:00");


        t1.setActionCommand(t1.getText());
        t2.setActionCommand(t2.getText());
        t3.setActionCommand(t3.getText());
        timePanel.add(t1); timePanel.add(t2); timePanel.add(t3);
        ButtonGroup group = new ButtonGroup();
        group.add(t1); group.add(t2); group.add(t3);

        JPanel ticketPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        ticketPanel.add(new JLabel("Number Of Tickets"));
        JSpinner spinner = new JSpinner(new SpinnerNumberModel(1,1,1,1));
        spinner.setPreferredSize(new Dimension(300,25));
        ticketPanel.add(spinner);

        JProgressBar progressBar = new JProgressBar(0,100);
        progressBar.setVisible(false);
        progressBar.setBorderPainted(true);
        progressBar.setStringPainted(true);

        JButton submitBtn = new JButton("SUBMIT");

        mainPanel.add(formPanel);
        mainPanel.add(timePanel);
        mainPanel.add(ticketPanel);
        mainPanel.add(new JLabel("Price per Ticket: 15$"));
        mainPanel.add(progressBar);
        mainPanel.add(submitBtn);

        add(mainPanel, BorderLayout.CENTER);

        submitBtn.addActionListener( e -> {
            submitBtn.setEnabled(false);
            progressBar.setVisible(true);
            progressBar.setValue(0);

            Timer timer = new Timer(20, null);
            timer.addActionListener( evt -> {
                int val = progressBar.getValue();
                if (val < 100) {
                    progressBar.setValue(val + 1);
                } else {
                    timer.stop();
                    submitBtn.setEnabled(true);
                    progressBar.setVisible(false);

                    String selectedTime = group.getSelection().getActionCommand();
                    String name = fullname.getText();
                    String phone = phoneNumber.getText();
                    int numberOfTickets = (int) spinner.getValue();
                    int total = numberOfTickets * 15;

                    JOptionPane.showMessageDialog(this,
                            "Exhibition Tickets" +
                                    "\nFullname: " + name +
                                    "\nPhone Number: " + phone +
                                    "\nShowtime: " + selectedTime +
                                    "\nTotal: $" + total);
                }
            });
            timer.start();
        });
    }

    public static void main(String[] args) {
        new ExihibitionTicket().setVisible(true);
    }

}

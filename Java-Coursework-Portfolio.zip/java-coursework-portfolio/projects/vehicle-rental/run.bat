@echo off
set JAVA_HOME=C:\Users\U-ser\.jdks\openjdk-24.0.1
set JAVAC=%JAVA_HOME%\bin\javac.exe
set JAVA=%JAVA_HOME%\bin\java.exe

if not exist "%JAVAC%" set JAVAC=javac
if not exist "%JAVA%" set JAVA=java

cd /d "%~dp0"

if not exist "out" mkdir out

echo Compiling Vehicle Rental App...
dir /s /b src\*.java > sources.txt
"%JAVAC%" -cp "lib\sqlite-jdbc-3.51.1.0.jar;sqlite-jdbc-3.51.1.0.jar" -d out @sources.txt
del sources.txt

if %ERRORLEVEL% equ 0 (
    echo Starting Vehicle Rental App...
    "%JAVA%" -cp "out;lib\sqlite-jdbc-3.51.1.0.jar;sqlite-jdbc-3.51.1.0.jar" VehicleRentalApp.App
) else (
    echo Compilation failed.
    pause
)
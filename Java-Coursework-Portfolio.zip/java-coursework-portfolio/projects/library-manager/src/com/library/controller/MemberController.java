package com.library.controller;

import com.library.model.Member;
import com.library.model.MemberStatus;
import com.library.model.User;
import com.library.service.LibraryService;
import com.library.view.MemberView;

import java.time.LocalDate;

public class MemberController {

    private final MemberView view;
    private final LibraryService service;
    private final User currentUser;

    public MemberController(MemberView view, LibraryService service, User currentUser) {
        this.view = view;
        this.service = service;
        this.currentUser = currentUser;

        view.setOnSearch(this::search);
        view.setOnRefresh(this::refresh);
        view.setOnAdd(this::addMember);
        view.setOnDelete(this::deleteMember);
        view.setOnUpdate(this::updateMember);


        refresh();
    }

    public void refresh() {
        view.populate(service.allMembers());
    }

    private void search() {
        String kw = view.getSearchText();
        view.populate(
                kw.isEmpty() ? service.allMembers() : service.searchMembers(kw)
        );
    }

    private void addMember() {
        try {
            String name = view.getNameText();
            String email = view.getEmailText();
            LocalDate dateJoined = LocalDate.now();
            MemberStatus status = view.getStatusSelection();
            Member m = new Member(0, name, email, dateJoined, status, 0);
            service.addMember(m);
            view.showInfo("New member is added");
            refresh();
        } catch (RuntimeException e) {
            view.showError(e.getMessage());
        }
    }

    private void updateMember() {
        if (!view.hasSelection()) {
            view.showWarning("Select a member to delete.");
            return;
        }

        try {
            int id = view.getSelectedId();
            String name = view.getNameText();
            String email = view.getEmailText();
            LocalDate dateJoined = LocalDate.parse(view.getSelectedJoinedDate());
            MemberStatus status = view.getStatusSelection();
            Member m = new Member(id, name, email, dateJoined, status, 0);
            service.updateMember(m);
            view.showInfo("Member is updated");
            refresh();
        } catch (RuntimeException e) {
            view.showError(e.getMessage());
        }
    }

    private void deleteMember() {
        if (!view.hasSelection()) {
            view.showWarning("Select a member to delete.");
            return;
        }
        int id = view.getSelectedId();
        int borrowed = view.getSelectedBorrowedCount();
        if (borrowed > 0) {
            view.showWarning("This member still has borrowed books to return.");
            return;
        }
        if (!view.confirmDelete(id)) return;
        try {
            service.deleteMember(id);
            view.showInfo("Member is deleted");
            refresh();
        } catch (RuntimeException e) {
            view.showError(e.getMessage());
        }
    }

    // ---- validation helpers ----

    private static String requireText(String raw, String label) {
        String v = raw == null ? "" : raw.trim();
        if (v.isEmpty()) throw new ValidationException(label + " is required.");
        return v;
    }

    private static void validateEmail(String email) {
        if (email != null && !email.matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$")) {
            throw new ValidationException("Email format looks invalid.");
        }
    }

    private static String blankToNull(String s) {
        s = s == null ? null : s.trim();
        return (s == null || s.isEmpty()) ? null : s;
    }

    private static final class ValidationException extends RuntimeException {
        ValidationException(String message) { super(message); }
    }
}

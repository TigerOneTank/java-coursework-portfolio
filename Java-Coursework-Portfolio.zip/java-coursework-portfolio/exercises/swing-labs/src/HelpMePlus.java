import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class HelpMePlus extends JFrame{
    private JPanel panel1;
    private JTextField num1field;
    private JTextField num2field;
    private JButton equalBtn;
    private JLabel titleLabel;
    private JLabel introlabel;
    private JLabel plusLabel;
    private JLabel resultLabel;

    public HelpMePlus() {
        setTitle("HELP ME PLUS");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(panel1);
        setLocationRelativeTo(null);
        setVisible(true);
        pack();
        equalBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                plus();
            }
        });
    }

    private void plus() {
        int num1 = Integer.parseInt(num1field.getText());
        int num2 = Integer.parseInt(num1field.getText());
        int result = num1 + num2;
        resultLabel.setText(String.valueOf(result));
        num1field.setText("");
        num2field.setText("");

    }
}

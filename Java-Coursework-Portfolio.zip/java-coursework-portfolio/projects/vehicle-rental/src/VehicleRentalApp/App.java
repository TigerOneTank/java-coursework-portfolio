package VehicleRentalApp;

import VehicleRentalApp.dao.Database;
import VehicleRentalApp.view.MainFrame;
import VehicleRentalApp.view.Theme;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import java.sql.SQLException;

/**
 * Entry point.
 *
 * Three steps, in this order:
 *   1. install the black and white theme  (must happen before any window exists)
 *   2. open the database and build the schema (fails loudly, not silently)
 *   3. hand over to Swing's event dispatch thread and show the window
 *
 * Run it from the VehicleRentalApp folder so that data/rental.db lands next to
 * the source rather than wherever the IDE happened to be pointing.
 */
public class App {

    public static void main(String[] args) {
        Theme.install();

        try {
            Database.init();
        } catch (SQLException e) {
            // no database means no app -- say so plainly and stop
            JOptionPane.showMessageDialog(null,
                    "Could not open the database (" + Database.DB_FILE + ").\n\n"
                            + e.getMessage(),
                    "Vehicle Rental Shop", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // every Swing component must be created and touched on the EDT
        SwingUtilities.invokeLater(() -> {
            MainFrame frame = new MainFrame();
            frame.setVisible(true);
            frame.loadInitialData();
        });
    }
}

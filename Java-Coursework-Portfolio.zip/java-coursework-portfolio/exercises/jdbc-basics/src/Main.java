import java.sql.DriverManager;
import java.sql.SQLException;

public class Main {
    public static void main(String[] args) {

        var url = "jdbc:sqlite:java_db.db";

        try (var conn = DriverManager.getConnection(url)) {
//            System.out.println("New Database is created.");
            if (conn != null) {
                var meta = conn.getMetaData();
                System.out.println(meta.getDatabaseProductName());
                System.out.println(meta.getDriverVersion());
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}

//SQLITE, MYSQL, Postgres, Server
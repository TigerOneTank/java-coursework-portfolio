package com.library.controller;

import com.library.model.Book;
import com.library.model.User;
import com.library.service.LibraryService;
import com.library.view.BookView;

/** Wires BookView's events to LibraryService calls; owns validation for the Books tab. */
public class BookController {

    private final BookView view;
    private final LibraryService service;
    private final User currentUser;


    public BookController(BookView view, LibraryService service, User currentUser) {
        this.view = view;
        this.service = service;
        this.currentUser = currentUser;

        view.setOnRefresh(this::refresh);
        view.setOnSearch(this::search);
        view.setOnAdd(this::addBook);
        view.setOnDelete(this::deleteBook);
        view.setOnUpdate(this::updateBook);


        refresh();
    }

    public void refresh() {
        view.populate(service.allBooks());
    }

    private void search() {
        String kw = view.getSearchText();
        view.populate(
                kw.isEmpty() ? service.allBooks() : service.searchBooks(kw)
        );
    }

    private void addBook() {
        try {
            String title = requireText(view.getTitleText(), "");
            String author = view.getAuthorText();
            String isbn = view.getIsbnText();
            String category = view.getCategoryText();
            int total = parsePositiveInt(view.getTotalCopiesText(), "");
            Book book = new Book(0, title, author, isbn, category, total, total);

            service.addBook(book);
            view.showInfo("Book added.");
            refresh();
        } catch (RuntimeException e ) {
            view.showError("Book cannot add." + e.getMessage());
        }
    }

    private void updateBook() {
        if (!view.hasSelection()) {
            view.showWarning("Select a book to update.");
            return;
        }

        try {
            int id = view.getSelectedId();
            int available = view.getSelectedAvailable();
            int oldTotal = view.getSelectedTotal();
            int newTotal = parsePositiveInt(view.getTotalCopiesText(), "Total Copies");
            int newAvailable = available + (newTotal - oldTotal);

            Book book = new Book(id, view.getTitleText(), view.getAuthorText(), view.getIsbnText(), view.getCategoryText(), newAvailable, newTotal);

            service.updateBook(book);
            view.showInfo("Book updated");
            refresh();
        } catch (ValidationException ve) {
            view.showWarning(ve.getMessage());
        } catch (RuntimeException e) {
            view.showError(e.getMessage());
        }
    }


    private void deleteBook() {
//        Limit the role (Policy)
        if (!currentUser.isAdmin()) {
            view.showWarning("Only an Admin can delete books");
            return;
        }

        if (!view.hasSelection()) {
            view.showWarning("Select a book to delete");
            return;
        }

        int id = view.getSelectedId();
        if (!view.confirmDelete(id)) return;

        try {
            service.deleteBook(id);
            view.showInfo("Book Is Deleted");
            refresh();

        } catch (IllegalStateException ise) {
            view.showWarning(ise.getMessage());
        } catch (RuntimeException e) {
            view.showError("Could not delete the book" + e.getMessage());
        }
    }

    // ---- validation helpers ----

    private static String requireText(String raw, String label) {
        String v = raw == null ? "" : raw.trim();
        if (v.isEmpty()) throw new ValidationException(label + " is required.");
        return v;
    }

    private static int parsePositiveInt(String raw, String label) {
        try {
            int v = Integer.parseInt(raw.trim());
            if (v <= 0) throw new ValidationException(label + " must be greater than 0.");
            return v;
        } catch (NumberFormatException e) {
            throw new ValidationException(label + " must be a number.");
        }
    }

    private static String blankToNull(String s) {
        s = s == null ? null : s.trim();
        return (s == null || s.isEmpty()) ? null : s;
    }

    /** Thrown on invalid form input. */
    private static final class ValidationException extends RuntimeException {
        ValidationException(String message) { super(message); }
    }
}

package VehicleRentalApp.dao;

import VehicleRentalApp.model.Customer;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/*
 * CustomerDao.java  -- FULLY COMPLETED EXAMPLE  (Step 1: read this carefully)
 *
 * Do NOT change this file. It is your model for VehicleDao and RentalDao,
 * exactly the way Car.java was your model for Truck.java.
 *
 * WHAT IS A DAO?
 * Data Access Object. Its only job is to translate between two worlds:
 *
 *      rows in a table   <---- DAO ---->   objects in memory
 *
 * The rule that makes the whole project hang together:
 * SQL lives HERE and nowhere else. No controller and no Swing panel is ever
 * allowed to contain the word SELECT. Swap SQLite for MySQL next term and
 * only this package changes.
 *
 * FOUR HABITS TO COPY FROM THIS FILE
 *
 *  1. PreparedStatement with ? placeholders -- never glue values into SQL
 *     with +. Doing that breaks the moment a customer is called O'Brien, and
 *     it is how SQL injection attacks work.
 *
 *  2. try-with-resources: try (PreparedStatement ps = ...) closes the
 *     statement automatically, even when something throws. A DAO that leaks
 *     statements will lock the database file eventually.
 *
 *  3. One private map(ResultSet) method. Every query funnels through it, so
 *     the "row -> object" rule is written once. When a column is renamed you
 *     fix one line.
 *
 *  4. Let SQLException escape. A DAO does not know whether the caller is a
 *     Swing window or a test, so it must not decide how the error is shown.
 *     Deciding is the view's job.
 */
public class CustomerDao {

    /** Everything in the table, sorted by name. */
    public List<Customer> findAll() throws SQLException {
        List<Customer> list = new ArrayList<>();
        String sql = "SELECT id, name, rental_count FROM customers ORDER BY name";
        try (PreparedStatement ps = Database.getConnection().prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {          // rs starts BEFORE the first row
                list.add(map(rs));
            }
        }
        return list;
    }

    /** One customer, or null when nobody by that name has rented yet. */
    public Customer findByName(String name) throws SQLException {
        // the column is COLLATE NOCASE, so "sokha" finds "Sokha" for free --
        // the database enforces the rule, not a lowercase() call in Java
        String sql = "SELECT id, name, rental_count FROM customers WHERE name = ?";
        try (PreparedStatement ps = Database.getConnection().prepareStatement(sql)) {
            ps.setString(1, name);       // parameters are numbered from 1, not 0
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }

    public Customer findById(int id) throws SQLException {
        String sql = "SELECT id, name, rental_count FROM customers WHERE id = ?";
        try (PreparedStatement ps = Database.getConnection().prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }

    /**
     * Seen before -> reuse the row. First visit -> create one.
     * This is what lets the shop count how many times somebody has rented.
     */
    public Customer findOrCreate(String name) throws SQLException {
        Customer existing = findByName(name);
        if (existing != null) {
            return existing;
        }
        Customer fresh = new Customer(name);
        insert(fresh);
        return fresh;
    }

    /**
     * Inserts and writes the generated key BACK into the object.
     *
     * A new Customer has id 0 because only the database can hand out ids.
     * RETURN_GENERATED_KEYS asks SQLite what number it chose, and setId()
     * puts it into the object -- otherwise RentalDao would have nothing to
     * store in rentals.customer_id.
     */
    public void insert(Customer c) throws SQLException {
        String sql = "INSERT INTO customers (name, rental_count) VALUES (?, ?)";
        try (PreparedStatement ps = Database.getConnection()
                .prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, c.getName());
            ps.setInt(2, c.getRentalCount());
            ps.executeUpdate();          // executeUpdate for INSERT/UPDATE/DELETE
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    c.setId(keys.getInt(1));
                }
            }
        }
    }

    /** Saves the loyalty counter after a rental. */
    public void updateRentalCount(Customer c) throws SQLException {
        try (PreparedStatement ps = Database.getConnection()
                .prepareStatement("UPDATE customers SET rental_count = ? WHERE id = ?")) {
            ps.setInt(1, c.getRentalCount());
            ps.setInt(2, c.getId());
            ps.executeUpdate();
        }
    }

    /**
     * Counting is one job SQL really is better at than a Java loop: the
     * database returns a single number instead of shipping every row across
     * so that Java can throw most of them away.
     */
    public int countLoyal() throws SQLException {
        String sql = "SELECT COUNT(*) FROM customers WHERE rental_count >= ?";
        try (PreparedStatement ps = Database.getConnection().prepareStatement(sql)) {
            ps.setInt(1, Customer.LOYALTY_THRESHOLD);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        }
    }

    /** The one place that knows how a customers row becomes a Customer. */
    private Customer map(ResultSet rs) throws SQLException {
        return new Customer(rs.getInt("id"), rs.getString("name"), rs.getInt("rental_count"));
    }
}

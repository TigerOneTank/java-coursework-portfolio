package VehicleRentalApp.controller;

import VehicleRentalApp.dao.VehicleDao;
import VehicleRentalApp.model.Insurable;
import VehicleRentalApp.model.Vehicle;

import java.sql.SQLException;
import java.util.List;

/*
 * VehicleController.java  -- YOUR TASK  (Step 6)
 *
 * Connects the view (VehiclePanel, AddVehicleDialog) to the DAO.
 *
 * Notice the shape of this class:
 *   - the find methods (listAll, listAvailable, find) do not contain SQL.
 *     They call vehicleDao, which does.
 *   - addVehicle() DOES contain validation, because validation is a business
 *     rule, not a database rule.
 *
 * A controller's job is not to do work -- it is to DECIDE WHAT WORK TO DO,
 * and then delegate to the models and DAOs.
 */
public class VehicleController {

    private final VehicleDao vehicleDao = new VehicleDao();

    // ---- GIVEN: reading --------------------------------------------------

    public List<Vehicle> listAll() throws SQLException {
        return vehicleDao.findAll();
    }

    public List<Vehicle> listAvailable() throws SQLException {
        return vehicleDao.findAvailable();
    }

    public List<Vehicle> listSortedByRate() throws SQLException {
        return vehicleDao.findAllSortedByRate();
    }

    public Vehicle find(String id) throws SQLException {
        return vehicleDao.findById(id);
    }

    /** GIVEN: false when the vehicle still has rental history. */
    public boolean deleteVehicle(String id) throws SQLException {
        return vehicleDao.delete(id);
    }

    // ---- YOUR TASK -------------------------------------------------------

    /**
     * Saves a new vehicle, but only if it makes sense.
     *
     * @throws IllegalArgumentException with a message the user will read
     */
    public void addVehicle(Vehicle v) throws SQLException, IllegalArgumentException {
        /*
         * TODO 6.1: reject bad data before it reaches the database.
         *
         *   - id null or blank        -> "Vehicle ID cannot be empty."
         *   - brand or model blank    -> "Brand and model cannot be empty."
         *   - dailyRate <= 0          -> "Daily rate must be greater than zero."
         *   - vehicleDao.exists(id)   -> "Vehicle ID " + id + " is already taken."
         *
         * Throw IllegalArgumentException with those exact messages -- the
         * dialog in AddVehicleDialog prints e.getMessage() straight to the
         * user, so the message IS the user interface.
         *
         * WHY HERE AND NOT IN THE DIALOG?
         * Because a second view -- a web page, a REST call, a test -- would
         * have to repeat every rule. Validation belongs to the layer that
         * owns the rules, not to the layer that draws the text boxes.
         *
         * Use String.isBlank(): it catches "   " as well as "", which
         * isEmpty() does not.
         */

        if (v == null || v.getId() == null || v.getId().isBlank()) {
            throw new IllegalArgumentException("Vehicle ID cannot be empty.");
        }
        if (v.getBrand() == null || v.getBrand().isBlank() || v.getModel() == null || v.getModel().isBlank()) {
            throw new IllegalArgumentException("Brand and model cannot be empty.");
        }
        if (v.getDailyRate() <= 0) {
            throw new IllegalArgumentException("Daily rate must be greater than zero.");
        }
        if (vehicleDao.exists(v.getId())) {
            throw new IllegalArgumentException("Vehicle ID " + v.getId() + " is already taken.");
        }

        // TODO 6.2: once the checks pass, vehicleDao.insert(v);
        vehicleDao.insert(v);
    }

    /** How many vehicles in the fleet can be insured. Used by the Report tab. */
    public int countInsurable() throws SQLException {
        /*
         * TODO 6.3: loop over vehicleDao.findAll() and count the ones that
         * signed the Insurable contract:
         *
         *      if (v instanceof Insurable) { count++; }
         *
         * Again: ask about the CONTRACT, never "instanceof Car || instanceof
         * Truck". Add an insurable Bus next term and this method keeps working
         * without being touched.
         */

        int count = 0;
        for (Vehicle vehicle : vehicleDao.findAll()) {
            if (vehicle instanceof Insurable) {
                count++;
            }
        }
        return count;
    }
}

package contactApp;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ContactManager {
    private static final String DB_URL = "jdbc:sqlite:contacts2.db";
    private Connection connection;

    public ContactManager() {
        connect();
        createTable();

    }

    private void connect() {
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection(DB_URL);
            System.out.println("Database is connected.");

            try (Statement stmt = connection.createStatement()){
                stmt.execute("PRAGMA foreign_keys=ON");
            }
        } catch (ClassNotFoundException e) {
            System.out.println("SQLITE Driver is not found");
        } catch (SQLException e) {
            System.err.println("Connection failed " + e.getMessage());
        }
    }

    private void createTable() {
        String usersTable = """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE   ,
                password TEXT NOT NULL
            );
            """;

        String contactsTable = """
            CREATE TABLE IF NOT EXISTS contacts (
                id      INTEGER PRIMARY KEY AUTOINCREMENT,
                name    TEXT    NOT NULL,
                email   TEXT    NOT NULL,
                phone   TEXT    NOT NULL,
                user_id INTEGER NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users(id)
            );
            """;
        try (Statement stmt = connection.createStatement()) {
            stmt.execute(usersTable);
            stmt.execute(contactsTable);
        } catch (SQLException e) {
            System.err.println("Could not create table " + e.getMessage());
        }
    }

    public int signUp(String username, String password) {
        String sql = "INSERT INTO users (username, password) VALUES (?, ?)";
        try (PreparedStatement pst = connection.prepareStatement(sql)) {
            pst.setString(1, username);
            pst.setString(2, password);
            pst.executeUpdate();

            try (Statement st = connection.createStatement()) {
                ResultSet rs = st.executeQuery("SELECT last_insert_rowid()");
                return rs.next() ? rs.getInt(1) : -1;
            }

        } catch (SQLException e) {
            System.err.println("Could not create new record." + e.getMessage());
            return -1;
        }
    }

    public int signIn(String username, String password) {
        String sql = "SELECT * FROM users WHERE username = ? AND password = ?";

        try (PreparedStatement pst = connection.prepareStatement(sql)) {
            pst.setString(1, username);
            pst.setString(2,    password);
            ResultSet rs = pst.executeQuery();
            return rs.next() ? rs.getInt("id") : -1;
        } catch (SQLException e) {
            System.err.println("Could not create new record." + e.getMessage());
            return -1;
        }
    }

    boolean addContact(Contact contact, int user_id) {
        String sql = "INSERT INTO contacts (user_id,name, email, phone) VALUES (?, ?, ?,?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, user_id);
            pstmt.setString(2, contact.getName());
            pstmt.setString(3, contact.getEmail());
            pstmt.setString(4, contact.getPhone());
            pstmt.executeUpdate();
            System.out.println("New Current is Added");
            return true;
        } catch (SQLException e) {
            System.err.println("Failed to add contact. " + e.getMessage());
            return false;
        }
    }

    public List<Contact> getAllContacts(int user_id) {
        List<Contact> contacts = new ArrayList<>();
        String sql = "SELECT * FROM contacts WHERE user_id = ? ORDER BY name ASC";
//        try (Statement stmt = connection.createStatement()) {
//            ResultSet rs = stmt.executeQuery(sql);
        try (PreparedStatement pst = connection.prepareStatement(sql)) {
            pst.setInt(1, user_id);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                Contact newContact = new Contact(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getString("phone")
                );
                contacts.add(newContact);
            }
        } catch (SQLException e) {
            System.err.println("Cannot fetch the contacts data. " + e.getMessage());
        }

        return contacts;
    }

    public List<Contact> searchContacts(String keyword) {
        List<Contact> contacts = new ArrayList<>();
        String sql = "SELECT * FROM contacts WHERE name LIKE ? OR email LIKE ? OR phone LIKE ? ORDER BY name ASC";
        try (PreparedStatement pstm = connection.prepareStatement(sql)) {
            String pattern = "%" + keyword + "%";
            pstm.setString(1, pattern);
            pstm.setString(2, pattern);
            pstm.setString(3, pattern);
            ResultSet rs = pstm.executeQuery();
            while (rs.next()) {
                contacts.add(new Contact(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getString("phone")
                ));
            }

        } catch (SQLException e) {
            System.err.println("Search failed " + e.getMessage());
        }

        return contacts;
    }

    public boolean updateContact(Contact contact) {
        String sql = "UPDATE contacts SET name = ?, email = ?, phone = ? WHERE id = ?";
        try (PreparedStatement psmt = connection.prepareStatement(sql)) {
            psmt.setString(1, contact.getName());
            psmt.setString(2, contact.getEmail());
            psmt.setString(3, contact.getPhone());
            psmt.setInt(4, contact.getId());
            psmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("Update contact failed. " + e.getMessage());
            return false;
        }
    }

    public boolean deleteContact(int id) {
        String sql = "DELETE FROM contacts WHERE id = ?";
        try (PreparedStatement psmt = connection.prepareStatement(sql)) {
            psmt.setInt(1, id);
            psmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("Delete contact failed. " + e.getMessage());
            return false;
        }
    }
}
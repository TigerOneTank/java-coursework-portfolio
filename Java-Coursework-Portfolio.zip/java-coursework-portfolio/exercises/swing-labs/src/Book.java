public class Book {
    private String title;
    private boolean isTaken;
    private Author author;
    private Genre genre;

    public Book(String title, Author author, Genre genre) {
        this.title = title;
        this.isTaken = false;
        this.author = author;
        this.genre = genre;
    }

    public String getTitle() { return title; }
    public boolean isTaken() { return isTaken; }
    public Author getAuthor() { return author; }
    public Genre getGenre() { return genre; }

    public void setTitle(String title) {
        this.title = title;
    }
    public void setTaken(boolean taken) { isTaken = taken; }
    public void setAuthor(Author author) { this.author = author; }
    public void setGenre(Genre genre) { this.genre = genre; }

    @Override
    public String toString() {
        String text = (isTaken) ? "Yes" : "No";
        return "Book{" +
                "title='" + title + '\'' +
                ", Is Available? = " + text +
                ", author=" + author +
                ", genre=" + genre +
                '}';
    }
}
package Week4;

import java.util.ArrayList;
import java.util.Map;
import java.util.TreeMap;

public class Leaderboard {
    public static void main(String[] args) {
        TreeMap<Integer, ArrayList<String>> board = new TreeMap<>();

        addScore(board, 95, "Jane");
        addScore(board, 95, "John");
        addScore(board, 88, "Bob");
        addScore(board, 82, "Ronaldo");
        addScore(board, 82, "Messi");
        addScore(board, 77, "Mbappe");

        int rank = 1;

        for (Map.Entry<Integer, ArrayList<String>> entry : board.descendingMap().entrySet()) {
            int score = entry.getKey();
            ArrayList<String> name = entry.getValue();

            System.out.println("#" + rank + " " + score + " pts " + name);

            rank += name.size();
        }

    }

    public static void addScore(TreeMap<Integer, ArrayList<String>> board, int score, String name) {
        if (!board.containsKey(score)) {
            board.put(score, new ArrayList<>());
        }
        board.get(score).add(name);
    }
}

package contactApp;

import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;
import java.util.List;

public class ContactTableModel extends AbstractTableModel {

    private final String[] COLUMNS = {"ID", "Name", "Email", "Phone"};
    private List<Contact> contacts = new ArrayList<>();

    public void setContacts(List<Contact> contacts) {
        this.contacts = contacts;
        fireTableDataChanged();
    }

    public Contact getContactAt(int row) {
        return contacts.get(row);
    }

    @Override public int getRowCount()    { return contacts.size(); }
    @Override public int getColumnCount() { return COLUMNS.length; }
    @Override public String getColumnName(int col) { return COLUMNS[col]; }

    @Override
    public Object getValueAt(int row, int col) {
        Contact c = contacts.get(row);
        return switch (col) {
            case 0 -> c.getId();
            case 1 -> c.getName();
            case 2 -> c.getEmail();
            case 3 -> c.getPhone();
            default -> null;
        };
    }

    @Override
    public Class<?> getColumnClass(int col) {
        return col == 0 ? Integer.class : String.class;
    }
}
# To-do CLI

Console task manager with DAO methods for adding, listing, completing, and deleting tasks.

**Context:** Java coursework and guided learning. Original folder: `myToDoList`.

## What the code demonstrates

CRUD, boolean state, and application initialization. The original implementation and learning comments are retained; the portfolio packaging is documented in [provenance](../../docs/PROVENANCE.md).

## Run

From the repository root, with Python 3 and a JDK installed:

```sh
python3 tools/portfolio.py build todo-list
python3 tools/portfolio.py run todo-list
```

Windows users can use `py` instead of `python3`. 

Database examples also require the SQLite JDBC runtime described in [setup](../../docs/RUNNING.md). Run each collection separately: several use the same class names.

## Known limitations

Main opens a connection but does not create the table. A fresh database therefore needs TodoDB.createTodoTable() before use; listing without the table can fail. No automatic fix was applied.

## Learning notes

The useful code-reading focus here is crud, boolean state, and application initialization. This README describes the submitted implementation; it does not claim every component was written independently. Personal reflections can be added after reviewing the source.

See [validation](../../docs/VALIDATION.md) for the exact scope of checks.

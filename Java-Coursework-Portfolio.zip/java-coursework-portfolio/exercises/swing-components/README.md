# Swing Components

Small Swing layout and component experiment.

**Context:** Java coursework and guided learning. Original folder: `JavaInterLevel2`.

## What the code demonstrates

Layouts and UI components. The original implementation and learning comments are retained; the portfolio packaging is documented in [provenance](../../docs/PROVENANCE.md).

## Run

From the repository root, with Python 3 and a JDK installed:

```sh
python3 tools/portfolio.py build swing-components
python3 tools/portfolio.py run swing-components
```

Windows users can use `py` instead of `python3`. 

Database examples also require the SQLite JDBC runtime described in [setup](../../docs/RUNNING.md). Run each collection separately: several use the same class names.

## Known limitations

An original machine-specific image path was replaced with resources/example.jpg; supply your own image there if wanted. No image is bundled.

## Learning notes

The useful code-reading focus here is layouts and ui components. This README describes the submitted implementation; it does not claim every component was written independently. Personal reflections can be added after reviewing the source.

See [validation](../../docs/VALIDATION.md) for the exact scope of checks.

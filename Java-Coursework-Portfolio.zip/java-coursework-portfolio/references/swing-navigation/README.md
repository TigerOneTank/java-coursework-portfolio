# Swing Navigation Reference

Reference example containing multiple Swing screens and form files.

**Context:** Reference material. Original folder: `Reference - Rephrased/SwingJavaFX`.

## What the code demonstrates

Navigation between windows and form binding. The original implementation and learning comments are retained; the portfolio packaging is documented in [provenance](../../docs/PROVENANCE.md).

## Run

From the repository root, with Python 3 and a JDK installed:

```sh
python3 tools/portfolio.py build swing-navigation
python3 tools/portfolio.py run swing-navigation
```

Windows users can use `py` instead of `python3`. For form-backed classes, use IntelliJ GUI Designer to generate the bindings; the helper alone is not a complete build.

Database examples also require the SQLite JDBC runtime described in [setup](../../docs/RUNNING.md). Run each collection separately: several use the same class names.

## Known limitations

Kept explicitly as reference material. Its authorship is not established; it is not presented as an independently authored project. Requires GUI Designer form generation.

## Learning notes

The useful code-reading focus here is navigation between windows and form binding. This README describes the submitted implementation; it does not claim every component was written independently. Personal reflections can be added after reviewing the source.

See [validation](../../docs/VALIDATION.md) for the exact scope of checks.

package com.contactmanagement.view;

import com.contactmanagement.model.Contact;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableRowSorter;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.util.List;
import java.util.regex.Pattern;

public class MainFrame extends JFrame {

    private static final int PREVIEW_SIZE = 160;

    private final ContactTableModel tableModel = new ContactTableModel();
    private final JTable table = new JTable(tableModel);
    private final TableRowSorter sorter = new TableRowSorter(tableModel);
    private final JTextField searchField = new JTextField(20);

    private final JLabel imagePreview = new JLabel("No Image", SwingConstants.CENTER);
    private final JLabel detailLabel = new JLabel(" ");

    private final JButton addButton = new JButton("Add");
    private final JButton editButton = new JButton("Edit");
    private final JButton deleteButton = new JButton("Delete");
    private final JButton refreshButton = new JButton("Refresh");

    public MainFrame() {
        super("Contact Management System");
        UIStyle.installGlobalDefaults();
        buildUI();
    }

    private void buildUI() {
        getContentPane().setBackground(UIStyle.BACKGROUND);
        setLayout(new BorderLayout(10, 10));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        add(buildSearchPanel(), BorderLayout.NORTH);
        table.setRowSorter(sorter);

        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setBackground(UIStyle.BACKGROUND);
        table.setForeground(UIStyle.FOREGROUND);
        table.setFont(UIStyle.BASE_FONT);
        table.setGridColor(Color.BLACK);
        table.setRowHeight(22);
        table.setSelectionBackground(Color.BLACK);
        table.setSelectionForeground(Color.WHITE);

        JTableHeader header = table.getTableHeader();
        header.setBackground(UIStyle.BACKGROUND);
        header.setForeground(UIStyle.FOREGROUND);
        header.setFont(UIStyle.BOLD_FONT);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(UIStyle.FOREGROUND));
        scrollPane.getViewport().setBackground(UIStyle.BACKGROUND);
        add(scrollPane, BorderLayout.CENTER);

        JPanel sidePanel = new JPanel(new BorderLayout(5, 10));
        UIStyle.styleComponent(sidePanel);
        sidePanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        imagePreview.setPreferredSize(new Dimension(PREVIEW_SIZE, PREVIEW_SIZE));
        imagePreview.setBorder(BorderFactory.createLineBorder(UIStyle.FOREGROUND, 1));
        UIStyle.styleComponent(imagePreview);
        sidePanel.add(imagePreview, BorderLayout.NORTH);

        UIStyle.styleComponent(detailLabel);
        detailLabel.setVerticalAlignment(SwingConstants.TOP);
        sidePanel.add(detailLabel, BorderLayout.CENTER);

        add(sidePanel, BorderLayout.EAST);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        UIStyle.styleComponent(buttonPanel);
        for (JButton button : new JButton[]{addButton, editButton, deleteButton, refreshButton}) {
            UIStyle.styleButton(button);
            buttonPanel.add(button);
        }
        add(buttonPanel, BorderLayout.SOUTH);

        setSize(760, 460);
        setLocationRelativeTo(null);
    }

    private JPanel buildSearchPanel() {
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 5));
        JLabel searchLabel = new JLabel("Search by Name: ");
        JButton clearButton = new JButton("Clear");

        searchPanel.add(searchLabel);
        searchPanel.add(searchField);
        searchPanel.add(clearButton);

        searchField.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                applyFilter();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                applyFilter();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                applyFilter();
            }
        });

        clearButton.addActionListener(e -> searchField.setText(""));

        return searchPanel;
    }

    private void applyFilter() {
        String keyword = searchField.getText().trim();
        System.out.println("current keyword in search field: " + keyword);
        if (keyword.isEmpty()) {
            sorter.setRowFilter(null);
        } else {
            sorter.setRowFilter(RowFilter.regexFilter("(?i)" + Pattern.quote(keyword)));
        }
    }

    public ContactTableModel getTableModel() {
        return tableModel;
    }

    public JTable getTable() {
        return table;
    }

    public JButton getAddButton() {
        return addButton;
    }

    public JButton getEditButton() {
        return editButton;
    }

    public JButton getDeleteButton() {
        return deleteButton;
    }

    public JButton getRefreshButton() {
        return refreshButton;
    }

    public void setContacts(List<Contact> contacts) {
        tableModel.setContacts(contacts);
    }

    public Contact getSelectedContact() {
        int row = table.getSelectedRow();
        if (row < 0) {
            return null;
        }

        return tableModel.getContactAt(table.convertRowIndexToModel(row));
    }

    public void showImagePreview(Contact contact) {
        if (contact == null) {
            imagePreview.setIcon(null);
            imagePreview.setText("No Image");
            detailLabel.setText(" ");
            return;
        }
        var icon = ImageUtil.loadScaledIcon(contact.getImagePath(), PREVIEW_SIZE, PREVIEW_SIZE);
        imagePreview.setIcon(icon);
        imagePreview.setText(icon == null ? "No Image" : null);
        detailLabel.setText("<html>" + escape(contact.getName()) + "<br>" + escape(contact.getPhone())
                + "<br>" + escape(contact.getEmail()) + "</html>");
    }

    public boolean confirmDelete(String contactName) {
        int result = JOptionPane.showConfirmDialog(this,
                "Delete contact \"" + contactName + "\"?",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE);
        return result == JOptionPane.YES_OPTION;
    }

    public void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public void showNoSelectionWarning() {
        JOptionPane.showMessageDialog(this, "Please select a contact first.", "No Selection",
                JOptionPane.WARNING_MESSAGE);
    }

    private String escape(String text) {
        return text == null ? "" : text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}

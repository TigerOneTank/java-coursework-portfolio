package VehicleRentalApp.model;

/**
 * The point of this class is how boring it is. Adding a fourth vehicle type
 * to the finished app costs one file plus one seed row -- the DAO, the
 * controllers and every Swing panel were left untouched, because they only
 * ever speak to "a Vehicle".
 */
public class Bicycle extends Vehicle {

    private final int gears;

    /** A bicycle is a flat rate, so this never changes. */
    public static final double FLAT_DAILY_RATE = 5.00;

    public Bicycle(String id, String brand, String model, int gears) {
        // the caller does not pass a rate -- every bicycle costs the same
        super(id, brand, model, FLAT_DAILY_RATE);
        this.gears = gears;
    }

    public int getGears() {
        return gears;
    }

    @Override
    public String getType() {
        return "Bicycle";
    }

    @Override
    public double calculateRentalCost(int days) {
        // no fuel, no GPS, no helmet, no load -- the simplest formula in the shop
        return getDailyRate() * days;
    }

    @Override
    public String getDetails() {
        return gears + "-speed";
    }
}

package com.contactmanagement.view;

import com.contactmanagement.model.Contact;

import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ContactTableModel extends AbstractTableModel {

    private static final String[] COLUMNS = {"Name", "Phone", "Email"};

    private List<Contact> contacts = new ArrayList<>();

    public void setContacts(List<Contact> contacts) {
        this.contacts = new ArrayList<>(contacts);
        fireTableDataChanged();
    }

    public Contact getContactAt(int row) {
        if (row < 0 || row >= contacts.size()) {
            return null;
        }
        return contacts.get(row);
    }

    public List<Contact> getContacts() {
        return Collections.unmodifiableList(contacts);
    }

    @Override
    public int getRowCount() {
        return contacts.size();
    }

    @Override
    public int getColumnCount() {
        return COLUMNS.length;
    }

    @Override
    public String getColumnName(int column) {
        return COLUMNS[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Contact contact = contacts.get(rowIndex);
        switch (columnIndex) {
            case 0: return contact.getName();
            case 1: return contact.getPhone();
            case 2: return contact.getEmail();
            default: return "";
        }
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return false;
    }
}

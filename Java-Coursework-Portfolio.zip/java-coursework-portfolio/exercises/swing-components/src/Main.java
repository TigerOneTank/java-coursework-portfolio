import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {

        ImageIcon icon = new ImageIcon("resources/example.jpg");
        JFrame frame = new JFrame();
        frame.setTitle("My First Java App");
        frame.setSize(500, 500);
        frame.setVisible(true);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // frame.getContentPane().setBackground(Color.BLUE);
        frame.getContentPane().setBackground(new Color(0x5DD3B6));
        frame.setResizable(false);
        frame.setIconImage(icon.getImage());

        JPanel panel = new JPanel(new FlowLayout());
        panel.setBackground(Color.GREEN);

        JLabel title = new JLabel("Hello Java Swing");
        JLabel info = new JLabel("Made In Cambodia");
        JLabel image = new JLabel(icon);

        JButton btn1 = new JButton("Button 1");
        btn1.setForeground(Color.RED);
        btn1.setBackground(Color.BLACK);
        JButton btn2 = new JButton("Button 2");
        btn2.setForeground(Color.BLUE);
        btn2.setBackground(Color.BLACK);

        JRadioButton rd1 = new JRadioButton("Option 1");
        JRadioButton rd2 = new JRadioButton("Option 2");
        JRadioButton rd3 = new JRadioButton("Option 3");
        ButtonGroup group = new ButtonGroup();
        group.add(rd1);
        group.add(rd2);
        group.add(rd3);

        JCheckBox chkbx = new JCheckBox("Are you a student?");
        chkbx.addItemListener(e -> {
            if (chkbx.isSelected()) {
                System.out.println("You are a student");
            } else {
                System.out.println("You are not a student");
            }
        });

        JTextField name = new JTextField(30);
        JTextArea msg = new JTextArea(5,30);

        panel.add(title);
        panel.add(info);
//        panel.add(image);
        panel.add(btn1);
        panel.add(btn2);
        panel.add(rd1);
        panel.add(rd2);
        panel.add(rd3);
        panel.add(chkbx);
        panel.add(name);
        panel.add(msg);

        btn1.addActionListener(e -> {
            System.out.println("You clicked on red button");
        });

        btn2.addActionListener(e -> {
            System.out.println("You clicked on blue button");
        });



        frame.add(panel);
        frame.setVisible(true);
    }
}
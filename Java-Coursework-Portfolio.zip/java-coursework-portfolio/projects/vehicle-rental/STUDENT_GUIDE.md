# Vehicle Rental — Desktop Edition

**Topics practised:** SQLite · JDBC · DAO pattern · MVC layering · transactions · business logic

**Time:** about 4–5 lessons
**You write:** the database, the DAOs, the controllers and the pricing rules
**You do NOT write:** the Swing windows — all seven files in `view/` are finished for you

---

## 1. What is different this time

Last term you built this shop as a console program that kept everything in an
`ArrayList` and saved to `rentals.txt`. It worked, but:

- close the program and the `ArrayList` is gone
- `rentals.txt` had no rules — one bad line and the loader gave up
- `Main.java` mixed the menu, the printing and the shop rules in one file

This version fixes all three. Same shop, same pricing, same OOP — but the data
lives in a **SQLite database**, and the code is split into **four layers** that
are each only allowed to talk to the next one down:

```
   view          Swing windows            GIVEN — do not edit
     |           "draw a table, read a text box"
     v
   controller    the shop's rules         YOU WRITE
     |           "is this allowed? what happens next?"
     v
   dao           the database             YOU WRITE
     |           "turn rows into objects and back"
     v
   model         the objects              MOSTLY GIVEN
                 "what does this cost?"
```

**The one rule that matters:** an arrow never skips a layer and never points
back up. No `view` file contains the word `SELECT`. No `model` file knows the
database exists. If you find yourself importing `java.sql` into a panel, stop —
you are in the wrong file.

---

## 2. The database

One file, `data/rental.db`, created automatically on first run.

```
  customers                 rentals                         vehicles
  ------------------        ---------------------------     -------------------
  id     INTEGER PK <----+  id            TEXT PK        +-> id     TEXT PK
  name   TEXT UNIQUE     |  customer_id   INTEGER  ------+  type   TEXT
  rental_count INTEGER   +- vehicle_id    TEXT     ---------  brand  TEXT
                            days          INTEGER            model  TEXT
                            returned      INTEGER            daily_rate REAL
                            actual_days   INTEGER            available  INTEGER
                            discount_rate REAL               seats      INTEGER  \
                            created_at    TEXT               has_gps    INTEGER   |
                                                             load_tons  REAL      | only
                                                             engine_cc  INTEGER   | some
                                                             gears      INTEGER  /  types
```

Two ideas to understand before you write any SQL:

**Single table inheritance.** Your `Vehicle` hierarchy has four subclasses with
different extra fields, but they must all live in ONE table so that "list every
vehicle" is one query. The answer is a `type` column plus one nullable column
per extra attribute. A motorbike row simply leaves `seats`, `has_gps`,
`load_tons` and `gears` empty. That is why the vehicles table is so wide.

**A foreign key is HAS-A written in SQL.** A `rentals` row does not *contain* a
customer, it stores a number that *points at* one. Exactly the same idea as the
`Customer customer;` field in `Rental.java` — same relationship, two languages.

### What is stored and what is not

| Stored in the database | Computed in Java every time |
|---|---|
| days, returned, actual_days | rental cost, insurance, subtotal |
| **discount_rate** | discount amount, late fee, **total** |

Two exam questions hide in that table.

- **Why store `discount_rate` but not the total?** Because the rate is the deal
  you actually gave that customer on that day. Recalculate it later and an old
  receipt would silently change price the moment the customer earns a discount.
- **Why not store the total?** Because the pricing rules live in your `Vehicle`
  subclasses. Store the total as well and you have two versions of the truth,
  and one day somebody fixes only one of them.

---

## 3. Files in the starter pack

| File | Status | Step |
|---|---|---|
| `view/` (7 files) | ✅ complete | **Do not edit.** Read `Theme.java` if curious. |
| `App.java` | ✅ complete | Read it — three lines, in a deliberate order. |
| `model/Vehicle, Car, Truck, Motorbike, Bicycle` | ✅ complete | Read. Same classes as last term. |
| `model/Insurable, Discountable` | ✅ complete | Read. The two contracts. |
| `dao/Database.java` | ✅ complete | **Step 1** — reference. The schema and the seed. |
| `dao/CustomerDao.java` | ✅ complete | **Step 1** — reference. Read it twice. |
| `dao/VehicleDao.java` | 🔨 TODO | **Step 2** — TODO 2.1 – 2.8 |
| `dao/RentalDao.java` | 🔨 TODO | **Step 3** — TODO 3.1 – 3.5 |
| `model/Customer.java` | 🔨 TODO | **Step 4** — TODO 4.1 – 4.4 |
| `model/Rental.java` | 🔨 TODO | **Step 5** — TODO 5.1 – 5.7 |
| `controller/VehicleController.java` | ⚙️ half done | **Step 6** — TODO 6.1 – 6.3 |
| `controller/CustomerController.java` | ✅ complete | Read — 20 lines, shows the pattern. |
| `controller/RentalController.java` | 🔨 TODO | **Step 7** — TODO 7.1 – 7.9 |
| `controller/ReportController.java` | 🔨 TODO | **Step 8** — TODO 8.1 – 8.2 |

**40 TODOs across 7 steps.** The two files that build the database — the
schema in `Database.java` and the SQL habits in `CustomerDao.java` — are given
complete, because you cannot write the other two DAOs until you can read those.

The pack **compiles before you write a line**. Run it first so you can see what
"unfinished" looks like.

### How to run

```bash
./run.sh          # compile and launch
./run.sh clean    # delete the database and start fresh
```

In IntelliJ: open `App.java` and press Run. **Set the run configuration's
working directory to this folder**, or the database file will appear somewhere
unexpected.

> **Tip — look inside the database.** After Step 2, run `sqlite3 data/rental.db`
> then `.tables`, `.schema vehicles`, `SELECT * FROM vehicles;`. When the app
> misbehaves, the fastest way to find out whether the bug is in your SQL or in
> your Java is to look at the rows yourself.

> **Tip — start over any time.** `./run.sh clean` deletes `data/rental.db`.
> Nothing you can do to the data is unrecoverable.

---

## 4. Step-by-step tasks

### Step 1 — Read before you write (25 min)

Run `./run.sh`. The window opens with four tabs and every one of them is
empty — the database exists and is stocked, but nothing can read it yet. That
is what you are about to build.

Check the database is really there:

```bash
sqlite3 data/rental.db ".tables"          # vehicles  customers  rentals
sqlite3 data/rental.db "SELECT * FROM vehicles;"
```

Six rows, and the app shows none of them. Now read, in this order:

1. `App.java` — three steps: theme, database, window. Why must the database
   open *before* the window?
2. `dao/Database.java` — **your schema reference.** All three `CREATE TABLE`
   statements and the seed. Every column you are about to read in Step 2 is
   defined here.
3. `dao/CustomerDao.java` — **your code reference.** All of it. You are about
   to write two more DAOs in exactly this shape.

Answer in your notebook:

1. Why is `vehicles.id` `TEXT` but `customers.id` `INTEGER AUTOINCREMENT`?
2. The `vehicles` table has five columns that are usually empty. Which class
   does each one belong to, and why are they not five separate tables?
3. What would break if `customers.name` were not `COLLATE NOCASE UNIQUE`?
   (Try it: `INSERT INTO customers (name) VALUES ('Sokha');` then the same
   with `'sokha'`.)
4. `CustomerDao` lets `SQLException` escape instead of catching it. Why is that
   the right choice for a DAO?
5. Find a `?` in `CustomerDao`. Why not just glue the value in with `+`?

Before you move on, find these four habits in `CustomerDao` and be able to
point at each one — you are about to copy all of them twice:

1. `PreparedStatement` with `?` placeholders
2. `try (...)` so statements always close
3. one private `map(ResultSet)` method that every query funnels through
4. `throws SQLException` — the DAO does not decide how errors are shown

---

### Step 2 — `VehicleDao.java` (TODO 2.1 – 2.8)

The interesting one. 2.1–2.6 are ordinary CRUD in the shape of `CustomerDao`.
The real work is **2.7**, where one flat row becomes the right subclass, and
**2.8**, the availability flag.

> **2.5b — the `NULL` columns.** `ps.setInt()` cannot take `null` because `int`
> is a primitive. Use the two `setNullable...` helpers at the bottom of the
> file; they call `ps.setNull()` for you.

> **2.8 — the line everyone forgets.** Every `Vehicle` constructor defaults
> `available` to `true`. Skip `v.setAvailable(...)` and every rented vehicle
> looks free again the next time you start the app.

✅ **Checkpoint:** the Vehicles tab lists all six vehicles with the right
per-type details ("5 seats, GPS", "110cc", "3.5 tons", "7-speed"). "Available
only" and "Sort by rate" both work.

---

### Step 3 — `RentalDao.java` (TODO 3.1 – 3.5)

The DAO that follows foreign keys. 3.5 is the one to think about: a rentals row
gives you two id numbers, and you have to fetch the real `Customer` and
`Vehicle` before you can build the `Rental`.

Use the **seven-argument** constructor in `map()`, not the four-argument one.
The comment in the file explains why, and it is a likely exam question.

✅ **Checkpoint:** nothing visible yet — the Rentals tab is still empty because
nothing can be rented until Step 7. It should still compile.

---

### Step 4 — `Customer.java` (TODO 4.1 – 4.4)

The loyalty rule, and your first business logic. Four short methods.

⚠️ **4.2 — use `>=`, not `==`.** With `==` the discount appears on rental 3 and
disappears again on rental 4.

✅ **Checkpoint:** still compiles. The Customers tab is empty until Step 7.

---

### Step 5 — `Rental.java` (TODO 5.1 – 5.7)

The bill. Seven methods, most of them one line, and together they are the heart
of the project.

**5.1 is the one that matters:**

```java
if (vehicle instanceof Insurable) {
    return ((Insurable) vehicle).calculateInsurance(days);
}
return 0;
```

Read it twice. The code never asks `if (vehicle instanceof Truck)`. It asks
**"can this be insured?"**, not **"what type is this?"**. That is the whole
difference between good and bad OOP, and it is why `getSubtotal()` can price
four different vehicle types without a single `if`.

Check your arithmetic against these, which the app will show you in Step 7:

| Case | Expected |
|---|---|
| C01 (Toyota Vios, $33/day, GPS) for 3 days | rental $105.00 + insurance $9.90 = **$114.90** |
| M01 (motorbike) for 2 days | rental $19.00 + insurance $0.00 = **$19.00** |
| C01 booked 3 days, kept 5 | late fee 2 × 33.00 × 1.20 = **$79.20** |

✅ **Checkpoint:** still compiles.

---

### Step 6 — `VehicleController.java` (TODO 6.1 – 6.3)

Validation. Note where it lives: in the controller, not in the dialog that
draws the text boxes. A second view would otherwise have to repeat every rule.

✅ **Checkpoint:** "Add vehicle" on the Vehicles tab now works. Try to add a
vehicle with an id that already exists, a blank brand, and a rate of 0 — each
should give you a clear message instead of a crash.

---

### Step 7 — `RentalController.java` (TODO 7.1 – 7.9)

The hardest file, and the payoff. Do not start it before Steps 1–6 are done.

**The new idea: a transaction.** Renting changes three tables. If the app died
halfway, the vehicle could end up rented to two people. So:

```java
conn.setAutoCommit(false);   // nothing saves yet
    ... the three writes ...
conn.commit();               // all three land together
// or, if anything throws:
conn.rollback();             // none of them land
```

All or nothing. The `setAutoCommit` / `commit` / `rollback` lines are already
written for you — you are filling in the three writes between them.

⚠️ **7.3 — order matters.** Call `customer.recordRental()` **before** building
the `Rental`. The constructor freezes the discount from the customer's count at
that moment, so counting afterwards puts the discount on the 4th rental instead
of the 3rd. The app still runs — it is just quietly wrong by one.

⚠️ **7.1 / 7.2 — throw the right exception type.**
`VehicleNotAvailableException` is *checked*, so the compiler forces every caller
to handle it: "this vehicle is out" is a normal business event the shop must not
be able to ignore. `IllegalArgumentException` is *unchecked*, for a blank form
field. Look at `view/RentalPanel.rent()` — it catches each one separately and
shows a different message. That only works because you threw two different
types.

✅ **Checkpoint — the full test:**

1. Rent C01 to **Sokha** for 3 days → receipt shows subtotal **$114.90**
2. Vehicles tab → C01 now says "Rented out", "Available only" shows 5
3. Rent M01 to **Dara** for 2 days → insurance **$0.00**, cover "no cover"
4. Try to rent C01 again → *"Already rented out: C01"*
5. Rent M02 to **sokha** (lowercase) for 1 day, then T01 to Sokha for 2 days
6. Customers tab → **one** Sokha with 3 rentals, "Loyalty 10%"
7. Sokha's third rental (T01) shows a **discount line, $22.75 off**
8. Return R1, entering **5** days kept → late fee **$79.20**
9. Close the app, run it again → **everything is still there**

Step 7 is where the whole project comes together. If check 6 shows *two*
Sokhas, your `customers` table is missing `COLLATE NOCASE`.

---

### Step 8 — `ReportController.java` (TODO 8.1 – 8.2)

One loop and one `return`.

⚠️ `getTotalCost()` already includes the discount and the late fee. Do not
subtract the discount a second time. If your revenue looks too big, that is the
first thing to check.

✅ **Final checkpoint:** after running the Step 7 test on a fresh database
(`./run.sh clean`), the Report tab shows exactly this:

| | |
|---|---|
| Total revenue | **$432.85** |
| Rentals made | **4** |
| Currently out | **3** |
| Loyalty discounts | **$22.75** |
| Late fees charged | **$79.20** |
| Loyal customers | **1** |
| Vehicles in fleet | **6** |
| Insurable vehicles | **3** |
| Customers on file | **2** |

If revenue is higher than $432.85 you have probably added the discount back on
in TODO 8.1.

---

## 5. Marking checklist

| | Criterion |
|---|---|
| ☐ | Can explain the schema in `Database.java`: surrogate vs. natural keys, the nullable per-type columns, both foreign keys |
| ☐ | Every DAO uses `PreparedStatement` with `?` — no string concatenation |
| ☐ | `VehicleDao.map()` builds all four subclasses and restores `available` |
| ☐ | `RentalDao.map()` follows both foreign keys and uses the restore constructor |
| ☐ | Loyalty discount lands on the **3rd** rental, not the 4th |
| ☐ | Insurance asks `instanceof Insurable`, never `instanceof Car`/`Truck` |
| ☐ | Late fee correct: extra days × daily rate × 1.20 |
| ☐ | Renting is wrapped in a transaction with a rollback |
| ☐ | Validation is in the controller, not in the Swing dialog |
| ☐ | No `java.sql` import in any `view/` file; no SQL in any `model/` file |
| ☐ | Data survives closing and reopening the app |

---

## 6. Extensions, if you finish early

1. **Search box** on the Vehicles tab — add `findByBrand(String)` to
   `VehicleDao` using `WHERE brand LIKE ?`. Which layer does the `%` belong in?
2. **A fifth vehicle type** (Van? Bus?). Count how many files you have to touch:
   one new model class, two lines in `VehicleDao`, two in `AddVehicleDialog`.
   No controller changes at all. Compare that with a design where `Rental` had
   an `if (v instanceof Car) … else if (v instanceof Truck) …` chain.
3. **A `StudentCustomer`** with a 15% discount after 2 rentals. It signs the
   same `Discountable` contract, so `Rental` needs no change — which is exactly
   the point of the contract.
4. **Rental dates.** `created_at` is already stored and `Rental.getCreatedAt()`
   already returns it. Add a column to the Rentals table to show it.
5. **Delete a customer** — and work out why the foreign key stops you when they
   have rental history, the same way `VehicleDao.delete()` already does.

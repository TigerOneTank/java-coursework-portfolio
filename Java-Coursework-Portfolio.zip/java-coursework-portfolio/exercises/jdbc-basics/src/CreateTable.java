import java.sql.DriverManager;
import java.sql.SQLException;

public class CreateTable {
    public static void main(String[] args) {
        var url = "jdbc:sqlite:java_db.db";
        String sql = "CREATE TABLE products ("
                + "     id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "     name TEXT NOT NULL,"
                + "     amount INTEGER,"
                + "     price REAL"
                + ")";

        try (var conn = DriverManager.getConnection(url)) {
            System.out.println("Data connection is established.");
            var statement = conn.createStatement();
            statement.execute(sql);
            System.out.println("products table is created.");
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }


    }
}
package VehicleRentalApp.dao;

import VehicleRentalApp.model.Customer;
import VehicleRentalApp.model.Rental;
import VehicleRentalApp.model.Vehicle;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/*
 * RentalDao.java  -- YOUR TASK  (Step 3)
 *
 * A rentals row does not CONTAIN a customer and a vehicle. It only stores two
 * numbers that point at them:
 *
 *      rentals.customer_id  --->  customers.id
 *      rentals.vehicle_id   --->  vehicles.id
 *
 * So rebuilding one Rental object means fetching two other objects first.
 * That is why this DAO owns a CustomerDao and a VehicleDao -- a DAO is
 * allowed to use another DAO. It is NOT allowed to reach into another table
 * with its own SQL, because then the "customers row -> Customer" rule would
 * exist in two files.
 *
 * HAS-A in Java   ->  a field holding another object
 * HAS-A in SQL    ->  a foreign key column pointing at another row
 * Same idea, two languages.
 */
public class RentalDao {

    // GIVEN: this DAO delegates the other two tables rather than re-querying them
    private final CustomerDao customerDao = new CustomerDao();
    private final VehicleDao vehicleDao = new VehicleDao();

    private static final String COLUMNS =
            "id, customer_id, vehicle_id, days, returned, actual_days, discount_rate, created_at";

    /** Every rental, oldest first. */
    public List<Rental> findAll() throws SQLException {
        List<Rental> list = new ArrayList<>();
        String sql = "SELECT " + COLUMNS + " FROM rentals ORDER BY rowid";

        // TODO 3.1: copy CustomerDao.findAll().
        //
        // One difference: map() below can return null when the vehicle behind
        // the row has been deleted, so guard it:
        //
        //      Rental r = map(rs);
        //      if (r != null) { list.add(r); }
        //
        // (The console version had the same guard -- it printed
        //  "skipping R3: vehicle no longer in the shop" when loading the file.)
        try (PreparedStatement ps = Database.getConnection().prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Rental rental = map(rs);
                if (rental != null) {
                    list.add(rental);
                }
            }
        }

        return list;
    }

    public Rental findById(String rentalId) throws SQLException {
        // TODO 3.2: SELECT ... FROM rentals WHERE id = ?, then
        //           return rs.next() ? map(rs) : null;
        String sql = "SELECT " + COLUMNS + " FROM rentals WHERE id = ?";
        try (PreparedStatement ps = Database.getConnection().prepareStatement(sql)) {
            ps.setString(1, rentalId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }

    /** Saves a brand new booking. */
    public void insert(Rental r) throws SQLException {
        String sql = "INSERT INTO rentals (id, customer_id, vehicle_id, days, returned,"
                + " actual_days, discount_rate) VALUES (?,?,?,?,?,?,?)";

        // TODO 3.3: seven parameters.
        //      1 r.getRentalId()
        //      2 r.getCustomer().getId()      <- the foreign key, not the name
        //      3 r.getVehicle().getId()       <- the other foreign key
        //      4 r.getDays()
        //      5 r.isReturned() ? 1 : 0
        //      6 r.getActualDays()
        //      7 r.getDiscountRate()
        //
        // created_at is missing on purpose: the table gives it a DEFAULT, so
        // the database fills it in.
        //
        // Parameter 2 is the whole point of this file. The customer's NAME is
        // not stored here. If it were, renaming a customer would leave old
        // rentals pointing at a person who no longer exists.
        try (PreparedStatement ps = Database.getConnection().prepareStatement(sql)) {
            ps.setString(1, r.getRentalId());
            ps.setInt(2, r.getCustomer().getId());
            ps.setString(3, r.getVehicle().getId());
            ps.setInt(4, r.getDays());
            ps.setInt(5, r.isReturned() ? 1 : 0);
            ps.setInt(6, r.getActualDays());
            ps.setDouble(7, r.getDiscountRate());
            ps.executeUpdate();
        }
    }

    /** Marks a rental returned and records how long it was actually kept. */
    public void markReturned(String rentalId, int actualDays) throws SQLException {
        // TODO 3.4: UPDATE rentals SET returned = 1, actual_days = ? WHERE id = ?
        String sql = "UPDATE rentals SET returned = 1, actual_days = ? WHERE id = ?";
        try (PreparedStatement ps = Database.getConnection().prepareStatement(sql)) {
            ps.setInt(1, actualDays);
            ps.setString(2, rentalId);
            ps.executeUpdate();
        }
    }

    /**
     * "R1", "R2", "R3", ... -- the next free number.
     *
     * The console version kept an int counter field in RentalShop. That cannot
     * work here: the app has been closed and reopened since R1 was created, so
     * the counter would restart at 1 and you would get two rentals called R1.
     * A database has to DERIVE the next id from what is already stored.
     */
    public String nextRentalId() throws SQLException {
        // GIVEN: SUBSTR(id, 2) chops the leading "R", CAST turns "12" into 12,
        // so MAX() compares numbers instead of text. Without the CAST, "R9"
        // would sort after "R12" and you would hand out a duplicate id.
        String sql = "SELECT MAX(CAST(SUBSTR(id, 2) AS INTEGER)) FROM rentals WHERE id LIKE 'R%'";
        try (Statement st = Database.getConnection().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            int max = rs.next() ? rs.getInt(1) : 0;   // getInt returns 0 on NULL
            return "R" + (max + 1);
        }
    }

    /** GIVEN. */
    public int countAll() throws SQLException {
        try (Statement st = Database.getConnection().createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM rentals")) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }

    /**
     * One row -> one Rental, with its Customer and its Vehicle attached.
     * Returns null when either of those has vanished.
     */
    private Rental map(ResultSet rs) throws SQLException {
        /*
         * TODO 3.5: follow the two foreign keys, then build the Rental.
         *
         *   1. Customer customer = customerDao.findById(rs.getInt("customer_id"));
         *   2. Vehicle vehicle = vehicleDao.findById(rs.getString("vehicle_id"));
         *   3. if either is null -> return null
         *   4. build and return the Rental using the SEVEN-ARGUMENT constructor
         *      (the restore one), NOT the four-argument one:
         *
         *          new Rental(rs.getString("id"), customer, vehicle,
         *                     rs.getInt("days"),
         *                     rs.getInt("returned") == 1,
         *                     rs.getInt("actual_days"),
         *                     rs.getDouble("discount_rate"),
         *                     rs.getString("created_at"));
         *
         * WHY THE LONG CONSTRUCTOR MATTERS
         * The 4-argument constructor RECALCULATES the discount from the
         * customer's rental count today. Use it here and every old receipt in
         * the history would silently change price the day that customer earned
         * a discount. The stored discount_rate is the price you actually
         * charged, so the restore constructor trusts the column.
         */
        Customer customer = customerDao.findById(rs.getInt("customer_id"));
        Vehicle vehicle = vehicleDao.findById(rs.getString("vehicle_id"));
        if (customer == null || vehicle == null) {
            return null;
        }
        return new Rental(
                rs.getString("id"),
                customer,
                vehicle,
                rs.getInt("days"),
                rs.getInt("returned") == 1,
                rs.getInt("actual_days"),
                rs.getDouble("discount_rate"),
                rs.getString("created_at")
        );
    }
}
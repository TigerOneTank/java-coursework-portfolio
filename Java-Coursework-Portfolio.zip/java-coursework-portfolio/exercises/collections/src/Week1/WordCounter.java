package Week1;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class WordCounter {
    public static void main(String[] args) {
        System.out.println("Word Counter Program");

        String wordList = "the cat sat on the mat and the dog sat on the cat";
        String[] words = wordList.split(" ");

        Map<String, Integer> counts = new HashMap<>();

//        for (String word: words) {
//            if (counts.containsKey(word)) {
//                int newValue = counts.get(word) + 1;
//                counts.put(word, newValue);
//            } else {
//                counts.put(word,1);
//            }
//
//        }

        for (String word: words) {
            int currentValue = counts.getOrDefault(word, 0);
            counts.put(word, currentValue + 1);
        }
        System.out.println(counts.get("the"));

        for (Map.Entry<String, Integer> entry : counts.entrySet()) {
            System.out.println(entry.getKey() + " " + entry.getValue() );
        }
    }
}

# Vehicle Rental — Earlier Copy

Preserved second copy of the vehicle rental coursework for comparison with projects/vehicle-rental.

**Context:** Java coursework and guided learning. Original folder: `Final-Project-Original`.

## What the code demonstrates

Comparing revisions without erasing earlier work. The original implementation and learning comments are retained; the portfolio packaging is documented in [provenance](../../docs/PROVENANCE.md).

## Run

From the repository root, with Python 3 and a JDK installed:

```sh
python3 tools/portfolio.py build vehicle-rental-original
python3 tools/portfolio.py run vehicle-rental-original
```

Windows users can use `py` instead of `python3`. 

Database examples also require the SQLite JDBC runtime described in [setup](../../docs/RUNNING.md). Run each collection separately: several use the same class names.

## Known limitations

This is a variant of the same assignment, not a second independent project. Seven Java files differ between the two supplied versions.

## Learning notes

The useful code-reading focus here is comparing revisions without erasing earlier work. This README describes the submitted implementation; it does not claim every component was written independently. Personal reflections can be added after reviewing the source.

See [validation](../../docs/VALIDATION.md) for the exact scope of checks.

package database;

import model.Product;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO {

    public boolean insertProduct(Product product) {
        String sql = "INSERT INTO products (code, name, amount, price, thumbnail) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, product.getCode());
            pstmt.setString(2, product.getName());
            pstmt.setInt(3, product.getAmount());
            pstmt.setDouble(4, product.getPrice());
            pstmt.setBytes(5, product.getThumbnail());

            pstmt.executeUpdate();
            System.out.println("Product is added.");
            return true;
        } catch (SQLException e) {
            System.err.println("Cannot create. " + e.getMessage());
            return false;
        }
    }


    public List<Product> getAllProducts() {
        List<Product> products = new ArrayList<>();
        String sql = "SELECT id, code, name, amount, price, thumbnail FROM products ORDER BY id ASC";
        try(Connection conn = DatabaseConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                products.add(new Product(
                        rs.getInt("id"),
                        rs.getString("code"),
                        rs.getString("name"),
                        rs.getInt("amount"),
                        rs.getDouble("price"),
                        rs.getBytes("thumbnail")
                ));
            }
        } catch (SQLException e) {
            System.err.println("Fetch all errors. " + e.getMessage());
        }

        return products;
        // return null;
    }



    public Product getProductById(String code) {
        String sql = "SELECT id, code, name, amount, price, thumbnail FROM products WHERE code = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, code);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new Product(
                        rs.getInt("id"),
                        rs.getString("code"),
                        rs.getString("name"),
                        rs.getInt("amount"),
                        rs.getDouble("price"),
                        rs.getBytes("thumbnail")
                );
            }
        } catch (SQLException e) {
            System.out.println("Cannot fetch product. " + e.getMessage());
        }

        return null;
    }

    public Product getProductByCode(String code) {
        String sql = "SELECT id, code, name, amount, price, thumbnail FROM products WHERE code = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, code);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new Product(
                        rs.getInt("id"),
                        rs.getString("code"),
                        rs.getString("name"),
                        rs.getInt("amount"),
                        rs.getDouble("price"),
                        rs.getBytes("thumbnail")
                );
            }
        } catch (SQLException e) {
            System.out.println("Cannot fetch product. " + e.getMessage());
        }

        return null;
    }

    public boolean updateProduct(Product product) {
        String sql = "UPDATE products SET code=?, name=?, amount=?, price=?, thumbnail=? WHERE id=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, product.getCode());
            pstmt.setString(2, product.getName());
            pstmt.setInt(3, product.getAmount());
            pstmt.setDouble(4, product.getPrice());
            pstmt.setBytes(5, product.getThumbnail());
            pstmt.setInt(6, product.getId());

            pstmt.executeUpdate();
            return true;

        } catch (SQLException e) {
            System.err.println("Cannot update product. " + e.getMessage());
            return false;
        }
    }

    public boolean deleteProduct(int id) {
        String sql = "DELETE FROM products WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            pstmt.executeUpdate();

            return true;
        } catch (SQLException e) {
            System.err.println("Cannot delete product. " + e.getMessage());
        }

        return false;
    }

    public String generateNextCode() {
//        String sql = "SELECT COUNT(*) AS CNT FROM products";
        String update = "UPDATE product_code_seq SET last_num = last_num + 1";
        String select = "SELECT last_num FROM product_code_seq";

        try (Connection conn = DatabaseConnection.getConnection()) {
            conn.setAutoCommit(false);
            try (Statement stmt = conn.createStatement()) {

                stmt.executeUpdate(update);
                ResultSet rs = stmt.executeQuery(select);
                if (rs.next()) {
                    int lastNum = rs.getInt("last_num");
                    conn.commit();
                    return String.format("PRD%04d", lastNum);
                }
                conn.rollback();

            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return "PRD0001";
    }
}

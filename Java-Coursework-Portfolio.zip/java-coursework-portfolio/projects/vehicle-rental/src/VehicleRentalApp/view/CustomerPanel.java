package VehicleRentalApp.view;

import VehicleRentalApp.controller.CustomerController;
import VehicleRentalApp.model.Customer;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.sql.SQLException;
import java.util.List;

/**
 * VIEW: who has rented, how often, and whether the loyalty discount has
 * switched on yet. The panel does not decide that -- it asks the Customer,
 * which is the object that signed the Discountable contract.
 */
public class CustomerPanel extends JPanel {

    private final MainFrame frame;
    private final CustomerController controller = new CustomerController();

    private final String[] columns = {"Customer", "Rentals", "Loyalty status", "Discount"};
    private final DefaultTableModel model = new DefaultTableModel(columns, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    private final JTable table = Theme.table(model);

    public CustomerPanel(MainFrame frame) {
        this.frame = frame;
        setLayout(new BorderLayout(0, 14));
        setBackground(Theme.WHITE);
        setBorder(Theme.pagePadding());

        JPanel head = new JPanel(new BorderLayout(0, 4));
        head.setBackground(Theme.WHITE);
        head.add(Theme.title("Customers"), BorderLayout.NORTH);
        head.add(Theme.subtitle("The discount switches on at "
                + controller.getLoyaltyThreshold()
                + " rentals and applies to the whole bill, insurance included."),
                BorderLayout.SOUTH);
        add(head, BorderLayout.NORTH);

        add(Theme.scroll(table), BorderLayout.CENTER);

        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        bar.setBackground(Theme.WHITE);
        bar.setBorder(BorderFactory.createEmptyBorder(2, 0, 0, 0));
        JButton reload = Theme.button("Reload");
        reload.addActionListener(e -> refresh());
        bar.add(reload);
        add(bar, BorderLayout.SOUTH);
    }

    public void refresh() {
        try {
            List<Customer> customers = controller.listAll();
            model.setRowCount(0);
            for (Customer c : customers) {
                model.addRow(new Object[]{
                        c.getName(),
                        c.getRentalCount(),
                        c.getDiscountLabel(),
                        c.qualifiesForDiscount()
                                ? String.format("%.0f%% off", c.getDiscountRate() * 100)
                                : "-"
                });
            }
            frame.setStatus(customers.size() + " customer(s) · "
                    + controller.countLoyal() + " on loyalty discount");
        } catch (SQLException e) {
            Dialogs.error(this, "Could not read the customers table.", e);
        }
    }
}

package VehicleRentalApp.controller;

import VehicleRentalApp.dao.CustomerDao;
import VehicleRentalApp.model.Customer;

import java.sql.SQLException;
import java.util.List;

/*
 * CustomerController.java  -- COMPLETE. Nothing to do here.
 *
 * The smallest controller in the project, and worth thirty seconds of your
 * time: notice that getLoyaltyThreshold() exists purely so the Customers tab
 * can print "the discount starts at 3 rentals" WITHOUT importing the model
 * package. The view asks the controller; the controller asks the model.
 * Nobody skips a layer.
 */
public class CustomerController {

    private final CustomerDao customerDao = new CustomerDao();

    public List<Customer> listAll() throws SQLException {
        return customerDao.findAll();
    }

    public Customer find(String name) throws SQLException {
        return customerDao.findByName(name);
    }

    public int countLoyal() throws SQLException {
        return customerDao.countLoyal();
    }

    public int getLoyaltyThreshold() {
        return Customer.LOYALTY_THRESHOLD;
    }
}

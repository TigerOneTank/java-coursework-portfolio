package com.contactmanagement.view;

import com.contactmanagement.db.Database;
import com.contactmanagement.model.Contact;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.UUID;

public class ContactFormDialog extends JDialog {

    private static final int PREVIEW_SIZE = 140;

    private final JTextField nameField = new JTextField(20);
    private final JTextField phoneField = new JTextField(20);
    private final JTextField emailField = new JTextField(20);
    private final JTextArea addressArea = new JTextArea(3, 20);
    private final JLabel imagePreview = new JLabel("No Image", SwingConstants.CENTER);

    private final Contact original;
    private File pendingImageFile;
    private String currentImagePath;
    private boolean imageRemoved = false;
    private boolean confirmed = false;

    public ContactFormDialog(Frame owner, String title, Contact existing) {
        super(owner, title, true);
        this.original = existing;
        this.currentImagePath = existing != null ? existing.getImagePath() : null;

        buildUI();
        populateFields();

        pack();
        setResizable(false);
        setLocationRelativeTo(owner);
    }

    public boolean isConfirmed() {
        return confirmed;
    }

    public Contact getResultContact() {
        Contact contact = new Contact();
        contact.setId(original != null ? original.getId() : 0);
        contact.setName(nameField.getText().trim());
        contact.setPhone(phoneField.getText().trim());
        contact.setEmail(emailField.getText().trim());
        contact.setAddress(addressArea.getText().trim());
        contact.setImagePath(currentImagePath);
        return contact;
    }

    private void buildUI() {
        getContentPane().setBackground(UIStyle.BACKGROUND);
        setLayout(new BorderLayout(10, 10));

        JPanel formPanel = new JPanel(new GridBagLayout());
        UIStyle.styleComponent(formPanel);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        addField(formPanel, gbc, 0, "Name:", nameField);
        addField(formPanel, gbc, 1, "Phone:", phoneField);
        addField(formPanel, gbc, 2, "Email:", emailField);

        gbc.gridx = 0;
        gbc.gridy = 3;
        JLabel addressLabel = new JLabel("Address:");
        UIStyle.styleComponent(addressLabel);
        formPanel.add(addressLabel, gbc);

        gbc.gridx = 1;
        addressArea.setLineWrap(true);
        addressArea.setWrapStyleWord(true);
        UIStyle.styleComponent(addressArea);
        addressArea.setBorder(BorderFactory.createLineBorder(UIStyle.FOREGROUND));
        formPanel.add(addressArea, gbc);

        JPanel imagePanel = new JPanel(new BorderLayout(5, 5));
        UIStyle.styleComponent(imagePanel);
        imagePreview.setPreferredSize(new Dimension(PREVIEW_SIZE, PREVIEW_SIZE));
        imagePreview.setBorder(BorderFactory.createLineBorder(UIStyle.FOREGROUND, 1));
        UIStyle.styleComponent(imagePreview);
        imagePanel.add(imagePreview, BorderLayout.CENTER);

        JPanel imageButtons = new JPanel(new java.awt.GridLayout(1, 2, 5, 0));
        UIStyle.styleComponent(imageButtons);
        JButton chooseImageButton = new JButton("Choose Image...");
        UIStyle.styleButton(chooseImageButton);
        chooseImageButton.addActionListener(e -> chooseImage());
        JButton removeImageButton = new JButton("Remove Image");
        UIStyle.styleButton(removeImageButton);
        removeImageButton.addActionListener(e -> removeImage());
        imageButtons.add(chooseImageButton);
        imageButtons.add(removeImageButton);
        imagePanel.add(imageButtons, BorderLayout.SOUTH);

        JPanel centerPanel = new JPanel(new BorderLayout(15, 15));
        UIStyle.styleComponent(centerPanel);
        centerPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        centerPanel.add(formPanel, BorderLayout.CENTER);
        centerPanel.add(imagePanel, BorderLayout.EAST);
        add(centerPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        UIStyle.styleComponent(buttonPanel);
        JButton saveButton = new JButton("Save");
        UIStyle.styleButton(saveButton);
        saveButton.addActionListener(e -> onSave());
        JButton cancelButton = new JButton("Cancel");
        UIStyle.styleButton(cancelButton);
        cancelButton.addActionListener(e -> dispose());
        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void addField(JPanel formPanel, GridBagConstraints gbc, int row, String labelText, JTextField field) {
        gbc.gridx = 0;
        gbc.gridy = row;
        JLabel label = new JLabel(labelText);
        UIStyle.styleComponent(label);
        formPanel.add(label, gbc);

        gbc.gridx = 1;
        UIStyle.styleComponent(field);
        field.setBorder(BorderFactory.createLineBorder(UIStyle.FOREGROUND));
        formPanel.add(field, gbc);
    }

    private void populateFields() {
        if (original != null) {
            nameField.setText(original.getName());
            phoneField.setText(original.getPhone());
            emailField.setText(original.getEmail());
            addressArea.setText(original.getAddress());
        }
        refreshPreview();
    }

    private void chooseImage() {
        JFileChooser chooser = new JFileChooser();
        chooser.setFileFilter(new FileNameExtensionFilter("Image files", "jpg", "jpeg", "png", "gif"));
        int result = chooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            pendingImageFile = chooser.getSelectedFile();
            imageRemoved = false;
            imagePreview.setIcon(ImageUtil.loadScaledIcon(pendingImageFile.getAbsolutePath(), PREVIEW_SIZE, PREVIEW_SIZE));
            imagePreview.setText(null);
        }
    }

    private void removeImage() {
        pendingImageFile = null;
        imageRemoved = true;
        imagePreview.setIcon(null);
        imagePreview.setText("No Image");
    }

    private void refreshPreview() {
        if (currentImagePath != null && !currentImagePath.isEmpty()) {
            var icon = ImageUtil.loadScaledIcon(currentImagePath, PREVIEW_SIZE, PREVIEW_SIZE);
            imagePreview.setIcon(icon);
            imagePreview.setText(icon == null ? "No Image" : null);
        } else {
            imagePreview.setIcon(null);
            imagePreview.setText("No Image");
        }
    }

    private void onSave() {
        if (nameField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Name is required.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (pendingImageFile != null) {
            try {
                currentImagePath = copyImageIntoDataDir(pendingImageFile);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "Could not save image: " + ex.getMessage(),
                        "Image Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        } else if (imageRemoved) {
            currentImagePath = null;
        }

        confirmed = true;
        dispose();
    }

    private String copyImageIntoDataDir(File source) throws IOException {
        String extension = "";
        String sourceName = source.getName();
        int dotIndex = sourceName.lastIndexOf('.');
        if (dotIndex >= 0) {
            extension = sourceName.substring(dotIndex);
        }
        String newName = UUID.randomUUID() + extension;
        Path target = Path.of(Database.getImagesDir(), newName);
        Files.copy(source.toPath(), target, StandardCopyOption.REPLACE_EXISTING);
        return target.toString();
    }
}

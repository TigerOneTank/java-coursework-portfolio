package VehicleRentalApp.model;

/**
 * Checked exception: the compiler forces the controller/view layer to deal
 * with a failed rental instead of silently ignoring a null return.
 */
public class VehicleNotAvailableException extends Exception {

    private static final long serialVersionUID = 1L;

    private final String vehicleId;

    public VehicleNotAvailableException(String vehicleId, String reason) {
        super(reason);
        this.vehicleId = vehicleId;
    }

    public String getVehicleId() {
        return vehicleId;
    }
}

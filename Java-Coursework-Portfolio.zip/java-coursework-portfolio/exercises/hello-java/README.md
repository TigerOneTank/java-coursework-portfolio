# Hello Java

First console greeting retained as part of the learning record.

**Context:** Java coursework and guided learning. Original folder: `JavaIntermediateCourse`.

## What the code demonstrates

Entry points and console output. The original implementation and learning comments are retained; the portfolio packaging is documented in [provenance](../../docs/PROVENANCE.md).

## Run

From the repository root, with Python 3 and a JDK installed:

```sh
python3 tools/portfolio.py build hello-java
python3 tools/portfolio.py run hello-java
```

Windows users can use `py` instead of `python3`. 

Database examples also require the SQLite JDBC runtime described in [setup](../../docs/RUNNING.md). Run each collection separately: several use the same class names.

## Known limitations

A minimal introductory exercise, not a portfolio flagship.

## Learning notes

The useful code-reading focus here is entry points and console output. This README describes the submitted implementation; it does not claim every component was written independently. Personal reflections can be added after reviewing the source.

See [validation](../../docs/VALIDATION.md) for the exact scope of checks.

package Week3;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

class Seat {
    private int row;
    private int col;

    public Seat(int row, int col) {
        this.row = row;
        this.col = col;
    }

    public int getCol() {
        return col;
    }

    public int getRow() {
        return row;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)return  true;
        if (!(obj instanceof Seat)) return false;
        Seat other = (Seat) obj;
        return this.row == other.row && this.col == other.col;
    }

    @Override
    public int hashCode() {
        return Objects.hash(row,col);
    }

    @Override
    public String toString() {
        return "Seat{" +
                "row=" + row +
                ", col=" + col +
                '}';
    }
}

public class ClassroomSeats {
    public static void main() {

        Map<Seat, String> plan = new HashMap<>();
        plan.put(new Seat(1,1), "John");
        plan.put(new Seat(2,2), "Joe");
        plan.put(new Seat(1,2), "Josh");
        plan.put(new Seat(2,1), "Samzzz");

        Seat checkseat = new Seat(2,1);
        System.out.println("Search result: " + plan.get(checkseat));
        checkseat = new Seat(1,2);
        System.out.println("Search Result: " + plan.get(checkseat));


    }
}

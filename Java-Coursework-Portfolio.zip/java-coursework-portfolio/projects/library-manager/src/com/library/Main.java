package com.library;

import com.library.controller.LoginController;
import com.library.dao.Database;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/** Application entry point. */
public class Main {
    public static void main(String[] args) {
        // Create tables and seed data on first run.
        Database.initialize();

        // Use the platform look and feel if available.
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
            // fall back to default
        }

        SwingUtilities.invokeLater(() -> new LoginController().start());
    }
}

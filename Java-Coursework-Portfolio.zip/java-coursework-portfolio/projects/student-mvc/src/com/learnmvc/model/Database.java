package com.learnmvc.model;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public final class Database {

    private static final String URL = "jdbc:sqlite:students.db";
//
//    private Database() { }
//
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL);
    }

    public static void initialize() {
        String createSql =
                "CREATE TABLE IF NOT EXISTS students (" +
                        "  id    INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "  name  TEXT NOT NULL," +
                        "  email TEXT," +
                        "  major TEXT" +
                        ")";
        try (Connection conn = getConnection();
             Statement st = conn.createStatement()) {

            st.execute(createSql);

            try (ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM students")) {
                if (rs.next() && rs.getInt(1) == 0) {
                    st.execute("INSERT INTO students(name,email,major) VALUES " +
                            "('john doe','demo2@example.com','Computer Science')");
                    st.execute("INSERT INTO students(name,email,major) VALUES " +
                            "('jane doe','demo1@example.com','Mathematics')");
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Database initialization failed", e);
        }
    }
}


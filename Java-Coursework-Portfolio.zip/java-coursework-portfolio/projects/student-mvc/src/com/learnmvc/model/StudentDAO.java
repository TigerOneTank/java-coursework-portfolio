package com.learnmvc.model;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class StudentDAO {

    /** READ: return every student, newest id last. */
    public List<Student> findAll() {
        List<Student> list = new ArrayList<>();
        String sql = "SELECT * FROM students ORDER BY id";
        try (Connection conn = Database.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                list.add(map(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("findAll failed.", e);
        }
        return list;
    }

    /** CREATE: insert a new student and return the generated id. */
    public int insert(Student s) {
        System.out.println(s + " is added");
        String sql = "INSERT INTO students (name, email, major) VALUES (?, ?, ?)";
        try (Connection conn = Database.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, s.getName());
            pstmt.setString(2, s.getEmail());
            pstmt.setString(3, s.getMajor());
            pstmt.executeUpdate();

            try (Statement st = conn.createStatement();
                 ResultSet keys = st.executeQuery("SELECT last_insert_rowid()")) {
                if (keys.next()) {
                    return keys.getInt(1);
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Add failed. " + e);
        }

        return -1;
    }

    /** UPDATE: save changes to an existing student (matched by id). */
    public void update(Student s) {
        String sql = "UPDATE students SET name=?, email=?, major=? WHERE id = ?";
        try (Connection conn = Database.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, s.getName());
            pstmt.setString(2, s.getEmail());
            pstmt.setString(3, s.getMajor());
            pstmt.setInt(4, s.getId());
            pstmt.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Update failed. " + e);
        }
    }

    /** DELETE: remove a student by id. */
    public void delete(int id) {
        String sql = "DELETE FROM students WHERE id = ?";
        try (Connection conn = Database.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            pstmt.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Delete failed." + e);
        }
    }


    /** Convert the current row of a ResultSet into a Student object. */
    private Student map(ResultSet rs) throws SQLException {
        return new Student(
                rs.getInt("id"),
                rs.getString("name"),
                rs.getString("email"),
                rs.getString("major"));
    }
}

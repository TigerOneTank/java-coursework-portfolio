package com.learnmvc;

import com.learnmvc.controller.StudentController;
import com.learnmvc.model.Database;
import com.learnmvc.model.Student;
import com.learnmvc.model.StudentDAO;
import com.learnmvc.view.StudentView;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class Main {
    public static void main(String[] args) {
        Database.initialize();

        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
            // default look and feel is fine
        }

        // Swing UI must be built on the Event Dispatch Thread.
        SwingUtilities.invokeLater(() -> {
            StudentDAO model = new StudentDAO();     // MODEL
            StudentView view = new StudentView();    // VIEW

            new StudentController(view, model);
            view.setVisible(true);
        });
    }
}


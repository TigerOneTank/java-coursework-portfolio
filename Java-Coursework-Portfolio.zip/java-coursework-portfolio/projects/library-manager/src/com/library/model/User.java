package com.library.model;

public class User extends Person {
    private String username;
    private String passwordHash;
    private Role role;

    public User(int id, String name, String email,
                String username, String passwordHash, Role role) {
        super(id, name, email);
        this.username = username;
        this.passwordHash = passwordHash;
        this.role = role;
    }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPasswordHash() { return passwordHash; }
    public void setPasswordHash(String passwordHash) { this.passwordHash = passwordHash; }

    public Role getRole() { return role; }
    public void setRole(Role role) { this.role = role; }

    public boolean isAdmin() { return role == Role.ADMIN; }

    @Override
    public String describe() {
        return "User " + username + " (" + role + ")";
    }
}

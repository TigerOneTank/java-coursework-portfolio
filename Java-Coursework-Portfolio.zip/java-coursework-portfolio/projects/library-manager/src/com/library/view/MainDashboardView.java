package com.library.view;

import com.library.model.User;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.SwingConstants;
import java.awt.BorderLayout;
import java.awt.FlowLayout;

public class MainDashboardView extends JFrame {

    private final JButton logoutButton = new JButton("Logout");

    public MainDashboardView(User currentUser, BookView bookView, MemberView memberView, LoanView loanView) {
        setTitle("Library Management System — " + currentUser.getUsername()
                + " (" + currentUser.getRole() + ")");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(820, 560);
        setLocationRelativeTo(null);

        add(buildTopBar(), BorderLayout.NORTH);

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Books", bookView);
        tabs.addTab("Members", memberView);
        tabs.addTab("Loans", loanView);
        add(tabs, BorderLayout.CENTER);

        JLabel status = new JLabel("Signed in as " + currentUser.getName()
                + "  |  Role: " + currentUser.getRole(), SwingConstants.LEFT);
        status.setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));
        add(status, BorderLayout.SOUTH);
    }

    private JPanel buildTopBar() {
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bar.setBorder(BorderFactory.createEmptyBorder(4, 8, 0, 8));
        bar.add(logoutButton);
        return bar;
    }

    public void setOnLogout(Runnable r) { logoutButton.addActionListener(e -> r.run()); }
}

import javax.swing.*;
import java.awt.event.ComponentAdapter;

public class MainScreen extends JFrame{
    private JPanel ContentPane;
    private JLabel Welcome;

    public MainScreen() {
        setContentPane(ContentPane);
        setTitle("MainScreen");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(300, 300);
        setLocationRelativeTo(null);
        setVisible(true);
    }



}

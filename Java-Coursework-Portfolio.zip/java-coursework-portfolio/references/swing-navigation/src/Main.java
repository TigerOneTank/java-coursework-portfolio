
public class Main {
    public static void main(String[] args) {

        SecondScreen screen = new SecondScreen();
    }
}
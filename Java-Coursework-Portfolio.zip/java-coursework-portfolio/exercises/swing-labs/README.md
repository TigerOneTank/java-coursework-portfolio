# Swing Labs

Mixed Swing exercises including calculators, library forms, a password generator, and stock-management UI practice.

**Context:** Java coursework and guided learning. Original folder: `SwingFX`.

## What the code demonstrates

GUI Designer, listeners, and input handling. The original implementation and learning comments are retained; the portfolio packaging is documented in [provenance](../../docs/PROVENANCE.md).

## Run

From the repository root, with Python 3 and a JDK installed:

```sh
python3 tools/portfolio.py build swing-labs
python3 tools/portfolio.py run swing-labs
```

Windows users can use `py` instead of `python3`. For form-backed classes, use IntelliJ GUI Designer to generate the bindings; the helper alone is not a complete build.

Database examples also require the SQLite JDBC runtime described in [setup](../../docs/RUNNING.md). Run each collection separately: several use the same class names.

## Known limitations

Several classes rely on IntelliJ GUI Designer .form generation. Plain javac compiles the Java but does not generate form bindings. Some exercises are incomplete. The password generator uses Random and is not suitable for security use.

## Learning notes

The useful code-reading focus here is gui designer, listeners, and input handling. This README describes the submitted implementation; it does not claim every component was written independently. Personal reflections can be added after reviewing the source.

See [validation](../../docs/VALIDATION.md) for the exact scope of checks.

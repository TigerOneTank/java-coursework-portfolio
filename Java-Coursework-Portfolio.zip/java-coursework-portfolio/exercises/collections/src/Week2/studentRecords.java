package Week2;


import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

class Student {

    private String id;
    private String name;
    private Double GPA;

    public Student(String name, String id, Double GPA) {
        this.name = name;
        this.id = id;
        this.GPA = GPA;
    }

    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    public Double getGPA() {
        return GPA;
    }

    public void setGPA(double GPA) {
        this.GPA = GPA;
    }

    @Override
    public String toString() {
        return "Student{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", GPA=" + GPA +
                '}';
    }

}

public class studentRecords {
    public static void main(String[] args) {
        Map<String, Student> students = new HashMap<>();

        Student s1 = new Student("SOO1","John",3.9);
        Student s2 = new Student("SOO2","Jane",4.0);
        Student s3 = new Student("SOO3","Timmy",3.5);

        students.put(s1.getId(), s1);
        students.put(s2.getId(), s2);
        students.put(s3.getId(), s3);

        System.out.println("Student Records List:");
        for(Map.Entry<String, Student> entry: students.entrySet()) {
            System.out.println(entry.getKey() + "==>" + entry.getValue());
        }

        Scanner scanner = new Scanner(System.in);
        System.out.println("Find the Student Records: ");
        System.out.println("Enter the Student ID: ");
        String ID = scanner.nextLine();

        Student searchStudent = students.get(ID);
        if (searchStudent != null) {
            System.out.println("Student Record:" + searchStudent);
            searchStudent.setGPA(3.5);
            System.out.println("Updated Student Record:" + searchStudent);
        } else {
            System.out.println("Error! Student ID has not been found!");
        }
    }
}



package VehicleRentalApp.controller;

import VehicleRentalApp.model.Rental;

import java.sql.SQLException;
import java.util.List;

/*
 * ReportController.java  -- YOUR TASK  (Step 8)
 *
 * The nine numbers on the Report tab.
 *
 * A fair question: why loop in Java when SQL has SUM()? Because the pricing
 * rules -- GPS fees, the helmet fee, insurance, the loyalty discount, the late
 * penalty -- live in your model classes. Rewriting them as a SUM() would mean
 * two versions of the truth, and the day somebody changes the GPS fee only one
 * of them gets fixed.
 *
 * So: SQL counts rows (see CustomerDao.countLoyal()), Java computes money.
 */
public class ReportController {

    private final RentalController rentalController = new RentalController();
    private final VehicleController vehicleController = new VehicleController();
    private final CustomerController customerController = new CustomerController();

    /*
     * GIVEN: a record is a small immutable data carrier. Java writes the
     * constructor, the getters (called totalRevenue(), not getTotalRevenue())
     * and equals()/toString() for you.
     */
    public record ShopReport(double totalRevenue, int rentalCount, int activeRentals,
                             int insurableVehicles, double totalDiscounts,
                             double totalLateFees, int loyalCustomers,
                             int vehicleCount, int customerCount) {
    }

    public ShopReport build() throws SQLException {
        List<Rental> rentals = rentalController.listAll();

        double revenue = 0;
        double discounts = 0;
        double lateFees = 0;
        int active = 0;

        /*
         * TODO 8.1: one for-each over rentals, adding up four things:
         *
         *      revenue   += r.getTotalCost();      // discounts and late fees
         *                                          // are already inside this
         *      discounts += r.getDiscountAmount();
         *      lateFees  += r.getLateFee();
         *      if (!r.isReturned()) { active++; }  // still out with a customer
         *
         * Do NOT add the discount back on or subtract it again -- getTotalCost()
         * is the final figure. If your revenue looks too big, that is the
         * mistake to look for first.
         */

        for (Rental rental : rentals) {
            revenue += rental.getTotalCost();
            discounts += rental.getDiscountAmount();
            lateFees += rental.getLateFee();
            if (!rental.isReturned()) {
                active++;
            }
        }

        /*
         * TODO 8.2: return a new ShopReport with the nine values, IN THIS
         * ORDER (the record's constructor is positional, and they are all
         * numbers, so the compiler cannot catch a swap -- the Report tab will
         * just show the wrong captions):
         *
         *      revenue,
         *      rentals.size(),
         *      active,
         *      vehicleController.countInsurable(),
         *      discounts,
         *      lateFees,
         *      customerController.countLoyal(),
         *      vehicleController.listAll().size(),
         *      customerController.listAll().size()
         *
         * Notice this controller calls three OTHER controllers and no DAO at
         * all. Controllers are allowed to use each other; that is how the
         * report reuses countInsurable() instead of writing it a second time.
         */

        // placeholder so the app runs before you start -- replace it in 8.2
        return new ShopReport(
                revenue,
                rentals.size(),
                active,
                vehicleController.countInsurable(),
                discounts,
                lateFees,
                customerController.countLoyal(),
                vehicleController.listAll().size(),
                customerController.listAll().size()
        );
    }
}

# Import review checks

These checks were added during portfolio organization, not submitted as original coursework. They cover rental pricing and database initialization and reproduce two known library defects. An expected defect being reproduced is not a claim of correct behavior.

After installing the JDBC dependencies in root `lib/`, build `vehicle-rental` and `library-manager` with `tools/portfolio.py`. Compile `PortfolioChecks.java` with those two output folders and `lib/*` on the classpath. Run the resulting class with the same classpath **from a new disposable empty working directory**. It creates `data/rental.db` and `library.db` in the working directory and intentionally returns a loan twice. Do not run it against an existing database. Once defects are fixed, update these probes to assert the corrected behavior.

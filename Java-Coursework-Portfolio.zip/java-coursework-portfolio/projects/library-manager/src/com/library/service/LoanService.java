package com.library.service;

import com.library.dao.BookDAO;
import com.library.dao.Database;
import com.library.dao.LoanDAO;
import com.library.dao.MemberDAO;
import com.library.model.Book;
import com.library.model.Loan;
import com.library.model.LoanStatus;
import com.library.model.Member;

import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public class LoanService {

    public static final int MAX_BOOKS_PER_MEMBER = 3;
    public static final int LOAN_PERIOD_DAYS = 14;

    private final BookDAO bookDAO = new BookDAO();
    private final MemberDAO memberDAO = new MemberDAO();
    private final LoanDAO loanDAO = new LoanDAO();
    private final FineCalculator fineCalculator = new FineCalculator();
    public Optional<Loan> find(int loanId) {
        return loanDAO.findById(loanId);
    }
    public List<Loan> activeLoansForMember(int memberId) {
        return loanDAO.findActiveByMember(memberId);
    }
    private void rollback(Connection c) {
        if (c != null) {
            try { c.rollback(); } catch (SQLException ignored) { }
        }
    }
    private void closeQuietly(Connection c) {
        if (c != null) {
            try { c.setAutoCommit(true); c.close(); } catch (SQLException ignored) { }
        }
    }

    public Loan issueBook(int memberId, int bookId) {

        System.out.println("Preparing issue book");
        Book book = bookDAO.findById(bookId).orElseThrow();
        Member member = memberDAO.findById(memberId).orElseThrow();

        if (!member.isActive()) {
            throw new IllegalStateException("Member is suspended and cannot make the loan");
        }

        if (member.getBorrowedCount() >= MAX_BOOKS_PER_MEMBER) {
            throw new IllegalStateException("Member already hold max amount of books");
        }

        if (!book.isAvailable()) {
            throw new IllegalStateException("No available copies of this book.");
        }

        // boolean alreadyBorrowed = loanDAO.findActiveByMember()

        LocalDate today = LocalDate.now();
        Loan loan = new Loan(0, bookId, memberId, today, today.plusDays(LOAN_PERIOD_DAYS), null, 0.0, LoanStatus.ACTIVE);
        Connection c = null;
        try {
            c = Database.getConnection();
            c.setAutoCommit(false);
            int id = loanDAO.insert(loan, c);
            bookDAO.decrementAvailable(bookId, c);
            c.commit();
            loan.setId(id);
            return loan;

        } catch (SQLException e) {
            rollback(c);
            throw new RuntimeException("Issue failed" + e.getMessage());
        } finally {
            closeQuietly(c);
        }
    }

    public double returnBook(int loanId) {
        System.out.println("Return this loan " + loanId);
        Loan loan = loanDAO.findById(loanId).orElseThrow(
                () -> new IllegalStateException("Loan not found!!!")
        );

// update the loan object
        LocalDate today = LocalDate.now();
        double fine = fineCalculator.calculate(loan.getDueDate(), today);
        loan.setReturnDate(today);
        loan.setFine(fine);
        loan.setStatus(LoanStatus.RETURNED);
// overwrite (update) to the database
        Connection c = null;
        try {
            c = Database.getConnection();
            c.setAutoCommit(false);
            loanDAO.update(loan, c);
            bookDAO.incrementAvailable(loan.getBookId(), c);
            c.commit();
            return fine;
        } catch (SQLException e) {
            throw new RuntimeException("Return book failed " + e.getMessage());
        } finally {
            closeQuietly(c);
        }
    }


}

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class BacIICalculator extends JFrame{
    private JPanel panel1;
    private JLabel titleLabel;
    private JLabel introLabel;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JTextField textField4;
    private JTextField textField5;
    private JTextField textField6;
    private JButton calculateButton;
    private JTextField textField7;
    private JLabel Result;

    public BacIICalculator () {
        setTitle("BacII Calculator");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(panel1);
        setLocationRelativeTo(null);
        setVisible(true);
        pack();
        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int Math = Integer.parseInt(textField1.getText());
                int Peasakhmer = Integer.parseInt(textField2.getText());
                int Bio = Integer.parseInt(textField3.getText());
                int Roub = Integer.parseInt(textField4.getText());
                int English = Integer.parseInt(textField5.getText());
                int Kimi = Integer.parseInt(textField6.getText());
                int His = Integer.parseInt(textField7.getText());
                String remark;

                int total = Math + Peasakhmer + Bio + Roub + English + Kimi + His;
                if (total >= 237) {
                    remark = "Pass";
                } else {
                    remark = "Fail";
                }
                Result.setText(String.valueOf(total) + " " + remark);
            }
        });
    }


}

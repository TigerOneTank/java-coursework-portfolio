import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class PrintRecords {
    public static void main(String[] args) {

        String url = "jdbc:sqlite:java_db.db";
        var sql = "SELECT * FROM products";

        try (var conn = DriverManager.getConnection(url)){

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            String myFormat = "%-2s%-10s%-5s%-3.2f%n";
            System.out.printf("%-2s%-10s%-5s%-6s%n","ID","NAME","AMT","PRICE");

            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                int amount = rs.getInt("amount");
                double price = rs.getDouble("price");
//                System.out.println(id + " " + name + " " + amount + " " + price);
                System.out.printf(myFormat,id,name,amount,price);
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}

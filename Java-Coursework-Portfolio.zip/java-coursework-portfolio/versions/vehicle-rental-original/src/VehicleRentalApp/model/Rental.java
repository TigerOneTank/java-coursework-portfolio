package VehicleRentalApp.model;

/*
 * Rental.java  -- YOUR TASK  (Step 5)
 *
 * One booking. HAS-A Customer and HAS-A Vehicle: two composition
 * relationships in one small class.
 *
 * This is where the bill is built, and it is the most important file in the
 * project for one reason: NO PRICE IS EVER STORED IN THE DATABASE. The
 * rentals table holds days, returned, actual_days and discount_rate -- the
 * money is worked out here, every time, from the rules in the vehicle
 * subclasses. So the pricing rules exist in exactly one place.
 *
 * THE BILL, top to bottom:
 *
 *      rental cost        vehicle.calculateRentalCost(days)   <- polymorphic
 *    + insurance          only if the vehicle signed Insurable
 *    = SUBTOTAL
 *    - discount           subtotal * discountRate
 *    + late fee           extra days, charged at 120% of the daily rate
 *    = TOTAL
 */
public class Rental {

    private final String rentalId;
    private final Customer customer;
    private final Vehicle vehicle;
    private final int days;             // days the customer BOOKED
    private boolean returned;
    private int actualDays;             // days actually kept; 0 until returned
    private final double discountRate;
    private final String createdAt;

    /** Late days cost the daily rate plus this much again: 20% penalty. */
    public static final double LATE_PENALTY_RATE = 0.20;

    // ---- GIVEN: the two constructors -------------------------------------

    /**
     * A brand new booking. The discount is worked out ONCE, here, and then
     * frozen -- see the comment on discountRate below.
     */
    public Rental(String rentalId, Customer customer, Vehicle vehicle, int days) {
        this(rentalId, customer, vehicle, days, false, 0, rateFor(customer), null);
    }

    /** Rebuilt from a row in the rentals table -- the stored rate is trusted. */
    public Rental(String rentalId, Customer customer, Vehicle vehicle, int days,
                  boolean returned, int actualDays, double discountRate, String createdAt) {
        this.rentalId = rentalId;
        this.customer = customer;
        this.vehicle = vehicle;
        this.days = days;
        this.returned = returned;
        this.actualDays = actualDays;
        this.discountRate = discountRate;
        this.createdAt = createdAt;
    }

    /*
     * GIVEN. Note the parameter type: Discountable, not Customer. This method
     * asks the CONTRACT, so anything that signs it prices the same way.
     */
    private static double rateFor(Discountable d) {
        return d != null && d.qualifiesForDiscount() ? d.getDiscountRate() : 0.0;
    }

    // ---- GIVEN: plain getters --------------------------------------------

    public String getRentalId() {
        return rentalId;
    }

    public Customer getCustomer() {
        return customer;
    }

    public String getCustomerName() {
        return customer.getName();
    }

    public Vehicle getVehicle() {
        return vehicle;
    }

    public int getDays() {
        return days;
    }

    public boolean isReturned() {
        return returned;
    }

    public int getActualDays() {
        return actualDays;
    }

    public String getCreatedAt() {
        return createdAt == null ? "" : createdAt;
    }

    /** The rate that was frozen at booking time. */
    public double getDiscountRate() {
        return discountRate;
    }

    /** Called by RentalController when the vehicle comes back. */
    public void markReturned(int actualDays) {
        this.returned = true;
        this.actualDays = actualDays;
    }

    // ---- YOUR TASK: the bill ---------------------------------------------

    /**
     * Insurance for this booking, or 0 when the vehicle is not insurable.
     */
    public double getInsuranceCost() {
        /*
         * TODO 5.1: ask whether the vehicle signed the Insurable contract, and
         * if it did, ask it for the number:
         *
         *      if (vehicle instanceof Insurable) {
         *          return ((Insurable) vehicle).calculateInsurance(days);
         *      }
         *      return 0;
         *
         * Read that twice. The code never says "if (vehicle instanceof Truck)".
         * It asks "CAN this be insured?", not "WHAT is this?". Motorbikes and
         * bicycles never signed the contract, so they land on the 0 -- and
         * when you add a fifth vehicle type next week, this method does not
         * change.
         */
        if (vehicle instanceof Insurable) {
            return ((Insurable) vehicle).calculateInsurance(days);
        }
        return 0;
    }

    /** Name of the policy for the receipt, or "no cover". */
    public String getPolicyLabel() {
        // TODO 5.2: same instanceof question as 5.1, but return
        //           getPolicyName(); otherwise return "no cover".
        if (vehicle instanceof Insurable) {
            return ((Insurable) vehicle).getPolicyName();
        }
        return "no cover";
    }

    /** Rental cost plus insurance, before any discount or late fee. */
    public double getSubtotal() {
        /*
         * TODO 5.3: vehicle.calculateRentalCost(days) + getInsuranceCost()
         *
         * One line, and it is the best line in the project. This class prices
         * a Car, a Truck, a Motorbike and a Bicycle without a single if.
         * Each vehicle already knows its own formula; Rental just asks.
         */
        return vehicle.calculateRentalCost(days) + getInsuranceCost();
    }

    /** Money off, in dollars. */
    public double getDiscountAmount() {
        // TODO 5.4: getSubtotal() * discountRate
        //
        // The discount applies to the WHOLE subtotal, insurance included --
        // check the guide's pricing table if you are unsure.
        return getSubtotal() * discountRate;
    }

    /** Days kept beyond the booking. 0 when on time or not yet back. */
    public int getExtraDays() {
        /*
         * TODO 5.5: return 0 when the vehicle is not back yet OR when
         * actualDays <= days. Otherwise return actualDays - days.
         *
         * Both guards matter. actualDays is 0 until the vehicle is returned,
         * so without the !returned check an outstanding rental would report a
         * NEGATIVE number of extra days and the late fee would come out as a
         * refund.
         */
        if (!returned || actualDays <= days) {
            return 0;
        }
        return actualDays - days;
    }

    /** Penalty for keeping it too long: extra days at 120% of the daily rate. */
    public double getLateFee() {
        // TODO 5.6: getExtraDays() * vehicle.getDailyRate() * (1 + LATE_PENALTY_RATE)
        //
        // Worked example: C01 costs $33/day, booked 3 days, kept 5.
        //      2 extra days * 33.00 * 1.20 = $79.20
        // Use this to check your work in the app.
        return getExtraDays() * vehicle.getDailyRate() * (1 + LATE_PENALTY_RATE);
    }

    /** What the customer actually pays. */
    public double getTotalCost() {
        // TODO 5.7: subtotal - discount + late fee
        //
        // Mind the signs. A discount comes OFF, a late fee goes ON.
        return getSubtotal() - getDiscountAmount() + getLateFee();
    }

    // ---- GIVEN: the receipt shown in the Rentals tab ---------------------

    public String toReceipt() {
        StringBuilder sb = new StringBuilder();
        sb.append("RECEIPT  ").append(rentalId).append('\n');
        sb.append("--------------------------------------------\n");
        sb.append(String.format("Customer   : %s (%s)%n",
                customer.getName(), customer.getDiscountLabel()));
        sb.append(String.format("Vehicle    : %s%n", vehicle.describe()));
        sb.append(String.format("Booked     : %d day(s)%n", days));
        sb.append("--------------------------------------------\n");
        sb.append(String.format("Rental     : $%.2f%n", vehicle.calculateRentalCost(days)));
        sb.append(String.format("Insurance  : $%.2f  (%s)%n", getInsuranceCost(), getPolicyLabel()));
        sb.append(String.format("Subtotal   : $%.2f%n", getSubtotal()));
        if (getDiscountAmount() > 0) {
            sb.append(String.format("Discount   : -$%.2f%n", getDiscountAmount()));
        }
        if (getLateFee() > 0) {
            sb.append(String.format("Late (%dd)  : $%.2f%n", getExtraDays(), getLateFee()));
        }
        sb.append("--------------------------------------------\n");
        sb.append(String.format("TOTAL      : $%.2f%n", getTotalCost()));
        return sb.toString();
    }

    @Override
    public String toString() {
        return rentalId + " - " + customer.getName() + " - " + vehicle.getId();
    }
}
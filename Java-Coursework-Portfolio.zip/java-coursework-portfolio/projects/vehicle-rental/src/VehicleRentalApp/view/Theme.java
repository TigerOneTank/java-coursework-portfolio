package VehicleRentalApp.view;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.table.JTableHeader;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Insets;

/**
 * The whole look of the app in one file: black text on white, one grey for
 * borders, one grey for muted text. No gradients, no accent colour.
 *
 * Keeping every colour and font here means changing the theme is a one-file
 * edit, not a hunt through six panels.
 */
public final class Theme {

    // ---- palette ----------------------------------------------------------
    public static final Color BLACK      = new Color(0x000000);
    public static final Color WHITE      = new Color(0xFFFFFF);
    public static final Color GREY_LINE  = new Color(0xD4D4D4);   // borders, grid
    public static final Color GREY_MUTED = new Color(0x767676);   // secondary text
    public static final Color GREY_ROW   = new Color(0xF5F5F5);   // zebra stripe
    public static final Color GREY_HOVER = new Color(0xEBEBEB);

    // ---- type -------------------------------------------------------------
    private static final String FAMILY = "SansSerif";
    public static final Font FONT_TITLE  = new Font(FAMILY, Font.BOLD, 20);
    public static final Font FONT_HEADER = new Font(FAMILY, Font.BOLD, 12);
    public static final Font FONT_BODY   = new Font(FAMILY, Font.PLAIN, 13);
    public static final Font FONT_SMALL  = new Font(FAMILY, Font.PLAIN, 11);
    public static final Font FONT_MONO   = new Font(Font.MONOSPACED, Font.PLAIN, 12);

    private Theme() {
    }

    /**
     * Applied once at start-up, before any window is built. Overriding the
     * UIDefaults is what stops the platform look and feel from painting its
     * own blues over our black and white.
     */
    public static void install() {
        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        } catch (Exception e) {
            // the default look and feel will do; the overrides below still apply
        }

        UIManager.put("control", WHITE);
        UIManager.put("nimbusBase", BLACK);
        UIManager.put("Panel.background", WHITE);
        UIManager.put("OptionPane.background", WHITE);
        UIManager.put("OptionPane.messageForeground", BLACK);
        UIManager.put("Label.foreground", BLACK);
        UIManager.put("Label.font", FONT_BODY);
        UIManager.put("TextField.font", FONT_BODY);
        UIManager.put("TextField.caretForeground", BLACK);
        UIManager.put("ComboBox.font", FONT_BODY);
        UIManager.put("ComboBox.background", WHITE);
        UIManager.put("ComboBox.foreground", BLACK);
        UIManager.put("ComboBox.selectionBackground", BLACK);
        UIManager.put("ComboBox.selectionForeground", WHITE);
        UIManager.put("Button.font", FONT_BODY);
        UIManager.put("TabbedPane.font", FONT_HEADER);
        UIManager.put("TabbedPane.background", WHITE);
        UIManager.put("TabbedPane.foreground", BLACK);
        UIManager.put("TabbedPane.selected", WHITE);
        UIManager.put("TabbedPane.contentAreaColor", WHITE);
        UIManager.put("TabbedPane.light", GREY_LINE);
        UIManager.put("TabbedPane.darkShadow", GREY_LINE);
        UIManager.put("TabbedPane.shadow", GREY_LINE);
        UIManager.put("TabbedPane.focus", BLACK);
        UIManager.put("Table.font", FONT_BODY);
        UIManager.put("Table.gridColor", GREY_LINE);
        UIManager.put("TableHeader.font", FONT_HEADER);
        UIManager.put("ScrollBar.thumb", GREY_MUTED);
        UIManager.put("ScrollBar.track", WHITE);
        UIManager.put("ScrollPane.background", WHITE);
        UIManager.put("Viewport.background", WHITE);
        UIManager.put("TextArea.font", FONT_MONO);
        UIManager.put("ToolTip.background", BLACK);
        UIManager.put("ToolTip.foreground", WHITE);
    }

    // ---- component factories ---------------------------------------------

    /** Big heading at the top of a panel. */
    public static JLabel title(String text) {
        JLabel l = new JLabel(text);
        l.setFont(FONT_TITLE);
        l.setForeground(BLACK);
        return l;
    }

    /** Grey explanatory line under a title. */
    public static JLabel subtitle(String text) {
        JLabel l = new JLabel(text);
        l.setFont(FONT_SMALL);
        l.setForeground(GREY_MUTED);
        return l;
    }

    public static JLabel label(String text) {
        JLabel l = new JLabel(text);
        l.setFont(FONT_BODY);
        l.setForeground(BLACK);
        return l;
    }

    /** White button, black text, thin black outline. */
    public static JButton button(String text) {
        return styleButton(new JButton(text), false);
    }

    /** Black button, white text -- for the one main action on a panel. */
    public static JButton primaryButton(String text) {
        return styleButton(new JButton(text), true);
    }

    private static JButton styleButton(JButton b, boolean filled) {
        b.setFont(FONT_BODY);
        b.setFocusPainted(false);
        b.setContentAreaFilled(false);
        b.setOpaque(true);
        b.setBackground(filled ? BLACK : WHITE);
        b.setForeground(filled ? WHITE : BLACK);
        b.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BLACK, 1),
                BorderFactory.createEmptyBorder(6, 14, 6, 14)));
        b.setMargin(new Insets(0, 0, 0, 0));
        b.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.HAND_CURSOR));

        Color idle = b.getBackground();
        b.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent e) {
                if (b.isEnabled()) {
                    b.setBackground(filled ? GREY_MUTED : GREY_HOVER);
                }
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent e) {
                b.setBackground(idle);
            }
        });
        return b;
    }

    public static JTextField textField(int columns) {
        JTextField f = new JTextField(columns);
        f.setFont(FONT_BODY);
        f.setForeground(BLACK);
        f.setBackground(WHITE);
        f.setCaretColor(BLACK);
        f.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(GREY_LINE, 1),
                BorderFactory.createEmptyBorder(5, 7, 5, 7)));
        return f;
    }

    /** Black header, zebra rows, black selection. */
    public static JTable table(javax.swing.table.TableModel model) {
        JTable t = new JTable(model);
        t.setFont(FONT_BODY);
        t.setForeground(BLACK);
        t.setBackground(WHITE);
        t.setRowHeight(26);
        t.setShowGrid(false);
        t.setShowHorizontalLines(true);
        t.setGridColor(GREY_LINE);
        t.setIntercellSpacing(new java.awt.Dimension(0, 0));
        t.setSelectionBackground(BLACK);
        t.setSelectionForeground(WHITE);
        t.setAutoCreateRowSorter(true);
        t.getTableHeader().setReorderingAllowed(false);

        JTableHeader header = t.getTableHeader();
        header.setFont(FONT_HEADER);
        header.setBackground(BLACK);
        header.setForeground(WHITE);
        header.setPreferredSize(new java.awt.Dimension(0, 30));
        header.setBorder(BorderFactory.createEmptyBorder());
        ((javax.swing.table.DefaultTableCellRenderer) header.getDefaultRenderer())
                .setHorizontalAlignment(javax.swing.SwingConstants.LEFT);

        // zebra striping, applied to whatever the column renders
        t.setDefaultRenderer(Object.class, new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean selected, boolean focused, int row, int column) {
                Component c = super.getTableCellRendererComponent(
                        table, value, selected, focused, row, column);
                if (!selected) {
                    c.setBackground(row % 2 == 0 ? WHITE : GREY_ROW);
                    c.setForeground(BLACK);
                }
                setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 8));
                return c;
            }
        });
        return t;
    }

    /** Wraps a table (or anything) in a thin bordered scroll pane. */
    public static JScrollPane scroll(Component view) {
        JScrollPane sp = new JScrollPane(view);
        sp.setBorder(BorderFactory.createLineBorder(GREY_LINE, 1));
        sp.getViewport().setBackground(WHITE);
        sp.setBackground(WHITE);
        return sp;
    }

    /** Titled box used to group the form fields. */
    public static Border groupBorder(String title) {
        return BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(
                        BorderFactory.createLineBorder(GREY_LINE, 1),
                        title, javax.swing.border.TitledBorder.LEFT,
                        javax.swing.border.TitledBorder.TOP, FONT_HEADER, BLACK),
                BorderFactory.createEmptyBorder(10, 12, 12, 12));
    }

    public static Border pagePadding() {
        return BorderFactory.createEmptyBorder(18, 20, 18, 20);
    }
}

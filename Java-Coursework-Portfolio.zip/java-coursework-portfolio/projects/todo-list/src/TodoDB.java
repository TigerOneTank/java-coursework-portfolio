import java.sql.*;
import java.util.ArrayList;

public class TodoDB {
    public static Connection getConnection() throws SQLException {
        String url = "jdbc:sqlite:tododb.db";
        Connection conn = DriverManager.getConnection(url);
        return conn;
    }

    public static void createTodoTable() {
        String sql = "CREATE TABLE IF NOT EXISTS todo ("
                + "id INTEGER PRIMARY KEY,"
                + "name TEXT NOT NULL,"
                + "description TEXT NOT NULL,"
                + "done BOOLEAN NOT NULL);";
        try (Connection conn = getConnection()) {
            Statement stmt = conn.createStatement();
            stmt.execute(sql);
            System.out.println("New Table has been created!");
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    public static boolean addTodo(Todo todo) {
        String sql = "INSERT INTO Todo (id, name, description, done)"
                + "VALUES (?,?,?,?);";
        try (Connection conn = getConnection()) {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, todo.getId());
            ps.setString(2, todo.getName());
            ps.setString(3, todo.getDescription());
            ps.setBoolean(4, todo.getDone());
            ps.executeUpdate();
            System.out.println("One record is added to the table.");
            return true;

        } catch (SQLException e) {
            System.out.println(e);
            return false;
        }
    }

    public static ArrayList<Todo> getAllTodos() {
        String sql = "SELECT * FROM Todo";
        ArrayList<Todo> todos = new ArrayList<>();
        try (Connection conn = getConnection()) {
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String description = rs.getString("description");
                boolean done = rs.getBoolean("done");
                Todo todo = new Todo(id, name, description, done);
                todos.add(todo);
            }
            return todos;
        } catch (SQLException e) {
            System.out.println(e);
            return null;
        }
    }

    public static boolean deleteTodo(int id) {
        String sql = "DELETE FROM Todo WHERE id = ?;";

        try (Connection conn = getConnection()) {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();

            System.out.println("One record is deleted from the table.");
            return true;
        } catch (SQLException e) {
            System.out.println(e);
            return false;
        }
    }

    public static boolean updateTodo(Todo todo) {
        String sql = "UPDATE Todo SET name = ?, description = ?, done = ? WHERE id = ?;";
        try (Connection conn = getConnection()) {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, todo.getName());
            ps.setString(2, todo.getDescription());
            ps.setBoolean(3, todo.getDone());
            ps.setInt(4, todo.getId());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println(e);
            return false;
        }
    }

    public static Todo getOneTodo(int id) {
        ArrayList<Todo> todos = getAllTodos();
        for (Todo todo : todos) {
            if (todo.getId() == id) {
                return todo;
            }
        }
        return null;
    }
}

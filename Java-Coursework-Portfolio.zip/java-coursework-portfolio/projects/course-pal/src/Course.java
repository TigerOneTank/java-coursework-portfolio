public class Course {
    private String code;
    private String name;
    private String description;
    private int capacity;
    private int terms;
    private double price;

    public Course(String code, String name, String description, int capacity, int terms, double price) {
        this.code = code;
        this.name = name;
        this.description = description;
        this.capacity = capacity;
        this.terms = terms;
        this.price = price;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public int getTerms() {
        return terms;
    }

    public void setTerms(int terms) {
        this.terms = terms;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double prices) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "Course{" +
                "code='" + code + '\'' +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", capacity=" + capacity +
                ", terms=" + terms +
                ", prices=" + price +
                '}';
    }
}

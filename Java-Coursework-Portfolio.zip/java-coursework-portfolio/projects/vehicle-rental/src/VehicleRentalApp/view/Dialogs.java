package VehicleRentalApp.view;

import javax.swing.JOptionPane;
import java.awt.Component;

/**
 * All the message boxes in one place, so error handling reads the same
 * everywhere and the wording stays consistent.
 */
public final class Dialogs {

    private Dialogs() {
    }

    public static void info(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "Vehicle Rental Shop",
                JOptionPane.INFORMATION_MESSAGE);
    }

    public static void warn(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "Please check",
                JOptionPane.WARNING_MESSAGE);
    }

    /** For anything the user cannot fix -- normally a SQLException. */
    public static void error(Component parent, String message, Throwable cause) {
        String text = message;
        if (cause != null && cause.getMessage() != null) {
            text += "\n\n" + cause.getMessage();
        }
        JOptionPane.showMessageDialog(parent, text, "Something went wrong",
                JOptionPane.ERROR_MESSAGE);
    }

    public static boolean confirm(Component parent, String question) {
        return JOptionPane.showConfirmDialog(parent, question, "Confirm",
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE)
                == JOptionPane.YES_OPTION;
    }
}

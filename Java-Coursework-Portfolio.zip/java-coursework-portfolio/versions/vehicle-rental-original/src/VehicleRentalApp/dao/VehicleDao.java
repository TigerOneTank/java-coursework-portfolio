package VehicleRentalApp.dao;

import VehicleRentalApp.model.Bicycle;
import VehicleRentalApp.model.Car;
import VehicleRentalApp.model.Motorbike;
import VehicleRentalApp.model.Truck;
import VehicleRentalApp.model.Vehicle;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/*
 * VehicleDao.java  -- YOUR TASK  (Step 2)
 *
 * Keep CustomerDao.java open beside this file. Every habit you need is
 * already demonstrated there.
 *
 * This DAO is the interesting one, because the vehicles table is FLAT and the
 * Vehicle hierarchy is NOT. Turning one row into the right subclass is the
 * whole job of map(), and it is the only place in the entire project that is
 * allowed to switch on the vehicle type.
 *
 * Why is that switch acceptable here when the guide told you to avoid
 * "if (v instanceof Car)" everywhere else? Because this is the BOUNDARY where
 * objects stop being objects and become rows. Somebody has to do the
 * translation. Doing it once, here, is what keeps the other twenty files free
 * of type checks. Doing it in ten places is the bug factory the guide warned
 * you about.
 */
public class VehicleDao {

    // GIVEN: listing the columns once keeps the SELECTs and the INSERT in step
    private static final String COLUMNS =
            "id, type, brand, model, daily_rate, available, seats, has_gps, load_tons, engine_cc, gears";

    // ---- the four finders -------------------------------------------------

    public List<Vehicle> findAll() throws SQLException {
        // TODO 2.1: return query("SELECT " + COLUMNS + " FROM vehicles ORDER BY id")
        //           (query() is written for you at the bottom of this file)
        return query("SELECT " + COLUMNS + " FROM vehicles ORDER BY id");
    }

    public List<Vehicle> findAvailable() throws SQLException {
        // TODO 2.2: same as 2.1 but add   WHERE available = 1   before ORDER BY.
        // Remember SQLite has no boolean: available is 1 or 0.
        return query("SELECT " + COLUMNS + " FROM vehicles WHERE available = 1 ORDER BY id");
    }

    /** Cheapest first -- the SQL version of Collections.sort(vehicles). */
    public List<Vehicle> findAllSortedByRate() throws SQLException {
        // TODO 2.3: same as 2.1 but ORDER BY daily_rate, id
        //
        // Compare this one line with the compareTo() you wrote in Vehicle.java:
        // "ORDER BY daily_rate, id" and "compare rate, then break the tie on id"
        // are the same rule written in two languages.
        return query("SELECT " + COLUMNS + " FROM vehicles ORDER BY daily_rate, id");
    }

    public Vehicle findById(String id) throws SQLException {
        // TODO 2.4: copy the shape of CustomerDao.findByName().
        //   - SELECT ... FROM vehicles WHERE id = ?
        //   - ps.setString(1, id)
        //   - return rs.next() ? map(rs) : null;
        String sql = "SELECT " + COLUMNS + " FROM vehicles WHERE id = ?";
        try (PreparedStatement ps = Database.getConnection().prepareStatement(sql)) {
            ps.setString(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }

    // ---- writing ----------------------------------------------------------

    /**
     * Saves a new vehicle.
     *
     * Eleven columns, so eleven ? placeholders. The first six are easy. The
     * last five are the per-subclass ones and MOST OF THEM MUST BE NULL:
     * a motorbike row has no seats, no GPS, no tonnage and no gears.
     */
    public void insert(Vehicle v) throws SQLException {
        String sql = "INSERT INTO vehicles (" + COLUMNS + ") VALUES (?,?,?,?,?,?,?,?,?,?,?)";
        try (PreparedStatement ps = Database.getConnection().prepareStatement(sql)) {

            // TODO 2.5a: set parameters 1-6 from the Vehicle:
            //      1 id, 2 getType(), 3 brand, 4 model, 5 dailyRate,
            //      6 available  -> ps.setInt(6, v.isAvailable() ? 1 : 0)
            //
            // Notice you call v.getType() without asking what class v is.
            // The object answers for itself -- that is polymorphism, and it is
            // why this half of the method needs no if-statements at all.
            ps.setString(1, v.getId());
            ps.setString(2, v.getType());
            ps.setString(3, v.getBrand());
            ps.setString(4, v.getModel());
            ps.setDouble(5, v.getDailyRate());
            ps.setInt(6, v.isAvailable() ? 1 : 0);

            // TODO 2.5b: set parameters 7-11, the per-type columns.
            //
            // Use the two helpers at the bottom, which write a real SQL NULL
            // when you hand them null. Java's pattern-matching instanceof
            // gives you the typed variable in one step:
            //
            //   setNullableInt(ps, 7, v instanceof Car c ? c.getSeats() : null);
            //
            // read as: "if v is a Car, call it c and use c.getSeats();
            //           otherwise store NULL".
            //
            //       7  seats      Car.getSeats()
            //       8  has_gps    Car.hasGps() ? 1 : 0
            //       9  load_tons  Truck.getLoadTons()      (setNullableDouble)
            //      10  engine_cc  Motorbike.getEngineCc()
            //      11  gears      Bicycle.getGears()
            setNullableInt(ps, 7, v instanceof Car car ? car.getSeats() : null);
            setNullableInt(ps, 8, v instanceof Car car ? (car.hasGps() ? 1 : 0) : null);
            setNullableDouble(ps, 9, v instanceof Truck truck ? truck.getLoadTons() : null);
            setNullableInt(ps, 10, v instanceof Motorbike motorbike ? motorbike.getEngineCc() : null);
            setNullableInt(ps, 11, v instanceof Bicycle bicycle ? bicycle.getGears() : null);

            // TODO 2.5c: ps.executeUpdate();
            ps.executeUpdate();
        }
    }

    /**
     * Flips the availability flag. Called on every rent and every return.
     *
     * In the console version this was v.setAvailable(false) and the classic
     * bug was forgetting the line. Here it is one UPDATE -- and forgetting it
     * means the vehicle can be rented to two people at once.
     */
    public void updateAvailability(String vehicleId, boolean available) throws SQLException {
        // TODO 2.6: copy the shape of CustomerDao.updateRentalCount().
        //      UPDATE vehicles SET available = ? WHERE id = ?
        //      parameter 1 is  available ? 1 : 0
        String sql = "UPDATE vehicles SET available = ? WHERE id = ?";
        try (PreparedStatement ps = Database.getConnection().prepareStatement(sql)) {
            ps.setInt(1, available ? 1 : 0);
            ps.setString(2, vehicleId);
            ps.executeUpdate();
        }
    }

    // ---- GIVEN below this line: read, do not change ----------------------

    /** True when that id is already taken -- used to reject duplicates. */
    public boolean exists(String id) throws SQLException {
        try (PreparedStatement ps = Database.getConnection()
                .prepareStatement("SELECT 1 FROM vehicles WHERE id = ?")) {
            ps.setString(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    /**
     * Refuses to delete a vehicle that still has rental history, because
     * those receipts point at this row. Deleting it would leave them pointing
     * at nothing -- the foreign key would be broken.
     */
    public boolean delete(String id) throws SQLException {
        try (PreparedStatement ps = Database.getConnection()
                .prepareStatement("SELECT 1 FROM rentals WHERE vehicle_id = ?")) {
            ps.setString(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return false;
                }
            }
        }
        try (PreparedStatement ps = Database.getConnection()
                .prepareStatement("DELETE FROM vehicles WHERE id = ?")) {
            ps.setString(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    /** Runs a SELECT and maps every row. Used by TODO 2.1, 2.2 and 2.3. */
    private List<Vehicle> query(String sql) throws SQLException {
        List<Vehicle> list = new ArrayList<>();
        try (PreparedStatement ps = Database.getConnection().prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(map(rs));
            }
        }
        return list;
    }

    // ---- the heart of this class -----------------------------------------

    /** One flat row -> the right subclass. */
    private Vehicle map(ResultSet rs) throws SQLException {
        String id = rs.getString("id");
        String type = rs.getString("type");
        String brand = rs.getString("brand");
        String model = rs.getString("model");
        double rate = rs.getDouble("daily_rate");

        /*
         * TODO 2.7: build the right object from the 'type' column.
         *
         * A switch expression (Java 14+) returns a value, so the whole thing
         * is one assignment. The "Car" arm is done for you:
         *
         *      Vehicle v = switch (type) {
         *          case "Car" -> new Car(id, brand, model, rate,
         *                  rs.getInt("seats"), rs.getInt("has_gps") == 1);
         *          case "Truck" -> ...          rs.getDouble("load_tons")
         *          case "Motorbike" -> ...      rs.getInt("engine_cc")
         *          case "Bicycle" -> ...        rs.getInt("gears")
         *          default -> throw new SQLException("Unknown vehicle type: " + type);
         *      };
         *
         * Careful with Bicycle: its constructor takes NO rate, because every
         * bicycle is the same flat price. Look at Bicycle.java if unsure.
         *
         * Do not forget the 'default' arm. Without it the code will not
         * compile -- a switch expression must produce a value for every input.
         *
         * TODO 2.8: the row also carries the availability flag, and the
         * constructors all default it to true. Before returning, do:
         *
         *      v.setAvailable(rs.getInt("available") == 1);
         *
         * Forget this line and every rented vehicle looks free again the next
         * time you start the app.
         */

        Vehicle vehicle = switch (type) {
            case "Car" -> new Car(id, brand, model, rate,
                    rs.getInt("seats"), rs.getInt("has_gps") == 1);
            case "Truck" -> new Truck(id, brand, model, rate,
                    rs.getDouble("load_tons"));
            case "Motorbike" -> new Motorbike(id, brand, model, rate,
                    rs.getInt("engine_cc"));
            case "Bicycle" -> new Bicycle(id, brand, model,
                    rs.getInt("gears"));
            default -> throw new SQLException("Unknown vehicle type: " + type);
        };

        vehicle.setAvailable(rs.getInt("available") == 1);
        return vehicle;
    }

    // ---- GIVEN: helpers that write a real SQL NULL -----------------------

    /*
     * Why these exist: ps.setInt() cannot take null, because int is a
     * primitive. The Integer wrapper can be null, so these methods accept an
     * Integer/Double, and call ps.setNull() when it is missing.
     */
    private void setNullableInt(PreparedStatement ps, int index, Integer value) throws SQLException {
        if (value == null) {
            ps.setNull(index, java.sql.Types.INTEGER);
        } else {
            ps.setInt(index, value);
        }
    }

    private void setNullableDouble(PreparedStatement ps, int index, Double value) throws SQLException {
        if (value == null) {
            ps.setNull(index, java.sql.Types.REAL);
        } else {
            ps.setDouble(index, value);
        }
    }
}

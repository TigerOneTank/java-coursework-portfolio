package VehicleRentalApp.view;

import VehicleRentalApp.controller.VehicleController;
import VehicleRentalApp.model.Bicycle;
import VehicleRentalApp.model.Car;
import VehicleRentalApp.model.Motorbike;
import VehicleRentalApp.model.Truck;
import VehicleRentalApp.model.Vehicle;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.sql.SQLException;

/**
 * VIEW: the "add a vehicle" form.
 *
 * The extra field at the bottom changes with the chosen type -- a Car needs
 * seats and GPS, a Truck needs tonnage, a Bicycle needs neither a rate nor
 * anything else, because every bicycle is the same flat price.
 */
public class AddVehicleDialog extends JDialog {

    private static final String[] TYPES = {"Car", "Motorbike", "Truck", "Bicycle"};

    private final VehicleController controller;

    private final JComboBox<String> typeBox = new JComboBox<>(TYPES);
    private final JTextField idField = Theme.textField(10);
    private final JTextField brandField = Theme.textField(14);
    private final JTextField modelField = Theme.textField(14);
    private final JTextField rateField = Theme.textField(8);

    private final JTextField seatsField = Theme.textField(6);
    private final JCheckBox gpsBox = new JCheckBox("has GPS");
    private final JTextField tonsField = Theme.textField(6);
    private final JTextField ccField = Theme.textField(6);
    private final JTextField gearsField = Theme.textField(6);

    private final JPanel extrasPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
    private final JLabel rateLabel = Theme.label("Daily rate ($)");

    private boolean saved = false;
    private String savedId;

    public AddVehicleDialog(MainFrame owner, VehicleController controller) {
        super(owner, "Add a vehicle", true);
        this.controller = controller;

        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        getContentPane().setBackground(Theme.WHITE);
        setLayout(new BorderLayout(0, 12));
        ((JPanel) getContentPane()).setBorder(Theme.pagePadding());

        add(buildForm(), BorderLayout.CENTER);
        add(buildButtons(), BorderLayout.SOUTH);

        typeBox.addActionListener(e -> updateExtras());
        updateExtras();

        pack();
        setMinimumSize(new Dimension(430, getHeight()));
        setLocationRelativeTo(owner);
    }

    private JPanel buildForm() {
        JPanel fields = new JPanel(new GridLayout(0, 2, 10, 10));
        fields.setBackground(Theme.WHITE);

        fields.add(Theme.label("Type"));
        fields.add(typeBox);
        fields.add(Theme.label("Vehicle ID"));
        fields.add(idField);
        fields.add(Theme.label("Brand"));
        fields.add(brandField);
        fields.add(Theme.label("Model"));
        fields.add(modelField);
        fields.add(rateLabel);
        fields.add(rateField);

        extrasPanel.setBackground(Theme.WHITE);
        gpsBox.setBackground(Theme.WHITE);
        gpsBox.setForeground(Theme.BLACK);
        gpsBox.setFont(Theme.FONT_BODY);
        gpsBox.setFocusPainted(false);

        JPanel wrapper = new JPanel();
        wrapper.setLayout(new BoxLayout(wrapper, BoxLayout.Y_AXIS));
        wrapper.setBackground(Theme.WHITE);
        wrapper.setBorder(Theme.groupBorder("Vehicle details"));
        fields.setAlignmentX(LEFT_ALIGNMENT);
        extrasPanel.setAlignmentX(LEFT_ALIGNMENT);
        wrapper.add(fields);
        wrapper.add(Box.createVerticalStrut(10));
        wrapper.add(extrasPanel);
        return wrapper;
    }

    private JPanel buildButtons() {
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        bar.setBackground(Theme.WHITE);
        bar.setBorder(BorderFactory.createEmptyBorder(4, 0, 0, 0));

        JButton cancel = Theme.button("Cancel");
        JButton save = Theme.primaryButton("Save vehicle");
        cancel.addActionListener(e -> dispose());
        save.addActionListener(e -> save());

        bar.add(cancel);
        bar.add(save);
        getRootPane().setDefaultButton(save);
        return bar;
    }

    /** Show only the fields the selected type actually has. */
    private void updateExtras() {
        extrasPanel.removeAll();
        String type = (String) typeBox.getSelectedItem();

        boolean bicycle = "Bicycle".equals(type);
        rateLabel.setEnabled(!bicycle);
        rateField.setEnabled(!bicycle);
        if (bicycle) {
            rateField.setText(String.format("%.2f", Bicycle.FLAT_DAILY_RATE));
        }

        switch (type) {
            case "Car" -> {
                extrasPanel.add(Theme.label("Seats"));
                extrasPanel.add(seatsField);
                extrasPanel.add(gpsBox);
            }
            case "Motorbike" -> {
                extrasPanel.add(Theme.label("Engine (cc)"));
                extrasPanel.add(ccField);
            }
            case "Truck" -> {
                extrasPanel.add(Theme.label("Load (tons)"));
                extrasPanel.add(tonsField);
            }
            case "Bicycle" -> {
                extrasPanel.add(Theme.label("Gears"));
                extrasPanel.add(gearsField);
                extrasPanel.add(Theme.subtitle("  flat rate, every bicycle costs the same"));
            }
            default -> { }
        }
        extrasPanel.revalidate();
        extrasPanel.repaint();
        pack();
    }

    private void save() {
        String type = (String) typeBox.getSelectedItem();
        String id = idField.getText().trim().toUpperCase();
        String brand = brandField.getText().trim();
        String model = modelField.getText().trim();

        try {
            double rate = "Bicycle".equals(type)
                    ? Bicycle.FLAT_DAILY_RATE
                    : parseDouble(rateField.getText(), "Daily rate");

            // building the right subclass is the only place the view needs
            // to know the type; after this it is just "a Vehicle" again
            Vehicle v = switch (type) {
                case "Car" -> new Car(id, brand, model, rate,
                        parseInt(seatsField.getText(), "Seats"), gpsBox.isSelected());
                case "Motorbike" -> new Motorbike(id, brand, model, rate,
                        parseInt(ccField.getText(), "Engine size"));
                case "Truck" -> new Truck(id, brand, model, rate,
                        parseDouble(tonsField.getText(), "Load"));
                case "Bicycle" -> new Bicycle(id, brand, model,
                        parseInt(gearsField.getText(), "Gears"));
                default -> throw new IllegalArgumentException("Pick a vehicle type.");
            };

            controller.addVehicle(v);
            saved = true;
            savedId = id;
            dispose();

        } catch (IllegalArgumentException e) {
            Dialogs.warn(this, e.getMessage());
        } catch (SQLException e) {
            Dialogs.error(this, "Could not save the vehicle.", e);
        }
    }

    private int parseInt(String text, String fieldName) {
        try {
            int value = Integer.parseInt(text.trim());
            if (value <= 0) {
                throw new IllegalArgumentException(fieldName + " must be greater than zero.");
            }
            return value;
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException(fieldName + " must be a whole number.");
        }
    }

    private double parseDouble(String text, String fieldName) {
        try {
            double value = Double.parseDouble(text.trim());
            if (value <= 0) {
                throw new IllegalArgumentException(fieldName + " must be greater than zero.");
            }
            return value;
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException(fieldName + " must be a number.");
        }
    }

    public boolean wasSaved() {
        return saved;
    }

    public String getSavedId() {
        return savedId;
    }
}

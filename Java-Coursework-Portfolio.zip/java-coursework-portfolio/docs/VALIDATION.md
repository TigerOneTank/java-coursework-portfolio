# Validation and known issues

Review date: 2026-11-05. Environment: OpenJDK 17.0.20, Linux. The checks used fresh temporary databases, not the owner's original records.

## Checks performed

| Check | Result | Scope |
| --- | --- | --- |
| Compile each non-JavaFX source collection separately | 17 of 17 compiled | Includes both rental versions and the reference collection; not 17 finished independent apps |
| JavaFX starter under Java 17 without JavaFX dependencies | Failed with missing JavaFX modules | Original Maven configuration also targets JDK 24; that configuration was not validated |
| Rental subtotal, GPS fee, insurance, loyalty discount, and late-return total | Passed selected assertions | One car scenario; not exhaustive financial validation |
| Vehicle database initialization | Created schema and six seeded vehicles | SQLite JDBC 3.43.2.0 + SLF4J API 2.0.9 |
| Bus timetable at 08:00 | Selected 08:30 departure | TreeMap ceiling lookup |
| Bus timetable after the last departure | Reported the next day's first departure | End-of-day branch |
| Late library fine | Reproduced zero fine for a late return | Known defect, not a passing business rule |
| Duplicate library return | Reproduced available copies exceeding total by one | Known defect, isolated disposable database |

The helper and privacy-sanitized source were recompiled after organization. Contact Manager emits an unchecked-operation warning. GUI click flows, photo selection, deployment, and concurrent use were not validated. IntelliJ `.form` compilation was not performed, so successful `javac` results for form-backed exercises do not prove that their windows launch correctly. No simulated screenshots are presented as real demonstrations.

[Review probe source](../tools/checks/PortfolioChecks.java) and [safe reproduction notes](../tools/checks/README.md) are included.

## Prioritized follow-up

| Area | Finding in the code | Suggested next change |
| --- | --- | --- |
| Library fines | `FineCalculator.calculate` always returns zero | Implement and test early/on-time/late returns |
| Library returns | No already-returned guard; catch block lacks explicit rollback | Enforce one return per loan and rollback failures |
| Library book editing | `BookController` reverses available/total constructor arguments | Correct mapping and test edits after a loan |
| Mini Mart cart | `findCartItem` returns null; `updateSelectedItem` is empty | Implement lookup/editing and duplicate-product tests |
| Mini Mart orders | Order persistence does not decrement stock | Validate and update stock in the order transaction |
| To-do CLI | Startup does not call table creation | Initialize schema and handle DAO errors without null iteration |
| Early Contact App | Plaintext passwords and inconsistently user-scoped queries | Replace demo authentication and enforce ownership in every query |
| Library authentication | Salted SHA-256 and seeded demo accounts | Use a password-specific KDF before any real authentication use |
| Swing password exercise | Uses `Random` and does not guarantee every chosen character class | Treat as a UI exercise; redesign before security use |
| Input handling | Several CLIs/forms accept malformed input or report success after failure | Add validation and propagate database failures clearly |
| Rental receipts | Prices derived from current vehicle data | Consider storing booked prices for stable historical receipts |

Application behavior was not silently rewritten during this import. These are candidates for small, separately reviewed improvements with tests.

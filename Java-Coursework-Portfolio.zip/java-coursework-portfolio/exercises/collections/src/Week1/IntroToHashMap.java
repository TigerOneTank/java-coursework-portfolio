package Week1;

import java.util.HashMap;
import java.util.Map;

public class IntroToHashMap {
    public static void main(String[] args) {

        Map<String, String> contactBook = new HashMap<>();
        // add a new entry into map: put(key, value)
        contactBook.put("john", "demo3@example.com");
        contactBook.put("joe", "demo2@example.com");
        contactBook.put("james", "demo1@example.com");
        // to get the size of the hashmap
        System.out.println(contactBook.size());
        System.out.println(contactBook);

//        if (contactBook.containsKey("john")) {
//            contactBook.remove("john");
//            System.out.println("Success!");
//        }
//        System.out.println(contactBook);
//        System.out.println(contactBook.get("james"));

        for (Map.Entry<String, String> entry : contactBook.entrySet()) {
            System.out.println(entry.getKey() + " " + entry.getValue());
        }
    }

}

package VehicleRentalApp.model;

/**
 * Does both things at once: extends Vehicle AND implements Insurable.
 * Compare calculateInsurance() here with the one in Car: same signature,
 * different formula. Neither class knows the other exists -- polymorphism.
 */
public class Truck extends Vehicle implements Insurable {

    private final double loadTons;

    public static final double LOAD_FEE_PER_TON = 5.00;
    public static final double TRUCK_INSURANCE_RATE = 0.15;   // vs 0.10 for a car
    public static final double PAPERWORK_FEE = 20.00;         // one-off

    public Truck(String id, String brand, String model, double dailyRate,
                 double loadTons) {
        super(id, brand, model, dailyRate);
        this.loadTons = loadTons;
    }

    public double getLoadTons() {
        return loadTons;
    }

    @Override
    public String getType() {
        return "Truck";
    }

    @Override
    public double calculateRentalCost(int days) {
        return getDailyRate() * days + LOAD_FEE_PER_TON * loadTons * days;
    }

    @Override
    public String getDetails() {
        return String.format("%.1f tons", loadTons);
    }

    @Override
    public double calculateInsurance(int days) {
        return getDailyRate() * TRUCK_INSURANCE_RATE * days + PAPERWORK_FEE;
    }

    @Override
    public String getPolicyName() {
        return "Commercial Truck Cover";
    }
}

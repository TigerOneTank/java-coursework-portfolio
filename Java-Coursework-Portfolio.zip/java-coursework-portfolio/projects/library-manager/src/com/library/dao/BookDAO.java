package com.library.dao;

import com.library.model.Book;

import javax.xml.crypto.Data;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/** Data access for the books table. */
public class BookDAO implements GenericDAO<Book> {

    @Override
    public int insert(Book b) {
        String sql = "INSERT INTO books(title,author,isbn,category,total_copies,available_copies) " +
                     "VALUES (?,?,?,?,?,?)";

        try (Connection conn = Database.getConnection()) {
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, b.getTitle());
            pstmt.setString(2, b.getAuthor());
            pstmt.setString(3, b.getIsbn());
            pstmt.setString(4, b.getCategory());
            pstmt.setInt(5, b.getTotalCopies());
            pstmt.setInt(6, b.getAvailableCopies());
            pstmt.executeUpdate();

            try (Statement stmt = conn.createStatement();
                ResultSet keys = stmt.executeQuery("Select last_insert_rowid()")) {
                if (keys.next()) {
                    return keys.getInt(1);
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Book insert failed." + e.getMessage());
        }


        return -1;
    }

    @Override
    public void update(Book b) {
        String sql = "UPDATE books SET title=?, author=?, isbn=?, category=?, "
                + "total_copies=?, available_copies=? WHERE id=?";
        try (Connection conn = Database.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, b.getTitle());
            pstmt.setString(2, b.getAuthor());
            pstmt.setString(3, b.getIsbn());
            pstmt.setString(4, b.getCategory());
            pstmt.setInt(5, b.getTotalCopies());
            pstmt.setInt(6, b.getAvailableCopies());
            pstmt.setInt(7, b.getId());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Book update failed." + e.getMessage());
        }
    }


    @Override
    public void delete(int id) {
        String sql = "DELETE FROM books WHERE id=?";

        try (Connection conn = Database.getConnection();
        PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1,id);
            pstmt.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Book Delete Failed" + e.getMessage());
        }
    }

    @Override
    public Optional<Book> findById(int id) {
        String sql = "SELECT * FROM books WHERE id=?";
        try (Connection conn = Database.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(map(rs));
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Book findById failed", e);
        }

        return Optional.empty();
    }

    @Override
    public List<Book> findAll() {
        String sql = "SELECT * FROM books ORDER BY id";
        List<Book> list = new ArrayList<>();
        try (Connection conn = Database.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                list.add(map(rs));
            }

        } catch (SQLException e) {
            throw new RuntimeException("Book findAll failed." + e.getMessage());
        }
        return list;
    }

    /** Search by title, author, or ISBN. */
    public List<Book> search(String keyword) {
        List<Book> list = new ArrayList<>();
        String sql = "SELECT * FROM books WHERE title LIKE ? OR author LIKE ? OR isbn LIKE ?";
        String like = "%" + keyword + "%";

        try (Connection conn = Database.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, like);
            pstmt.setString(2, like);
            pstmt.setString(3, like);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    list.add(map(rs));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Book search failed. " + e.getMessage());
        }

        return list;
    }

    /** Books with at least one available copy. */
    public List<Book> findAvailable() {
        String sql = "SELECT * FROM books WHERE available_copies > 0 ORDER BY title";
        List<Book> list = new ArrayList<>();
        return list;
    }

    /** Decrement availability within an existing transaction. */
    public void decrementAvailable(int bookId, Connection c) throws SQLException {
        try (PreparedStatement pstmt = c.prepareStatement(
                "UPDATE books SET available_copies = available_copies - 1 WHERE id = ? AND available_copies > 0"
        )) {
            pstmt.setInt(1, bookId);

            if (pstmt.executeUpdate() == 0) {
                throw new SQLException("No available copy to issue for book of " + bookId);
            }
        }
    }

    /** Increment availability within an existing transaction. */
    public void incrementAvailable(int bookId, Connection c) throws SQLException {
        try (PreparedStatement pstmt = c.prepareStatement(
                "UPDATE books SET available_copies = available_copies + 1 WHERE id = ?"
        )) {
            pstmt.setInt(1, bookId);
            pstmt.executeUpdate();
        }
    }
    private Book map(ResultSet rs) throws SQLException {
        return new Book(
                rs.getInt("id"),
                rs.getString("title"),
                rs.getString("author"),
                rs.getString("isbn"),
                rs.getString("category"),
                rs.getInt("total_copies"),
                rs.getInt("available_copies"));
    }
}

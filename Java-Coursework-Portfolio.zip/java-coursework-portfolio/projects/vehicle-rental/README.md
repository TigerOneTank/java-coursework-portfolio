# Vehicle Rental

Swing application with vehicle and customer records, rental/return workflows, receipts, loyalty discounts, insurance, and SQLite persistence.

**Context:** Java coursework and guided learning. Original folder: `Final-Project`.

## What the code demonstrates

Inheritance, interfaces, polymorphism, MVC, DAO, and transactions. The original implementation and learning comments are retained; the portfolio packaging is documented in [provenance](../../docs/PROVENANCE.md).

## Run

From the repository root, with Python 3 and a JDK installed:

```sh
python3 tools/portfolio.py build vehicle-rental
python3 tools/portfolio.py run vehicle-rental
```

Windows users can use `py` instead of `python3`. 

Database examples also require the SQLite JDBC runtime described in [setup](../../docs/RUNNING.md). Run each collection separately: several use the same class names.

## Known limitations

Built from a guided assignment scaffold; original GIVEN, YOUR TASK, and TODO comments are retained. Receipts recalculate using current vehicle rates. GUI workflows and concurrent use are not fully tested.

## Learning notes

The useful code-reading focus here is inheritance, interfaces, polymorphism, mvc, dao, and transactions. This README describes the submitted implementation; it does not claim every component was written independently. Personal reflections can be added after reviewing the source.

See [validation](../../docs/VALIDATION.md) for the exact scope of checks.

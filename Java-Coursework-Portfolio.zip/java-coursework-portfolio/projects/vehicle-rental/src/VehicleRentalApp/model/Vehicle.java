package VehicleRentalApp.model;

/**
 * Parent of every vehicle in the shop.
 *
 * Abstract because you never rent "a vehicle" -- you rent a Car, a Motorbike,
 * a Truck or a Bicycle. Holds the shared state and the two rules every
 * subclass must supply: what it is called, and what it costs.
 *
 * This class is pure MODEL: it knows nothing about SQL and nothing about Swing.
 */
public abstract class Vehicle implements Comparable<Vehicle> {

    private final String id;
    private String brand;
    private String model;
    private double dailyRate;
    private boolean available;

    protected Vehicle(String id, String brand, String model, double dailyRate) {
        this.id = id;
        this.brand = brand;
        this.model = model;
        this.dailyRate = dailyRate;
        this.available = true;
    }

    public String getId() {
        return id;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public double getDailyRate() {
        return dailyRate;
    }

    public void setDailyRate(double dailyRate) {
        this.dailyRate = dailyRate;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    // ---- every subclass must answer these two -----------------------------

    /** e.g. "Car", "Motorbike", "Truck", "Bicycle". */
    public abstract String getType();

    /** Total price for renting this vehicle for the given number of days. */
    public abstract double calculateRentalCost(int days);

    /** Extra attributes shown in the vehicle table, e.g. "5 seats, GPS". */
    public abstract String getDetails();

    // ---- natural ordering: cheapest first, id as a stable tie-break -------
    @Override
    public int compareTo(Vehicle other) {
        int byRate = Double.compare(this.dailyRate, other.dailyRate);
        if (byRate != 0) {
            return byRate;
        }
        return this.id.compareTo(other.id);
    }

    public String describe() {
        return String.format("[%s] %s %s %s $%.2f/day",
                id, getType(), brand, model, dailyRate);
    }

    @Override
    public String toString() {
        // the combo box in the rent form shows this
        return id + " - " + getType() + " " + brand + " " + model
                + String.format(" ($%.2f/day)", dailyRate);
    }
}

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("WELCOME TO THE STUDENT MANAGEMENT SYSTEM");
        StudentDB.createStudentTable();
        Scanner scanner = new Scanner(System.in);
        displayMenu();
        String command = "";
        while (!command.equalsIgnoreCase("exit")) {
            System.out.print("Enter your command: ");
            command = scanner.nextLine();
            switch (command) {
                case "list" -> displayAllStudents();
                case "help" -> displayMenu();
                case "exit" -> System.out.println("Bye!");
                case "view" -> displayStudentDetail();
                case "add" -> addStudent();
                case "delete" -> deleteStudent();
                case "update" -> updateStudent();
                default -> System.out.println("Invalid command.");
            }
        }

    }

    public static void displayMenu() {
        System.out.println("COMMAND MENU");
        System.out.println("list    - List all students");
        System.out.println("help    - Show the menu again");
        System.out.println("exit    - Exit the program");
        System.out.println("view    - Shows one student ");
        System.out.println("add    - Adds one student ");
        System.out.println("del    - Deletes one student ");
        System.out.println("Update    - Updates a Student ");
    }

    public static void displayAllStudents() {
        ArrayList<Student> students = StudentDB.selectAllStudents();

        if (students != null) {
            System.out.println("Here is the student list");
            for (Student s : students) {
                System.out.println(s);
            }
        } else {
            System.out.println("No student records.");
        }
        System.out.println();
    }

    public static void displayStudentDetail() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter Student ID: ");
        String id = scanner.nextLine();
        Student student = StudentDB.selectStudentById(id);
        if (student != null) {
            System.out.println(student);
        } else {
            System.out.println("Student not found.");
        }
    }

    public static void addStudent() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter student id: ");
        String id = scanner.nextLine();
        System.out.print("Enter student fullname: ");
        String fullname = scanner.nextLine();
        System.out.print("Enter student age: ");
        int age = Integer.parseInt(scanner.nextLine());
        System.out.print("Enter student grade: ");
        int grade = Integer.parseInt(scanner.nextLine());
        Student student = new Student(id, fullname, age, grade);
        if (StudentDB.addStudent(student)) {
            System.out.println("Student added. ");
        } else {
            System.out.println("Student Not Added. ");
        }


    }

    public static void deleteStudent() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter student id: ");
        String id = scanner.nextLine();
        Student student = StudentDB.selectStudentById(id);
        if (student != null ) {
            StudentDB.deleteStudent(student);
            System.out.println("Student deleted");
        } else {
            System.out.println("No Such Student");
        }
    }

    public static void updateStudent() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter student NEW fullname: ");
        String fullname = scanner.nextLine();
        System.out.print("Enter student NEW age: ");
        int age = Integer.parseInt(scanner.nextLine());
        System.out.print("Enter student NEW grade: ");
        int grade = Integer.parseInt(scanner.nextLine());
        System.out.print("Enter student ID to update: ");
        String id = scanner.nextLine();
        Student student = new Student(id, fullname, age, grade);
        if (StudentDB.updateStudent(student)) {
            System.out.println("Student updated successfully.");
        } else {
            System.out.println("Student Not Updated. Check if ID exists.");
        }
    }
}
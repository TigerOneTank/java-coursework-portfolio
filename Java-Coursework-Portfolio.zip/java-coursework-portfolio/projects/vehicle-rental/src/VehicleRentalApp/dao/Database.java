package VehicleRentalApp.dao;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/*
 * Database.java  -- FULLY COMPLETED EXAMPLE  (Step 1: read this carefully)
 *
 * Nothing to write in this file. It is your reference for how the shop is
 * stored, and you will need to understand every column in it before you can
 * write the DAOs in Steps 2 and 3.
 *
 * This class owns the one and only connection to the SQLite file, builds the
 * three tables the first time the app runs, and puts the starting stock in.
 *
 * THE BIG IDEA OF THIS FILE
 * A table row is FLAT. Your class hierarchy is not. A Car has seats and GPS,
 * a Truck has tonnage, a Motorbike has engine size -- but they all have to
 * live in one 'vehicles' table so that "list every vehicle" is one query.
 *
 * The trick is a 'type' column plus one nullable column per extra attribute.
 * A motorbike row simply leaves seats, has_gps, load_tons and gears empty.
 * This is called SINGLE TABLE INHERITANCE and it is the reason the vehicles
 * table below looks so wide.
 */
public final class Database {

    /** The file the whole shop lives in. Delete it to start over. */
    public static final String DB_FILE = "data/rental.db";

    private static Connection connection;

    private Database() {
    }

    /** Opens the connection on first call, reuses it afterwards. */
    public static Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            File file = new File(DB_FILE);
            File parent = file.getParentFile();
            if (parent != null && !parent.exists()) {
                parent.mkdirs();
            }
            connection = DriverManager.getConnection("jdbc:sqlite:" + file.getPath());
            try (Statement st = connection.createStatement()) {
                // SQLite ignores REFERENCES unless you switch this on per connection
                st.execute("PRAGMA foreign_keys = ON");
            }
        }
        return connection;
    }

    /** Called once at start-up by App.main(). */
    public static void init() throws SQLException {
        createTables();
        seedIfEmpty();
    }

    private static void createTables() throws SQLException {
        try (Statement st = getConnection().createStatement()) {

            /*
             * Things to notice:
             *   - "IF NOT EXISTS" so restarting the app is harmless
             *   - id is TEXT, because vehicle ids look like "C01", not 1
             *   - available is INTEGER, because SQLite has no boolean:
             *     you store 1 for true and 0 for false
             *   - the last five columns have no NOT NULL, because they only
             *     apply to some vehicle types
             */
            st.executeUpdate("""
                CREATE TABLE IF NOT EXISTS vehicles (
                    id          TEXT    PRIMARY KEY,
                    type        TEXT    NOT NULL,
                    brand       TEXT    NOT NULL,
                    model       TEXT    NOT NULL,
                    daily_rate  REAL    NOT NULL,
                    available   INTEGER NOT NULL DEFAULT 1,
                    seats       INTEGER,
                    has_gps     INTEGER,
                    load_tons   REAL,
                    engine_cc   INTEGER,
                    gears       INTEGER
                )""");

            /*
             * Why AUTOINCREMENT here but not on vehicles? A vehicle id is real
             * data printed on the key fob. A customer id is invented by the
             * database purely to have something to point at -- that is called
             * a SURROGATE key.
             *
             * Why COLLATE NOCASE UNIQUE? So that "sokha" and "Sokha" are the
             * same person, and the database itself refuses to store both. The
             * rule is enforced once, here, instead of by a toLowerCase() call
             * that somebody will forget to write in Java.
             */
            st.executeUpdate("""
                CREATE TABLE IF NOT EXISTS customers (
                    id           INTEGER PRIMARY KEY AUTOINCREMENT,
                    name         TEXT    NOT NULL COLLATE NOCASE UNIQUE,
                    rental_count INTEGER NOT NULL DEFAULT 0
                )""");

            /*
             * The two REFERENCES lines are FOREIGN KEYS. They are how a flat
             * table says "HAS-A": a rental row does not contain a customer,
             * it points at one. This is composition, written in SQL.
             *
             * created_at has a DEFAULT, so RentalDao never has to supply it.
             *
             * Question to answer in your notebook: why does this table store
             * discount_rate, but NOT the total price?
             * (Hint: what happens to an old receipt when the customer earns
             * a new discount? And where do the pricing rules live?)
             */
            st.executeUpdate("""
                CREATE TABLE IF NOT EXISTS rentals (
                    id            TEXT    PRIMARY KEY,
                    customer_id   INTEGER NOT NULL REFERENCES customers(id),
                    vehicle_id    TEXT    NOT NULL REFERENCES vehicles(id),
                    days          INTEGER NOT NULL,
                    returned      INTEGER NOT NULL DEFAULT 0,
                    actual_days   INTEGER NOT NULL DEFAULT 0,
                    discount_rate REAL    NOT NULL DEFAULT 0,
                    created_at    TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
                )""");
        }
    }

    /** Same starting stock the console version hard-coded in seedVehicles(). */
    private static void seedIfEmpty() throws SQLException {
        // only seed when the table is empty, so restarting the app does not
        // create six more vehicles every time
        try (Statement st = getConnection().createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM vehicles")) {
            if (rs.next() && rs.getInt(1) > 0) {
                return;   // already stocked
            }
        }

        try (Statement st = getConnection().createStatement()) {
            /*
             * One INSERT, six rows.
             *
             * Look down the last five columns. Every NULL is a column that
             * belongs to a different subclass: a Car row has no engine_cc, a
             * Motorbike row has no seats. That is single table inheritance in
             * action, and VehicleDao.map() is the code that reads these rows
             * back and decides which subclass to build (TODO 2.7).
             *
             * Note B01's rate of 5.0. Nobody chose it -- it is
             * Bicycle.FLAT_DAILY_RATE, because every bicycle costs the same.
             */
            st.executeUpdate("""
                INSERT INTO vehicles (id, type, brand, model, daily_rate, available,
                                      seats, has_gps, load_tons, engine_cc, gears) VALUES
                    ('C01','Car',      'Toyota','Vios',  33.0, 1, 5,    1,    NULL, NULL, NULL),
                    ('C02','Car',      'Honda', 'Civic', 40.0, 1, 5,    0,    NULL, NULL, NULL),
                    ('M01','Motorbike','Honda', 'Dream',  8.0, 1, NULL, NULL, NULL, 110,  NULL),
                    ('M02','Motorbike','Yamaha','NMAX',  12.0, 1, NULL, NULL, NULL, 155,  NULL),
                    ('T01','Truck',    'Isuzu', 'NPR',   75.0, 1, NULL, NULL, 3.5,  NULL, NULL),
                    ('B01','Bicycle',  'Giant', 'Escape', 5.0, 1, NULL, NULL, NULL, NULL, 7)
                """);
        }
    }

    public static void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException ignored) {
            // shutting down anyway
        }
    }
}

# Collections Practice

Eleven exercises using maps, sorted keys, custom key equality, inventory records, word counts, timetables, and leaderboards.

**Context:** Java coursework and guided learning. Original folder: `JavaTerm4`.

## What the code demonstrates

HashMap, TreeMap, LinkedHashMap, equals/hashCode, and iteration. The original implementation and learning comments are retained; the portfolio packaging is documented in [provenance](../../docs/PROVENANCE.md).

## Run

From the repository root, with Python 3 and a JDK installed:

```sh
python3 tools/portfolio.py build collections
python3 tools/portfolio.py run collections
```

Windows users can use `py` instead of `python3`. 

Database examples also require the SQLite JDBC runtime described in [setup](../../docs/RUNNING.md). Run each collection separately: several use the same class names.

## Known limitations

These are small classroom exercises with fixed examples and limited input validation. BusRoute expects a zero-padded HH:mm time.

## Learning notes

The useful code-reading focus here is hashmap, treemap, linkedhashmap, equals/hashcode, and iteration. This README describes the submitted implementation; it does not claim every component was written independently. Personal reflections can be added after reviewing the source.

See [validation](../../docs/VALIDATION.md) for the exact scope of checks.

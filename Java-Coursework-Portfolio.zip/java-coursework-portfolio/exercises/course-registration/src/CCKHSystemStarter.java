import javax.swing.*;
import java.awt.*;


public class CCKHSystemStarter extends JFrame {
    private JTextField txtName, txtAge;
    private JComboBox<String> cbCourse, cbShift;
    private JRadioButton rbSat, rbSun;
    private JSpinner spinTerms;
    private JProgressBar progressBar;
    private Timer loadingTimer;

    public CCKHSystemStarter() {
        setTitle("CCKH SYSTEM");
        setSize(400, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        // Create a mainPanel
        JPanel mainPanel = new JPanel(new GridLayout(8, 2, 5, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        // TASK1: Create a fullname label and txtName textfield to the panel
        mainPanel.add(new JLabel("Fullname:"));
        txtName = new JTextField();
        mainPanel.add(txtName);
        // TASK2: Create a Age label and txtName textfield to the panel
        mainPanel.add(new JLabel("Age:"));
        txtAge = new JTextField();
        mainPanel.add(txtAge);

        // TASK3: Create a course label and course checkbox to the panel

        mainPanel.add(new JLabel("Course:"));
        String[] courses = {"Java", "Python", "C++"};
        cbCourse = new JComboBox<>(courses);
        mainPanel.add(cbCourse);

        // TASK4: Create a day label and two radio button saturday and sunday in the dayPanel then add it to the contentPane
        mainPanel.add(new JLabel("Day:"));
        JPanel dayPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        rbSat = new JRadioButton("Saturday");
        rbSun = new JRadioButton("Sunday");
        dayPanel.add(rbSat);
        dayPanel.add(rbSun);
        mainPanel.add(dayPanel);

        // TASK5: Create a shift label and Morning and Afternoon Shift combobox
        mainPanel.add(new JLabel("Shift:"));
        cbShift = new JComboBox<>(new String[]{"Morning", "Afternoon"});
        mainPanel.add(cbShift);
        // TASK6: Create a term label and number of term spinner
        mainPanel.add(new JLabel("Terms(s):"));
        spinTerms = new JSpinner(new SpinnerNumberModel(1, 1, 10, 1));
        mainPanel.add(spinTerms);
        // TASK7: add 2 labels "price per term" and "100$" to the contentPane
        mainPanel.add(new JLabel("Price per term:"));
        mainPanel.add(new JLabel("$100"));
        JPanel bottomPanel = new JPanel(new BorderLayout(5, 5));
        JButton btnSubmit = new JButton("Submit");
        btnSubmit.addActionListener(e -> startSubmission());
        bottomPanel.add(btnSubmit, BorderLayout.SOUTH);
        // TASK8: create a progessbar value from 0-100, display percentage when loading, default value from 0-100
        // add the progressbar to the NORTH
        progressBar = new JProgressBar(0, 100);
        progressBar.setStringPainted(true);
        progressBar.setVisible(false);
        bottomPanel.add(progressBar, BorderLayout.NORTH);
        // Add the panels to the window
        add(mainPanel, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        // Timer logic to simulate loading
        loadingTimer = new Timer(30, e -> {
            // TASK9: handle the timer
            // i. get the current value from the progressbar
            // ii. check if the progressbar is less than 100 then increase the value of progressbar by 5
            // iii. else stop the loading timer then invoke showConfirmation()
            int currentValue = progressBar.getValue();
            if (currentValue < 100) {
                progressBar.setValue(currentValue + 5);
            } else {
                loadingTimer.stop();
                showConfirmation();
            }
        });

        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void startSubmission() {
        progressBar.setValue(0);
        progressBar.setVisible(true);
        loadingTimer.start();
    }

    private void showConfirmation() {
        // TASK10: show the confirmation in the JOptionPane
        // i. Gather all the data
        String name = txtName.getText();
        String age = txtAge.getText();
        String course = (String) cbCourse.getSelectedItem(); // Matches his Library style
        String shift = (String) cbShift.getSelectedItem();
        int terms = (Integer) spinTerms.getValue();

        // b. Determine which radio button was selected
        String day = "No Option Selected";
        // ii. check if the rbSat is selected then set the day to Saturday, if rbSun is selected then set the day to Sunday
        if (rbSat.isSelected()) {
            day = "Saturday";
        } else if (rbSun.isSelected()) {
            day = "Sunday";
        }



        // 2. Prepare the message to display in the joptionpane dipslaying all the input data
        int totalFee = terms * 100;
        String message = "--- Registration Details ---\n" +
                "Fullname: " + name + "\n" +
                "Age: " + age + "\n" +
                "Course: " + course + "\n" +
                "Day: " + day + "\n" +
                "Shift: " + shift + "\n" +
                "Terms: " + terms + "\n" +
                "------------------------------\n" +
                "Total Fee: $" + totalFee;

        // 3. Display the detailed message
        JOptionPane.showMessageDialog(this, message, "Confirmation", JOptionPane.INFORMATION_MESSAGE);

        // 4. Clear fields and hide progress bar
        clearFields();
        progressBar.setVisible(false);
    }

    private void clearFields() {
        // TASK11: Reset back to default
        txtName.setText("");
        txtAge.setText("");
        cbCourse.setSelectedIndex(0);
        cbShift.setSelectedIndex(0);
        rbSat.setSelected(false);
        rbSun.setSelected(false);
        spinTerms.setValue(1);
    }

    public static void main(String[] args) {
        new CCKHSystemStarter();
    }
}


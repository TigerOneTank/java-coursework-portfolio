package VehicleRentalApp.view;

import VehicleRentalApp.dao.Database;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.SwingConstants;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;

/**
 * VIEW: the shell. One tab per controller, plus a status bar the panels write
 * into. Holds no business rules of its own.
 */
public class MainFrame extends JFrame {

    private final JLabel status = new JLabel("Ready");

    private final VehiclePanel vehiclePanel = new VehiclePanel(this);
    private final RentalPanel rentalPanel = new RentalPanel(this);
    private final CustomerPanel customerPanel = new CustomerPanel(this);
    private final ReportPanel reportPanel = new ReportPanel(this);

    public MainFrame() {
        setTitle("Vehicle Rental Shop");
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setMinimumSize(new Dimension(920, 600));
        setSize(1060, 700);
        setLocationRelativeTo(null);

        getContentPane().setBackground(Theme.WHITE);
        setLayout(new BorderLayout());

        add(buildHeader(), BorderLayout.NORTH);
        add(buildTabs(), BorderLayout.CENTER);
        add(buildStatusBar(), BorderLayout.SOUTH);

        // close the database cleanly instead of leaving a lock behind
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                Database.close();
                dispose();
                System.exit(0);
            }
        });
    }

    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Theme.BLACK);
        header.setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));

        JLabel name = new JLabel("VEHICLE RENTAL SHOP");
        name.setFont(Theme.FONT_TITLE);
        name.setForeground(Theme.WHITE);

        JLabel hint = new JLabel("SQLite · " + Database.DB_FILE);
        hint.setFont(Theme.FONT_SMALL);
        hint.setForeground(Theme.GREY_LINE);
        hint.setHorizontalAlignment(SwingConstants.RIGHT);

        header.add(name, BorderLayout.WEST);
        header.add(hint, BorderLayout.EAST);
        return header;
    }

    private JTabbedPane buildTabs() {
        JTabbedPane tabs = new JTabbedPane();
        tabs.setBackground(Theme.WHITE);
        tabs.setForeground(Theme.BLACK);
        tabs.setFont(Theme.FONT_HEADER);
        tabs.setBorder(BorderFactory.createEmptyBorder(8, 8, 0, 8));

        tabs.addTab("Vehicles", vehiclePanel);
        tabs.addTab("Rentals", rentalPanel);
        tabs.addTab("Customers", customerPanel);
        tabs.addTab("Report", reportPanel);

        // every tab reloads from the database when you switch to it, so the
        // numbers can never be stale after a rental
        tabs.addChangeListener(e -> {
            switch (tabs.getSelectedIndex()) {
                case 0 -> vehiclePanel.refresh();
                case 1 -> rentalPanel.refresh();
                case 2 -> customerPanel.refresh();
                case 3 -> reportPanel.refresh();
                default -> { }
            }
        });
        return tabs;
    }

    private JPanel buildStatusBar() {
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 6));
        bar.setBackground(Theme.WHITE);
        bar.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, Theme.GREY_LINE));
        status.setFont(Theme.FONT_SMALL);
        status.setForeground(Theme.GREY_MUTED);
        bar.add(status);
        return bar;
    }

    /** Panels call this instead of printing to the console. */
    public void setStatus(String message) {
        status.setText(message);
    }

    /** Called after a rental or a return, so the other tabs are not stale. */
    public void refreshAll() {
        vehiclePanel.refresh();
        rentalPanel.refresh();
        customerPanel.refresh();
        reportPanel.refresh();
    }

    /** First load, once the frame is on screen. */
    public void loadInitialData() {
        refreshAll();
    }
}

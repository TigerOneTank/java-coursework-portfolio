package com.learnmvc.view;


import com.learnmvc.model.Student;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.util.List;


public class StudentView extends JFrame {

    // Table + its data model (rows shown to the user).
    private final DefaultTableModel tableModel =
            new DefaultTableModel(new Object[]{"ID", "Name", "Email", "Major"}, 0) {
                @Override public boolean isCellEditable(int r, int c) { return false; }
            };
    private final JTable table = new JTable(tableModel);

    // Form input fields.
    private final JTextField nameField  = new JTextField(16);
    private final JTextField emailField = new JTextField(16);
    private final JTextField majorField = new JTextField(16);

    // Buttons. The Controller decides what each one does.
    private final JButton addButton    = new JButton("Add");
    private final JButton updateButton = new JButton("Update");
    private final JButton deleteButton = new JButton("Delete");
    private final JButton clearButton  = new JButton("Clear");

    public StudentView() {
        setTitle("Student Manager — MVC + SQLite demo");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(640, 460);
        setLocationRelativeTo(null);

        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        add(new JScrollPane(table), BorderLayout.CENTER);
        add(buildForm(), BorderLayout.SOUTH);
    }

    private JPanel buildForm() {
        JPanel wrapper = new JPanel(new BorderLayout(8, 8));
        wrapper.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        JPanel fields = new JPanel(new GridLayout(3, 2, 6, 6));
        fields.add(new JLabel("Name:"));  fields.add(nameField);
        fields.add(new JLabel("Email:")); fields.add(emailField);
        fields.add(new JLabel("Major:")); fields.add(majorField);
        wrapper.add(fields, BorderLayout.CENTER);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttons.add(clearButton);
        buttons.add(addButton);
        buttons.add(updateButton);
        buttons.add(deleteButton);
        wrapper.add(buttons, BorderLayout.SOUTH);

        return wrapper;
    }

    // ---------- methods the CONTROLLER calls to DISPLAY data ----------

    /** Replace everything in the table with the given students. */
    public void setStudents(List<Student> students) {
        tableModel.setRowCount(0);
        for (Student s : students) {
            tableModel.addRow(new Object[]{s.getId(), s.getName(), s.getEmail(), s.getMajor()});
        }
    }

    /** Put a student's values into the form (used when a row is selected). */
    public void fillForm(int id, String name, String email, String major) {
        nameField.setText(name);
        emailField.setText(email);
        majorField.setText(major);
    }

    public void clearForm() {
        nameField.setText("");
        emailField.setText("");
        majorField.setText("");
        table.clearSelection();
    }

    public void showMessage(String message) {
        JOptionPane.showMessageDialog(this, message);
    }

    // ---------- methods the CONTROLLER calls to READ input ----------

    public String getName()  { return nameField.getText().trim(); }
    public String getEmail() { return emailField.getText().trim(); }
    public String getMajor() { return majorField.getText().trim(); }

    /** -1 if no row is selected, otherwise the ID in the selected row. */
    public int getSelectedId() {
        int row = table.getSelectedRow();
        if (row < 0) return -1;
        return (int) tableModel.getValueAt(row, 0);
    }

    /** Read a whole selected row so the Controller can fill the form. */
    public String getSelectedValue(int column) {
        int row = table.getSelectedRow();
        if (row < 0) return "";
        Object v = tableModel.getValueAt(row, column);
        return v == null ? "" : v.toString();
    }

    // ---------- hooks: the CONTROLLER plugs in BEHAVIOR here ----------
    // The View exposes "when X happens, call this listener" but never defines
    // the listener body itself.

    public void addSaveListener(ActionListener l)   { addButton.addActionListener(l); }
    public void addUpdateListener(ActionListener l)  { updateButton.addActionListener(l); }
    public void addDeleteListener(ActionListener l)  { deleteButton.addActionListener(l); }
    public void addClearListener(ActionListener l)   { clearButton.addActionListener(l); }
    public void addTableSelectionListener(ListSelectionListener l) {
        table.getSelectionModel().addListSelectionListener(l);
    }
}

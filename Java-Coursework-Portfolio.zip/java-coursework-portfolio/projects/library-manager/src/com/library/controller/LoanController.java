package com.library.controller;

import com.library.model.Book;
import com.library.model.Loan;
import com.library.model.Member;
import com.library.service.FineCalculator;
import com.library.service.LibraryService;
import com.library.service.LoanService;
import com.library.view.LoanView;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class LoanController {

    private final LoanView view;
    private final LibraryService libraryService;
    private final LoanService loanService;
    private final FineCalculator fineCalculator = new FineCalculator();
    private final Runnable onLoanChanged;

    private boolean showingOverdueOnly = false;

    public LoanController(LoanView view, LibraryService libraryService, LoanService loanService, Runnable onLoanChanged) {
        this.view = view;
        this.libraryService = libraryService;
        this.loanService = loanService;
        this.onLoanChanged = onLoanChanged;


        view.setOnIssue(this::issue);
        view.setOnReturn(this::returnBook);



        refresh();
    }

    private void refresh() {
        List<Loan> loans = showingOverdueOnly ? libraryService.overdueLoans() : libraryService.activeLoans();
        List<LoanView.LoanRow> rows = new ArrayList<>();

        for (Loan loan: loans) {
            rows.add(new LoanView.LoanRow(
                    loan.getId(),
                    loan.getBookTitle(),
                    loan.getMemberName(),
                    loan.getIssueDate().toString(),
                    loan.getDueDate().toString(),
                    "",
                    "0.0",
                    loan.getStatus().toString()
            ));
        }

        view.populate(rows);
    }

    private void issue() {
        view.showIssueDialog(this::describeMember, this::describeBook).ifPresent(req -> {
            try {
                Loan loan = loanService.issueBook(req.memberId, req.bookId);
                view.showInfo("Issued - due " + loan.getDueDate());
                refresh();
            } catch (IllegalStateException e) {
                view.showWarning(e.getMessage());
            } catch (RuntimeException e) {
                view.showError(e.getMessage());
            }
        });
    }

    private void returnBook() {
        Optional<Integer> loanId = view.showReturnDialog(this::describeMember, this::lookupMemberAndLoans);

        if (!loanId.isPresent()) return;

        try {
            double fine = loanService.returnBook(loanId.get());
            if (fine > 0) {
                view.showInfo(String.format("Book returned. Overdue fine: $%.2f", fine));
            } else {
                view.showInfo("Book returned on time. No fine.");
            }
            refresh();

        } catch (IllegalStateException e) {
            view.showWarning(e.getMessage());
        } catch (RuntimeException e) {
            view.showError(e.getMessage());
        }
    }

    private void notifyLoanChanged() {
        if (onLoanChanged != null) {
            onLoanChanged.run();
        }
    }

    // ---- lookups the view runs off the EDT via its own SwingWorker ----

    private String describeMember(int id) {
        Optional<Member> member = libraryService.findMemberById(id);
        if (!member.isPresent()) return "No member with that ID.";
        Member m = member.get();
        return m.getName() + " — " + m.getStatus() + ", " + m.getBorrowedCount() + " borrowed";
    }

    private String describeBook(int id) {
        Optional<Book> book = libraryService.findBookById(id);
        if (!book.isPresent()) return "No book with that ID.";
        Book b = book.get();
        return b.getTitle() + " by " + b.getAuthor() + " — "
                + b.getAvailableCopies() + "/" + b.getTotalCopies() + " available";
    }

    private LoanView.LoanLookupResult lookupMemberAndLoans(int id) {
        Optional<Member> member = libraryService.findMemberById(id);
        if (!member.isPresent()) return new LoanView.LoanLookupResult("No member with that ID.", List.of());
        List<Loan> loans = loanService.activeLoansForMember(id);
        String label = member.get().getName() + " — " + member.get().getStatus()
                + (loans.isEmpty() ? " (no active loans)" : "");
        return new LoanView.LoanLookupResult(label, loans);
    }
}

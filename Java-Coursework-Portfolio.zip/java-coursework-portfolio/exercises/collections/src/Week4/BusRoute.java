package Week4;


import java.util.Scanner;
import java.util.TreeMap;

public class BusRoute {
    public static void main(String[] args) {
        TreeMap<String, String> timetable = new TreeMap<>();
        timetable.put("07:30","L1: Techno Airport");
        timetable.put("08:30","L1: National Stadium");
        timetable.put("09:00","L2: National Monument");
        timetable.put("12:30","L2: Aeon Mall ");
        timetable.put("13:30","L3: Russian Market");

        Scanner sc = new Scanner(System.in);
        System.out.println("Please Enter The Current Time: ");
        String now = sc.nextLine().trim();
        String newDept = timetable.ceilingKey(now);

        if (newDept == null) {
            System.out.println("No More Buses Today");
            System.out.println("The First Bus Tomorrow is: ");
            System.out.println(timetable.firstKey() + " -> " + timetable.get(timetable.firstKey()));
        } else {
            System.out.println("Next Bus: " + newDept + " -> " + timetable.get(newDept));
        }

    }
}

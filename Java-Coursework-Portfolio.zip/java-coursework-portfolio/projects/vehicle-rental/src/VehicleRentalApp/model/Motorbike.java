package VehicleRentalApp.model;

/**
 * A Motorbike IS-A Vehicle but is NOT Insurable -- there is deliberately no
 * "implements Insurable" here. The customer signs a waiver instead.
 */
public class Motorbike extends Vehicle {

    private final int engineCc;

    public static final double HELMET_FEE = 3.00;   // charged once, not per day

    public Motorbike(String id, String brand, String model, double dailyRate,
                     int engineCc) {
        super(id, brand, model, dailyRate);
        this.engineCc = engineCc;
    }

    public int getEngineCc() {
        return engineCc;
    }

    @Override
    public String getType() {
        return "Motorbike";
    }

    @Override
    public double calculateRentalCost(int days) {
        // HELMET_FEE is OUTSIDE the multiplication -- one-off charge
        return getDailyRate() * days + HELMET_FEE;
    }

    @Override
    public String getDetails() {
        return engineCc + "cc";
    }
}

# Contact Manager

Swing contact manager with add/edit/delete operations, search, a table model, and contact photos stored alongside a SQLite database.

**Context:** Java coursework and guided learning. Original folder: `CONTACTMNG-MVC`.

## What the code demonstrates

MVC, prepared statements, table models, and file handling. The original implementation and learning comments are retained; the portfolio packaging is documented in [provenance](../../docs/PROVENANCE.md).

## Run

From the repository root, with Python 3 and a JDK installed:

```sh
python3 tools/portfolio.py build contact-manager
python3 tools/portfolio.py run contact-manager
```

Windows users can use `py` instead of `python3`. 

Database examples also require the SQLite JDBC runtime described in [setup](../../docs/RUNNING.md). Run each collection separately: several use the same class names.

## Known limitations

Photo selection and GUI interaction require a desktop. Compilation reports an unchecked-operation warning in MainFrame. Use fictional contacts only.

## Learning notes

The useful code-reading focus here is mvc, prepared statements, table models, and file handling. This README describes the submitted implementation; it does not claim every component was written independently. Personal reflections can be added after reviewing the source.

See [validation](../../docs/VALIDATION.md) for the exact scope of checks.

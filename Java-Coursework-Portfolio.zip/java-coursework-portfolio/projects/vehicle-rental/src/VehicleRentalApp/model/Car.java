package VehicleRentalApp.model;

/**
 *      class Car extends Vehicle implements Insurable
 *              |          |                 |
 *              |          |                 +-- signs the insurance contract
 *              |          +-- inherits id, brand, model, dailyRate, describe()
 *              +-- our new class
 *
 * A class can EXTEND only one parent, but can IMPLEMENT many interfaces.
 */
public class Car extends Vehicle implements Insurable {

    private final int seats;
    private final boolean hasGps;

    public static final double GPS_FEE_PER_DAY = 2.00;
    public static final double CAR_INSURANCE_RATE = 0.10;   // 10% of daily rate

    public Car(String id, String brand, String model, double dailyRate,
               int seats, boolean hasGps) {
        super(id, brand, model, dailyRate);
        this.seats = seats;
        this.hasGps = hasGps;
    }

    public int getSeats() {
        return seats;
    }

    public boolean hasGps() {
        return hasGps;
    }

    @Override
    public String getType() {
        return "Car";
    }

    @Override
    public double calculateRentalCost(int days) {
        double cost = getDailyRate() * days;
        if (hasGps) {
            cost += GPS_FEE_PER_DAY * days;
        }
        return cost;
    }

    @Override
    public String getDetails() {
        return seats + " seats" + (hasGps ? ", GPS" : "");
    }

    @Override
    public double calculateInsurance(int days) {
        return getDailyRate() * CAR_INSURANCE_RATE * days;
    }

    @Override
    public String getPolicyName() {
        return "Standard Car Cover";
    }
}

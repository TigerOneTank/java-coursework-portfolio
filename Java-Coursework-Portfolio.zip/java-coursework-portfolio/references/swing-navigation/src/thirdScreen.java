import javax.swing.*;

public class thirdScreen {
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JButton cancelButton;
    private JButton saveButton;
    private JCheckBox isUnavailableCheckBox;
    private JPanel thirdScreenPanel;
}

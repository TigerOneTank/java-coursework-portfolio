import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Calculator extends JFrame {

    private JPanel ContentPane;
    private JTextField InputNumber;
    private JLabel operationLbl;
    private JPanel Jbutton;
    private JButton acBtn;
    private JButton btn7;
    private JButton btn4;
    private JButton btn1;
    private JButton btn0;
    private JButton signBtn;
    private JButton PercBtn;
    private JButton divBtn;
    private JButton btn8;
    private JButton btn9;
    private JButton MultiplyBtn;
    private JButton btn5;
    private JButton btn6;
    private JButton minusBtn;
    private JButton btn2;
    private JButton btn3;
    private JButton plusBtn;
    private JButton DelBtn;
    private JButton equalBtn;

    private JButton[] allBtns = {btn0, btn1, btn2, btn4, btn5, btn6, btn7, btn8, btn9, acBtn, signBtn, PercBtn, divBtn,MultiplyBtn, minusBtn, plusBtn, DelBtn,equalBtn,btn3};
    String givenNumber = "";
    double total = 0;
    String currentOperator = "";
    boolean newInput = true;
    String digits = "0123456789";
    String operators = "+-x÷=";
    String specials = "AC+/-%DEL";



    public Calculator() {
        setTitle("My Calculator");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(ContentPane);
        setLocationRelativeTo(null);
        setVisible(true);
        pack();

        for (JButton btn: allBtns) {
            btn.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String inputText = btn.getText();
                    if(newInput) {
                        InputNumber.setText("");
                        newInput = !newInput;
                    }

                    if(!newInput && digits.contains(inputText)) {
                            givenNumber = InputNumber.getText() + inputText;
                            InputNumber.setText(givenNumber);
                    } else if (operators.contains(inputText)) {
                        InputNumber.setText("");
                        operationLbl.setText(operationLbl.getText() + givenNumber + inputText);
                        if (currentOperator.equals("")) {
                            total = Double.parseDouble(givenNumber);
                            currentOperator = inputText;
                            System.out.println(total + currentOperator + givenNumber);
                        } else {
                            System.out.println(total + currentOperator + givenNumber);
                            total = calculate(total, currentOperator, givenNumber);
                            System.out.println("Current Total: " + total);
                            InputNumber.setText(String.valueOf(Math.round(total)));
                            currentOperator = inputText;
                            newInput = !newInput;
                        }
                    } else if (specials.contains(inputText)) {
                        if (inputText.equals("DEL")) {
                            String currentNumber = InputNumber.getText();
                            int length = currentNumber.length();
                            String newNumber = currentNumber.substring(0, length - 1);
                            System.out.println(newNumber);
                            InputNumber.setText(newNumber);
                            givenNumber = newNumber;
                        } else if (inputText.equals("AC")) {
                            givenNumber = "";
                            total = 0;
                            currentOperator = "";
                            newInput = true;
                            InputNumber.setText("");
                            operationLbl.setText("");
                        } else if (inputText.equals("+/-")) {
                            String currentText = InputNumber.getText();

                            if (!currentText.isEmpty()) {
                                double value = Double.parseDouble(currentText);
                                value = -value; // flip the sign

                                givenNumber = String.valueOf(value);
                                InputNumber.setText(givenNumber);
                            }
                        }

                    }
                }

                });
        }


    }


    public double calculate(double currentTotal, String operator, String number) {
        switch (operator) {
            case "+":
                currentTotal = currentTotal + Double.parseDouble(number);
                break;
            case "-":
                currentTotal = currentTotal - Double.parseDouble(number);
                break;
            case "x":
                currentTotal = currentTotal * Double.parseDouble(number);
                break;
            case "÷":
                currentTotal = currentTotal / Double.parseDouble(number);
                break;
            default:
                break;

        }
        return currentTotal;
    }
}


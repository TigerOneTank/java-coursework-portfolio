package VehicleRentalApp.view;

import VehicleRentalApp.controller.VehicleController;
import VehicleRentalApp.model.Vehicle;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.sql.SQLException;
import java.util.List;

/**
 * VIEW: the fleet. Reads through VehicleController only -- there is no import
 * of any dao class or of java.sql in this file, and that is the point.
 */
public class VehiclePanel extends JPanel {

    private final MainFrame frame;
    private final VehicleController controller = new VehicleController();

    private final String[] columns =
            {"ID", "Type", "Brand", "Model", "Rate/day", "Details", "Status"};
    private final DefaultTableModel model = new DefaultTableModel(columns, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;   // the table is a report, not a form
        }
    };
    private final JTable table = Theme.table(model);

    /** Which view of the fleet is on screen. */
    private enum Mode { ALL, AVAILABLE, BY_RATE }

    private Mode mode = Mode.ALL;

    public VehiclePanel(MainFrame frame) {
        this.frame = frame;
        setLayout(new BorderLayout(0, 14));
        setBackground(Theme.WHITE);
        setBorder(Theme.pagePadding());

        add(buildHeader(), BorderLayout.NORTH);
        add(Theme.scroll(table), BorderLayout.CENTER);
        add(buildToolbar(), BorderLayout.SOUTH);
    }

    private JPanel buildHeader() {
        JPanel head = new JPanel(new BorderLayout(0, 4));
        head.setBackground(Theme.WHITE);
        head.add(Theme.title("Fleet"), BorderLayout.NORTH);
        head.add(Theme.subtitle(
                "Every vehicle the shop owns. Click a column header to sort."),
                BorderLayout.SOUTH);
        return head;
    }

    private JPanel buildToolbar() {
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        bar.setBackground(Theme.WHITE);
        bar.setBorder(BorderFactory.createEmptyBorder(2, 0, 0, 0));

        JButton all = Theme.button("All vehicles");
        JButton available = Theme.button("Available only");
        JButton byRate = Theme.button("Sort by rate");
        JButton add = Theme.primaryButton("Add vehicle");
        JButton delete = Theme.button("Delete selected");

        all.addActionListener(e -> show(Mode.ALL));
        available.addActionListener(e -> show(Mode.AVAILABLE));
        byRate.addActionListener(e -> show(Mode.BY_RATE));
        add.addActionListener(e -> openAddDialog());
        delete.addActionListener(e -> deleteSelected());

        bar.add(all);
        bar.add(available);
        bar.add(byRate);
        bar.add(add);
        bar.add(delete);
        return bar;
    }

    private void show(Mode next) {
        mode = next;
        refresh();
    }

    private void openAddDialog() {
        AddVehicleDialog dialog = new AddVehicleDialog(frame, controller);
        dialog.setVisible(true);
        if (dialog.wasSaved()) {
            mode = Mode.ALL;
            refresh();
            frame.setStatus("Added vehicle " + dialog.getSavedId() + ".");
        }
    }

    private void deleteSelected() {
        int row = table.getSelectedRow();
        if (row < 0) {
            Dialogs.warn(this, "Select a vehicle in the table first.");
            return;
        }
        // the table may be sorted, so translate the view row to the model row
        String id = (String) model.getValueAt(table.convertRowIndexToModel(row), 0);
        if (!Dialogs.confirm(this, "Delete vehicle " + id + "?")) {
            return;
        }
        try {
            if (controller.deleteVehicle(id)) {
                refresh();
                frame.setStatus("Deleted vehicle " + id + ".");
            } else {
                Dialogs.warn(this, id + " has rental history and cannot be deleted.\n"
                        + "Deleting it would leave those receipts pointing at nothing.");
            }
        } catch (SQLException e) {
            Dialogs.error(this, "Could not delete " + id + ".", e);
        }
    }

    /** Reload from the database. Called by MainFrame on every tab switch. */
    public void refresh() {
        try {
            List<Vehicle> vehicles = switch (mode) {
                case ALL -> controller.listAll();
                case AVAILABLE -> controller.listAvailable();
                case BY_RATE -> controller.listSortedByRate();
            };

            model.setRowCount(0);
            for (Vehicle v : vehicles) {
                model.addRow(new Object[]{
                        v.getId(),
                        v.getType(),
                        v.getBrand(),
                        v.getModel(),
                        String.format("$%.2f", v.getDailyRate()),
                        v.getDetails(),
                        v.isAvailable() ? "Available" : "Rented out"
                });
            }
            frame.setStatus(vehicles.size() + " vehicle(s) shown · view: " + label(mode));
        } catch (SQLException e) {
            Dialogs.error(this, "Could not read the vehicles table.", e);
        }
    }

    private String label(Mode m) {
        return switch (m) {
            case ALL -> "all";
            case AVAILABLE -> "available only";
            case BY_RATE -> "cheapest first";
        };
    }
}

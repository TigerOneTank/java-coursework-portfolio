import java.sql.*;
import java.util.ArrayList;

public class CourseDB {
    public static Connection getConnection() throws SQLException{
        String url = "jdbc:sqlite:coursedb.db";
        Connection conn = DriverManager.getConnection(url);
        return conn;
    }

    public static void createCourseTable() {
        // TODO1: write the code to create a new table
        String sql = "CREATE TABLE IF NOT EXISTS course ("
                + "code TEXT PRIMARY KEY,"
                + "name TEXT NOT NULL,"
                + "description TEXT NOT NULL,"
                + "capacity INTEGER NOT NULL,"
                + "terms INTEGER NOT NULL,"
                + "price REAL NOT NULL);";

        try (Connection conn = getConnection()) {
            Statement stmt = conn.createStatement();
            stmt.execute(sql);
            System.out.println("Course table has been created!");
        } catch (SQLException e) {
            System.out.println(e);
        }


    }

    public static boolean addCourse(Course course) {
        // TODO2: write the code to add a new course
        String sql = "INSERT INTO course (code, name, description, capacity, terms, price) "
                + "VALUES (?, ?, ?, ?, ?, ?);";
        try (Connection conn = getConnection()) {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, course.getCode());
            ps.setString(2, course.getName());
            ps.setString(3, course.getDescription());
            ps.setInt(4, course.getCapacity());
            ps.setInt(5, course.getTerms());
            ps.setDouble(6, course.getPrice());
            ps.executeUpdate();
            System.out.println("One record is added to the table.");
            return true;
        } catch (SQLException e) {
            System.out.println(e);
            return false;
        }

    }

    public static ArrayList<Course> getAllCourses() {
        // TODO3: write the code to get all courses
        String sql = "SELECT * FROM course";
        ArrayList<Course> courses = new ArrayList<>();
        try (Connection conn = getConnection()) {
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String code = rs.getString("code");
                String name = rs.getString("name");
                String description = rs.getString("description");
                int capacity = rs.getInt("capacity");
                int terms = rs.getInt("terms");
                double price = rs.getDouble("price");
                Course course = new Course(code, name, description, capacity, terms, price);
                courses.add(course);
            }
            return courses;
        } catch (SQLException e) {
            System.out.println(e);
            return null;
        }
    }

    public static boolean deleteCourse(String code) {
        // Todo4: write the code to delete a course
        String sql = "DELETE FROM Course WHERE code = ?;";

        try (Connection conn = getConnection()) {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, code);
            ps.executeUpdate();

            System.out.println("One record is deleted from the table.");
            return true;
        } catch (SQLException e) {
            System.out.println(e);
            return false;
        }
    }

    public static Course getOneCourse(String code) {

        ArrayList<Course> courses = getAllCourses();
        for (Course course : courses) {
            if (course.getCode().equals(code)) {
                return course;
            }
        }
        return null;
    }
}

import javax.swing.*;

public class passwordGenerator {
    private JPanel panel1;
    private JCheckBox checkBox1;
    private JCheckBox checkBox2;
    private JButton button1;
    private JCheckBox checkBox3;
    private JTextField textField1;
}

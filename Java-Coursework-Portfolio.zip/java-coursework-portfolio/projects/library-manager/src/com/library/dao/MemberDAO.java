package com.library.dao;

import com.library.model.Member;
import com.library.model.MemberStatus;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/** Data access for the members table. */
public class MemberDAO implements GenericDAO<Member> {

    private static final String SELECT_WITH_COUNT =
            "SELECT m.*, (SELECT COUNT(*) FROM loans l " +
            "             WHERE l.member_id = m.id AND l.status = 'ACTIVE') AS borrowed " +
            "FROM members m ";

    @Override
    public int insert(Member m) {
        String sql = "INSERT INTO members(name,email,phone,membership_date,status) VALUES (?,?,?,?,?)";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, m.getName());
            ps.setString(2, m.getEmail());
            ps.setString(3, null);
            ps.setString(4, m.getMembershipDate().toString());
            ps.setString(5, m.getStatus().name());
            ps.executeUpdate();

            try (Statement stmt = conn.createStatement();
                 ResultSet keys = stmt.executeQuery("SELECT last_insert_rowid()")) {

                if (keys.next()) {
                    return keys.getInt(1);
                }
            }

            return -1;
        } catch (SQLException e) {
            throw new RuntimeException("Book insert failed", e);
        }
    }

    @Override
    public void update(Member m) {
        String sql = "UPDATE members SET name=?,email=?,membership_date=?,status=? WHERE id=?";
        try (Connection conn = Database.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, m.getName());
            pstmt.setString(2, m.getEmail());
            pstmt.setString(3, m.getMembershipDate().toString());
            pstmt.setString(4, m.getStatus().name());
            pstmt.setInt(5, m.getId());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Member update failed." + e.getMessage());
        }


    }

    @Override
    public void delete(int id) {
        String sql = "DELETE FROM members WHERE id=?";
        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Member delete failed", e);
        }
    }

    @Override
    public Optional<Member> findById(int id) {
        try (Connection c = Database.getConnection();
             PreparedStatement pstmt = c.prepareStatement(SELECT_WITH_COUNT + "WHERE m.id=?")) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(map(rs));
                }
            }
            return Optional.empty();
        } catch (SQLException e) {
            throw new RuntimeException("Member findById failed.", e);
        }
    }

    @Override
    public List<Member> findAll() {
        String sql = SELECT_WITH_COUNT + "ORDER BY m.id";
        List<Member> list = new ArrayList<>();
        try (Connection conn = Database.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                list.add(map(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Member findall failed." + e.getMessage());
        }

        return list;

    }

    public List<Member> search(String keyword) {
        List<Member> list = new ArrayList<>();
        String sql = SELECT_WITH_COUNT + "WHERE m.name LIKE ? OR m.email LIKE ? ORDER BY m.id";
        String like = "%" + keyword + "%";

        try (Connection conn = Database.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, like);
            pstmt.setString(2, like);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    list.add(map(rs));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Member search failed." + e.getMessage());
        }

        return list;
    }

    private Member map(ResultSet rs) throws SQLException {
        Member m = new Member(
                rs.getInt("id"),
                rs.getString("name"),
                rs.getString("email"),
                LocalDate.parse(rs.getString("membership_date")),
                MemberStatus.valueOf(rs.getString("status")),
                rs.getInt("borrowed"));
        return m;
    }
}

import java.sql.PreparedStatement;
import java.sql.DriverManager;
import java.sql.SQLException;

public class UpdateRecords {
    public static void main(String[] args) {
        String url = "jdbc:sqlite:java_db.db";
        String sql = "UPDATE products SET amount = ?, price = ? WHERE id = ?";

        try (var conn = DriverManager.getConnection(url);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt( 1, 150);
            ps.setDouble( 2, 2888.88);
            ps.setInt( 3, 3);

            ps.executeUpdate();
            System.out.println("Record is updated.");
        } catch (SQLException e) {
            System.out.println(e);
        }
    }
}
package com.contactmanagement.view;

import javax.swing.ImageIcon;
import java.awt.Image;
import java.io.File;

final class ImageUtil {

    private ImageUtil() {
    }

    static ImageIcon loadScaledIcon(String path, int width, int height) {
        if (path == null || path.isEmpty()) {
            return null;
        }
        File file = new File(path);
        if (!file.exists()) {
            return null;
        }
        ImageIcon icon = new ImageIcon(path);
        Image scaled = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
        return new ImageIcon(scaled);
    }
}

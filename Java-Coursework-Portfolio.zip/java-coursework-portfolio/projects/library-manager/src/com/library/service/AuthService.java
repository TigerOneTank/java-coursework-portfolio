package com.library.service;

import com.library.dao.UserDAO;
import com.library.model.User;
import com.library.util.PasswordUtil;

import java.util.Optional;

/** Handles staff login. */
public class AuthService {

    private final UserDAO userDAO = new UserDAO();

    /** Returns the User if credentials are valid, otherwise empty. */
    public Optional<User> login(String username, String password) {
        Optional<User> user = userDAO.findByUsername(username);
        if (user.isPresent() && PasswordUtil.verify(password, user.get().getPasswordHash())) {
            return user;
        }
        return Optional.empty();
    }
}

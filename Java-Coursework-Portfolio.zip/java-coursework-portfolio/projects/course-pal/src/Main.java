import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;


public class Main {
    public static void main(String[] args) throws SQLException {
        System.out.println("Welcome to COURSE PAL");
        Connection conn = CourseDB.getConnection();

        if (conn != null) {
            System.out.println("Connection has been established");
            CourseDB.createCourseTable();
            String command = "";
            while (!command.equals("exit")) {
                displayMenu();
                System.out.println("In order to solve this problem we must be able to understand " +
                        "the solution and we must either solve it effectively or efficiently" +
                        "depending on the scenario or situation ");
                command = Console.getString("Enter your command: ");
                switch (command) {
                    case "list" -> listAllCourses();
                    case "add" -> addNewCourse();
                    case "delete" -> deleteOneCourse();
                    case "exit" -> System.out.println("Good bye!!");
                    default -> System.out.println("Invalid command");
                }

            }


        } else {
            System.out.println("No connection established");
        }
    }

    public static void displayMenu() {
        System.out.println("COURSE PAL");
        System.out.println("list : list all courses");
        System.out.println("add : add new course");
        System.out.println("delete : delete a course");
        System.out.println("exit : exit course");
    }

    public static void listAllCourses() {
        System.out.println("Here are all courses");
        // TODO1: write the code to display all courses
        ArrayList<Course> courses = CourseDB.getAllCourses();

        System.out.printf("%10s %20s %30s %10s %10s %10s\n", "CODE", "NAME", "DESCRIPTION", "CAPACITY", "TERMS", "PRICE");

        for (Course course : courses) {
            String code = course.getCode();
            String name = course.getName();
            String description = course.getDescription();
            int capacity = course.getCapacity();
            int terms = course.getTerms();
            double price = course.getPrice();

            System.out.printf(" %10s %20s %30s %10d %10d %10.2f\n", code, name, description, capacity, terms, price);
        }

        System.out.println();

    }

    public static void addNewCourse() {
        System.out.println("Add new course");
        // TODO2: write the code to add a new course
        String code = Console.getString("Enter the course code: ");
        String name = Console.getString("Enter the course name: ");
        String description = Console.getString("Enter the description: ");
        int capacity = Console.getInt("Enter the capacity: ");
        int terms = Console.getInt("Enter the terms: ");
        double price = Console.getDouble("Enter the price: ");

        Course newCourse = new Course(code, name, description, capacity, terms, price);
        CourseDB.addCourse(newCourse);
        System.out.println("New course has been added!");
    }

    public static void deleteOneCourse() {
        System.out.println("Delete course details");
        // TODO3: write the code to delete a course
        String id = Console.getString("Enter the course code: ");
        Course course = CourseDB.getOneCourse(id);
        if (course != null ) {
            CourseDB.deleteCourse(id);
            System.out.println("Course has been deleted sucessfully!");
        } else {
            System.out.println("Course does not exist");
        }
    }

}
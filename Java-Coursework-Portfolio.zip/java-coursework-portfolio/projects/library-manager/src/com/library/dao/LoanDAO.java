package com.library.dao;

import com.library.model.Loan;
import com.library.model.LoanStatus;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/** Data access for loan records. */
public class LoanDAO {

    private static final String SELECT_JOIN =
            "SELECT l.*, b.title AS book_title, m.name AS member_name " +
            "FROM loans l " +
            "LEFT JOIN books b   ON b.id = l.book_id " +
            "LEFT JOIN members m ON m.id = l.member_id ";

    /** Insert inside a caller-managed transaction. Returns generated id. */
    public int insert(Loan loan, Connection c) throws SQLException {
        String sql = "INSERT INTO loans(book_id, member_id, issue_date, due_date, return_date, fine, status) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, loan.getBookId());
            ps.setInt(2, loan.getMemberId());
            ps.setString(3, loan.getIssueDate().toString());
            ps.setString(4, loan.getDueDate().toString());
            ps.setString(5, loan.getReturnDate() == null ? null : loan.getReturnDate().toString());
            ps.setDouble(6, loan.getFine());
            ps.setString(7, loan.getStatus().name());
            ps.executeUpdate();
            try (Statement stmt = c.createStatement();
                 ResultSet keys = stmt.executeQuery("SELECT last_insert_rowid()")) {
                if (keys.next()) {
                    return keys.getInt(1);
                }
            }
            return -1;
        } catch (SQLException e) {
            throw new RuntimeException("Book insert failed", e);
        }
    }

    /** Update inside a caller-managed transaction (used on return). */
    public void update(Loan loan, Connection c) throws SQLException {
        String sql = "UPDATE loans SET return_date=?,fine=?,status=? WHERE id=?";

        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, loan.getReturnDate() == null ? null : loan.getReturnDate().toString());
            ps.setDouble(2, loan.getFine());
            ps.setString(3, loan.getStatus().toString());
            ps.setInt(4, loan.getId());
            ps.executeUpdate();
        }

    }

    public Optional<Loan> findById(int id) {
        try (Connection c = Database.getConnection();
             PreparedStatement pstmt = c.prepareStatement(SELECT_JOIN + "WHERE l.id = ?")) {

            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(map(rs));
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Loan findActiveByMember failed." + e.getMessage());
        }
        return Optional.empty();
    }

    public List<Loan> findAll() {
        return query(SELECT_JOIN + "ORDER BY l.id DESC");
    }

    public List<Loan> findActive() {
        return query(SELECT_JOIN + "WHERE l.status='ACTIVE' ORDER BY l.due_date");
    }

    public List<Loan> findActiveByMember(int memberId) {
        List<Loan> list = new ArrayList<>();

        try (Connection c = Database.getConnection();
             PreparedStatement pstmt = c.prepareStatement(SELECT_JOIN + "WHERE l.status = 'ACTIVE' AND l.member_id=?")) {

            pstmt.setInt(1, memberId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    list.add(map(rs));
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Loan findActiveByMember failed." + e.getMessage());
        }


        return list;
    }

    public int countOutstandingByBook(int bookId) {
        return 0;
    }

    public List<Loan> findOverdue() {
        List<Loan> list = new ArrayList<>();

        return list;
    }

    private List<Loan> query(String sql) {
        List<Loan> list = new ArrayList<>();

        try (Connection c = Database.getConnection();
             Statement stmt = c.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                list.add(map(rs));
            }

        } catch (SQLException e) {
            throw new RuntimeException("Loan query failed." + e.getMessage());
        }
        return list;
    }

    private Loan map(ResultSet rs) throws SQLException {
        String ret = rs.getString("return_date");
        Loan loan = new Loan(
                rs.getInt("id"),
                rs.getInt("book_id"),
                rs.getInt("member_id"),
                LocalDate.parse(rs.getString("issue_date")),
                LocalDate.parse(rs.getString("due_date")),
                ret == null ? null : LocalDate.parse(ret),
                rs.getDouble("fine"),
                LoanStatus.valueOf(rs.getString("status")));
        String bookTitle = rs.getString("book_title");
        String memberName = rs.getString("member_name");
        loan.setBookTitle(bookTitle == null ? "Deleted book" : bookTitle);
        loan.setMemberName(memberName == null ? "Deleted member" : memberName);
        return loan;
    }
}

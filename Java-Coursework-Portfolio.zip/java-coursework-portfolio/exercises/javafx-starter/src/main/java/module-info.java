module com.example.javaintermediatelevel2 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;


    opens com.example.javaintermediatelevel2 to javafx.fxml;
    exports com.example.javaintermediatelevel2;
}
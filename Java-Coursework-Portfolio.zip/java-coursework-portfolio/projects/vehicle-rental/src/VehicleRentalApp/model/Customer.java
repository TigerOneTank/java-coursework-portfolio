package VehicleRentalApp.model;

/*
 * Customer.java  -- YOUR TASK  (Step 4)
 *
 * Implements Discountable, which means it signs a CONTRACT promising three
 * methods:
 *      qualifiesForDiscount()
 *      getDiscountRate()
 *      getDiscountLabel()
 *
 * Notice the word "public" on those three methods below -- an interface
 * method is always public, so the class implementing it must say public too.
 * Leaving it off is a compiler error.
 */
public class Customer implements Discountable {

    public static final int LOYALTY_THRESHOLD = 3;
    public static final double LOYALTY_RATE = 0.10;

    private int id;                     // 0 until saved to SQLite
    private final String name;
    private int rentalCount;

    // ---- GIVEN: constructors and getters ---------------------------------

    /** Brand new customer -- starts with zero rentals. */
    public Customer(String name) {
        this(0, name, 0);
    }

    /** Rebuilt from a row in the customers table. */
    public Customer(int id, String name, int rentalCount) {
        this.id = id;
        this.name = name;
        this.rentalCount = rentalCount;
    }

    public int getId() {
        return id;
    }

    /** Called only by CustomerDao.insert() once SQLite has picked the id. */
    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public int getRentalCount() {
        return rentalCount;
    }

    // ---- YOUR TASK -------------------------------------------------------

    /** Called every time this customer takes a vehicle. */
    public void recordRental() {
        // TODO 4.1: add one to rentalCount.
        //
        // Nothing else. This method does not touch the database -- saving is
        // CustomerDao.updateRentalCount()'s job, and RentalController calls
        // them one after the other. An object that saves itself is an object
        // you can no longer test without a database.
        rentalCount++;
    }

    /*
     * The three methods promised by Discountable.
     *
     * Notice what is NOT here: a getDiscount() that returns a fixed number.
     * The object decides its own rate, so a future StudentCustomer could use a
     * different rule and neither Rental nor any controller would change.
     */

    @Override
    public boolean qualifiesForDiscount() {
        // TODO 4.2: true when rentalCount has reached LOYALTY_THRESHOLD.
        //
        // Use >= and not ==. With == the discount would appear on rental 3 and
        // then vanish again on rental 4, which is the kind of bug a customer
        // notices before you do.
        return rentalCount >= LOYALTY_THRESHOLD;
    }

    @Override
    public double getDiscountRate() {
        // TODO 4.3: LOYALTY_RATE once qualified, otherwise 0.0
        //
        // Reuse qualifiesForDiscount() -- do not compare against
        // LOYALTY_THRESHOLD a second time. Writing the rule twice means one
        // day somebody changes one copy and not the other.
        return qualifiesForDiscount() ? LOYALTY_RATE : 0.0;
    }

    @Override
    public String getDiscountLabel() {
        // TODO 4.4: the text under "Loyalty status" in the Customers tab.
        //
        //   not yet qualified ->  "2 more rentals to loyalty"
        //                         "1 more rental to loyalty"   (mind the 's')
        //   qualified         ->  "Loyalty 10%"
        //
        // For the second one:
        //      String.format("Loyalty %.0f%%", LOYALTY_RATE * 100)
        // %% is how you print a literal percent sign inside format().
        if (qualifiesForDiscount()) {
            return String.format("Loyalty %.0f%%", LOYALTY_RATE * 100);
        }
        int remaining = LOYALTY_THRESHOLD - rentalCount;
        return remaining == 1 ? "1 more rental to loyalty" : remaining + " more rentals to loyalty";
    }

    @Override
    public String toString() {
        return name;
    }
}

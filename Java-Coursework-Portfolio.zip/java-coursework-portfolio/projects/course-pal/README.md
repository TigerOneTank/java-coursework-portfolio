# CoursePal CLI

Console course catalog with SQLite-backed list, add, and delete operations.

**Context:** Java coursework and guided learning. Original folder: `FinalTest`.

## What the code demonstrates

DAO organization and console interaction. The original implementation and learning comments are retained; the portfolio packaging is documented in [provenance](../../docs/PROVENANCE.md).

## Run

From the repository root, with Python 3 and a JDK installed:

```sh
python3 tools/portfolio.py build course-pal
python3 tools/portfolio.py run course-pal
```

Windows users can use `py` instead of `python3`. 

Database examples also require the SQLite JDBC runtime described in [setup](../../docs/RUNNING.md). Run each collection separately: several use the same class names.

## Known limitations

Success messages do not consistently reflect database failures; input validation needs work.

## Learning notes

The useful code-reading focus here is dao organization and console interaction. This README describes the submitted implementation; it does not claim every component was written independently. Personal reflections can be added after reviewing the source.

See [validation](../../docs/VALIDATION.md) for the exact scope of checks.

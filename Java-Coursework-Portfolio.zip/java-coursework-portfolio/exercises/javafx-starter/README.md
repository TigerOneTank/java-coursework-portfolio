# JavaFX Starter

Maven JavaFX starter with a controller and FXML resource.

**Context:** Java coursework and guided learning. Original folder: `JavaIntermediateLevel2`.

## What the code demonstrates

FXML, controllers, Java modules, and Maven. The original implementation and learning comments are retained; the portfolio packaging is documented in [provenance](../../docs/PROVENANCE.md).

## Run

Use JDK 24 and Maven with the preserved `pom.xml`:

```sh
cd exercises/javafx-starter
mvn clean javafx:run
```

This command reflects the supplied configuration; it has not been runtime-verified.

Database examples also require the SQLite JDBC runtime described in [setup](../../docs/RUNNING.md). Run each collection separately: several use the same class names.

## Known limitations

The original pom targets JDK 24 and declares JavaFX 17.0.6. It was not validated with that toolchain; Java 17 compilation without JavaFX fails. This is starter material, not a finished application.

## Learning notes

The useful code-reading focus here is fxml, controllers, java modules, and maven. This README describes the submitted implementation; it does not claim every component was written independently. Personal reflections can be added after reviewing the source.

See [validation](../../docs/VALIDATION.md) for the exact scope of checks.

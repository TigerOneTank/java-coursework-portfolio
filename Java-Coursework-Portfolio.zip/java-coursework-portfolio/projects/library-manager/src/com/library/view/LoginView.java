package com.library.view;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

public class LoginView extends JFrame {

    private final JTextField usernameField = new JTextField(16);
    private final JPasswordField passwordField = new JPasswordField(16);
    private final JButton loginButton = new JButton("Login");

    public LoginView() {
        setTitle("Library Management System — Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setContentPane(buildContent());
        pack();
        setLocationRelativeTo(null); // center on screen
    }

    private JPanel buildContent() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 24, 20, 24));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(6, 6, 6, 6);
        g.anchor = GridBagConstraints.WEST;

        JLabel title = new JLabel("Library Management System");
        title.setFont(title.getFont().deriveFont(18f));
        g.gridx = 0; g.gridy = 0; g.gridwidth = 2;
        panel.add(title, g);

        g.gridwidth = 1;
        g.gridx = 0; g.gridy = 1; panel.add(new JLabel("Username:"), g);
        g.gridx = 1; panel.add(usernameField, g);

        g.gridx = 0; g.gridy = 2; panel.add(new JLabel("Password:"), g);
        g.gridx = 1; panel.add(passwordField, g);

        loginButton.setPreferredSize(new Dimension(120, 30));
        g.gridx = 1; g.gridy = 3; g.anchor = GridBagConstraints.EAST;
        panel.add(loginButton, g);

        JLabel hint = new JLabel("Try admin/admin123 or lib1/lib123");
        hint.setFont(hint.getFont().deriveFont(11f));
        g.gridx = 0; g.gridy = 4; g.gridwidth = 2; g.anchor = GridBagConstraints.CENTER;
        panel.add(hint, g);

        getRootPane().setDefaultButton(loginButton); // Enter key submits
        return panel;
    }

    public void setOnLogin(Runnable r) { loginButton.addActionListener(e -> r.run()); }

    public String getUsername() { return usernameField.getText().trim(); }
    public String getPassword() { return new String(passwordField.getPassword()); }
    public void clearPassword() { passwordField.setText(""); }

    public void showMissingInputWarning() {
        JOptionPane.showMessageDialog(this, "Please enter username and password.",
                "Missing input", JOptionPane.WARNING_MESSAGE);
    }

    public void showLoginFailed() {
        JOptionPane.showMessageDialog(this, "Invalid username or password.",
                "Login failed", JOptionPane.ERROR_MESSAGE);
        clearPassword();
    }
}

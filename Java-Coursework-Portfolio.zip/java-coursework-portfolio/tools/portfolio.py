#!/usr/bin/env python3
"""Compile one source collection at a time; added during portfolio organization."""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
PROJECTS = json.loads((ROOT / 'portfolio.json').read_text())

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['list', 'build', 'run'])
    parser.add_argument('project', nargs='?', choices=PROJECTS)
    parser.add_argument('--main', help='Override entry point, e.g. Week1.WordCounter')
    args = parser.parse_args()
    if args.action == 'list':
        for name, project in PROJECTS.items():
            print(f'{name:26} {project["path"]}')
        return
    if not args.project:
        parser.error('build/run requires a project')
    project = PROJECTS[args.project]
    if project['javafx']:
        parser.error('Use the JavaFX project README and its Maven configuration.')
    if args.action == 'run' and project['forms']:
        parser.error('This collection needs IntelliJ GUI Designer form generation; see its README.')
    java = shutil.which('java')
    if not java:
        parser.error('java is missing; install a JDK and put its bin directory on PATH.')
    compiler = [shutil.which('javac')] if shutil.which('javac') else [java, '-m', 'jdk.compiler/com.sun.tools.javac.Main']
    project_dir = ROOT / project['path']
    output = ROOT / '.build' / args.project
    output.mkdir(parents=True, exist_ok=True)
    sources = sorted(str(p) for p in (project_dir / 'src').rglob('*.java'))
    if not sources:
        parser.error('No source files found')
    classpath = os.pathsep.join([str(output), str(ROOT / 'lib' / '*')])
    subprocess.run(compiler + ['-encoding', 'UTF-8', '-cp', classpath, '-d', str(output)] + sources, check=True)
    print(f'Compiled {len(sources)} Java files: {args.project}', flush=True)
    if args.action == 'run':
        subprocess.run([java, '-cp', classpath, args.main or project['main']], cwd=project_dir, check=True)

if __name__ == '__main__':
    try:
        main()
    except subprocess.CalledProcessError as error:
        sys.exit(error.returncode)

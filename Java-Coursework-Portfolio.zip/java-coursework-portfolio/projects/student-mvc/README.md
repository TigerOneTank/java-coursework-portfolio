# Student MVC

Small Swing student manager with name, email, major, and SQLite CRUD operations separated into model, view, and controller.

**Context:** Java coursework and guided learning. Original folder: `LearnMVCPattern`.

## What the code demonstrates

Separating UI behavior from persistence. The original implementation and learning comments are retained; the portfolio packaging is documented in [provenance](../../docs/PROVENANCE.md).

## Run

From the repository root, with Python 3 and a JDK installed:

```sh
python3 tools/portfolio.py build student-mvc
python3 tools/portfolio.py run student-mvc
```

Windows users can use `py` instead of `python3`. 

Database examples also require the SQLite JDBC runtime described in [setup](../../docs/RUNNING.md). Run each collection separately: several use the same class names.

## Known limitations

Minimal input validation; GUI workflows were not tested end to end. Sample email addresses use example.com.

## Learning notes

The useful code-reading focus here is separating ui behavior from persistence. This README describes the submitted implementation; it does not claim every component was written independently. Personal reflections can be added after reviewing the source.

See [validation](../../docs/VALIDATION.md) for the exact scope of checks.

# Java Swing & SQLite Project Style Guide

This guide documents the architectural standards, design patterns, and coding conventions used in this project. Use this reference when building or extending similar projects to ensure consistency across the codebase.

---

## 1. Technology Stack

- **Language**: Java 17+
- **GUI Framework**: Java Swing (standard JDK `javax.swing`, `java.awt`)
- **Database**: SQLite via JDBC (`jdbc:sqlite:<dbname>.db`, using `org.xerial:sqlite-jdbc`)
- **Logging/Utility**: Standard JDK (`java.sql`, `java.time`, `java.security`, `java.util`)

---

## 2. Architecture & Package Structure

The project strictly follows a **Model-View-Controller (MVC) + Service + DAO (Data Access Object)** layered architecture.

```
com.<project>/
├── Main.java               # Application bootstrap (DB init, Look & Feel, launch login)
├── model/                  # Domain POJOs, entity inheritance, enums
├── dao/                    # Database connection, migrations, generic interface, CRUD queries
├── service/                # Business logic, validations, multi-table transactions
├── controller/             # Event wiring, input validation, role checks, view coordination
├── view/                   # Pure Swing panels, tables, dialogs, async background workers
└── util/                   # Security and general utility helpers (e.g. PasswordUtil)
```

---

## 3. Layer Specifications & Conventions

### A. Model Layer (`com.<project>.model`)

- **Entities**: Plain Old Java Objects (POJOs) with private fields, getters, setters, and constructors.
- **Inheritance**: Common attributes (e.g., `id`, `name`, `email`) go into an abstract base class (e.g. `Person`), extended by specialized entities (e.g. `User`, `Member`).
- **Enums**: Use enums for fixed statuses and roles (e.g. `Role.ADMIN`, `Role.LIBRARIAN`, `MemberStatus.ACTIVE`, `MemberStatus.SUSPENDED`, `LoanStatus.ACTIVE`).
- **Helper Methods**:
  - `public abstract String describe()`: Human-readable summary for logs or status bars.
  - `public String toString()`: Clean formatting for components like `JComboBox`.
  - Date calculations: Use `java.time.LocalDate` and `java.time.temporal.ChronoUnit`.

```java
public abstract class Person {
    private int id;
    private String name;
    private String email;
    // Constructor, getters, setters, and abstract describe()
}
```

---

### B. DAO Layer (`com.<project>.dao`)

- **Database Class (`Database.java`)**:
  - Encapsulates connection URL: `"jdbc:sqlite:<filename>.db"`.
  - Enforces foreign keys immediately on connection: `st.execute("PRAGMA foreign_keys = ON")`.
  - `initialize()` creates all tables with `CREATE TABLE IF NOT EXISTS`, runs migrations if needed, and seeds default records.
- **Generic Interface (`GenericDAO<T>`)**:
  ```java
  public interface GenericDAO<T> {
      int insert(T entity);
      void update(T entity);
      void delete(int id);
      Optional<T> findById(int id);
      List<T> findAll();
  }
  ```
- **Prepared Statements**: **Never** concatenate user input into SQL strings. Always use `?` placeholders.
- **Resource Management**: Always use `try-with-resources` for `Connection`, `PreparedStatement`, and `ResultSet`.
- **Row Mapping**: Encapsulate `ResultSet` parsing in a private `map(ResultSet rs) throws SQLException` helper.
- **Transactional Support**: For operations that span multiple queries (e.g. issuing a loan and decrementing available book copies), provide overload methods that accept an existing `Connection c` without closing or committing it.

```java
// Example transactional DAO method
public void decrementAvailable(int id, Connection c) throws SQLException {
    String sql = "UPDATE books SET available_copies = available_copies - 1 WHERE id = ? AND available_copies > 0";
    try (PreparedStatement ps = c.prepareStatement(sql)) {
        ps.setInt(1, id);
        if (ps.executeUpdate() == 0) {
            throw new SQLException("No available copies left.");
        }
    }
}
```

---

### C. Service Layer (`com.<project>.service`)

- **Role**: Sits between Controllers and DAOs. Owns business rules, eligibility criteria, and transaction boundaries.
- **Business Constants**: Define limits as public constants (e.g. `MAX_ITEMS = 3; LOAN_PERIOD_DAYS = 14;`).
- **Transaction Pattern**: When modifying multiple tables atomically:
  ```java
  Connection c = null;
  try {
      c = Database.getConnection();
      c.setAutoCommit(false);

      // Perform DAO operations sharing connection 'c'
      daoA.insert(item, c);
      daoB.updateStock(id, c);

      c.commit();
  } catch (SQLException e) {
      if (c != null) {
          try { c.rollback(); } catch (SQLException ignored) {}
      }
      throw new RuntimeException("Operation failed: " + e.getMessage(), e);
  } finally {
      if (c != null) {
          try { c.setAutoCommit(true); c.close(); } catch (SQLException ignored) {}
      }
  }
  ```
- **Error Handling**: Throw `IllegalStateException` for business rule violations (e.g. "Member is suspended", "Max books reached").

---

### D. View Layer (`com.<project>.view`)

- **Decoupled Design**: Views do **NOT** reference Controllers or Services. Views only define Swing components and expose callback registration methods (`setOn<Action>(Runnable)`).
- **Table Handling**:
  - Make table cells non-editable by overriding `isCellEditable`:
    ```java
    private final DefaultTableModel tableModel =
        new DefaultTableModel(new Object[]{"ID", "Title", ...}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
    ```
  - Set single selection mode: `table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION)`.
- **User Feedback**: Standardize popups using `JOptionPane`:
  - `showInfo(String msg)` $\rightarrow$ `JOptionPane.INFORMATION_MESSAGE`
  - `showWarning(String msg)` $\rightarrow$ `JOptionPane.WARNING_MESSAGE`
  - `showError(String msg)` $\rightarrow$ `JOptionPane.ERROR_MESSAGE`
  - `confirmDelete(int id)` $\rightarrow$ `JOptionPane.showConfirmDialog(..., YES_NO_OPTION)`
- **Asynchronous Execution (EDT Protection)**:
  - If a dialog or component queries the database during typing (e.g., live member ID lookup), run the query inside a `SwingWorker` so the GUI doesn't freeze.
  - Track an `AtomicInteger` ticket to discard out-of-order responses from earlier keystrokes.

---

### E. Controller Layer (`com.<project>.controller`)

- **Wiring Views**: Controllers instantiate or receive Views and wire UI actions using method references:
  ```java
  view.setOnSearch(this::search);
  view.setOnAdd(this::addItem);
  view.setOnUpdate(this::updateItem);
  view.setOnDelete(this::deleteItem);
  view.setOnRefresh(this::refresh);
  ```
- **Input Validation**: Keep validation static and reusable inside the controller:
  - `requireText(String raw, String label)`: Ensures non-blank strings.
  - `parsePositiveInt(String raw, String label)`: Validates integers $> 0$.
  - `validateEmail(String email)`: Regex check (`^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$`).
- **Role-Based Access Control (RBAC)**: Check user permissions before sensitive actions:
  ```java
  if (!currentUser.isAdmin()) {
      view.showWarning("Only an Administrator can perform this action.");
      return;
  }
  ```
- **Cross-Tab Synchronization**: Use `Runnable onDataChanged` callbacks so mutating data in one tab (e.g. issuing a loan) triggers `refresh()` in related tabs (e.g. Books and Members).

---

### F. Security & Utilities (`com.<project>.util`)

- **Password Hashing (`PasswordUtil.java`)**:
  - Salted SHA-256 using `SecureRandom` (16-byte salt).
  - Stored format: `Base64(salt) + ":" + Base64(hash)`.
  - Comparison: Use constant-time array comparison (`constantTimeEquals`) to mitigate timing attacks.

---

## 4. Coding Conventions Checklist

| Item | Convention | Example |
| :--- | :--- | :--- |
| **Class Names** | PascalCase | `BookController`, `LoanDAO`, `MemberStatus` |
| **Method Names** | camelCase | `issueBook()`, `findActiveByMember()`, `map()` |
| **Constants** | UPPER_SNAKE_CASE | `MAX_BOOKS_PER_MEMBER`, `FINE_PER_DAY` |
| **Database Tables** | lowercase plural | `users`, `books`, `members`, `loans` |
| **Database Columns** | snake_case | `available_copies`, `membership_date`, `book_id` |
| **Dates** | ISO-8601 Strings | Saved as `TEXT` (`YYYY-MM-DD`), parsed via `LocalDate` |
| **Foreign Keys** | Always enforced | `PRAGMA foreign_keys = ON;` |
| **Exceptions** | Domain-specific | `IllegalStateException` for business rules, `RuntimeException` for system errors |

package com.library.service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class FineCalculator {

    public static final double FINE_PER_DAY = 0.50;

    public double calculate(LocalDate dueDate, LocalDate returnDate) {

        return 0.0;
    }
}

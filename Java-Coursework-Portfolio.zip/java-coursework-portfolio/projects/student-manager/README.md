# Student Manager CLI

Console student record application with SQLite create, read, update, and delete operations.

**Context:** Java coursework and guided learning. Original folder: `StudentManagement`.

## What the code demonstrates

Console menus, objects, and CRUD. The original implementation and learning comments are retained; the portfolio packaging is documented in [provenance](../../docs/PROVENANCE.md).

## Run

From the repository root, with Python 3 and a JDK installed:

```sh
python3 tools/portfolio.py build student-manager
python3 tools/portfolio.py run student-manager
```

Windows users can use `py` instead of `python3`. 

Database examples also require the SQLite JDBC runtime described in [setup](../../docs/RUNNING.md). Run each collection separately: several use the same class names.

## Known limitations

Menu labels and command spelling/case differ in places; malformed numeric input is not handled consistently.

## Learning notes

The useful code-reading focus here is console menus, objects, and crud. This README describes the submitted implementation; it does not claim every component was written independently. Personal reflections can be added after reviewing the source.

See [validation](../../docs/VALIDATION.md) for the exact scope of checks.

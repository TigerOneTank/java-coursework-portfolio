import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class myLibrary extends JFrame{
    private JPanel contentPane;
    private JTextField textField1;
    private JTextField textField2;
    private JComboBox<Genre> comboBox1;
    private JCheckBox checkBox1;
    private JButton CancelBtn;
    private JButton SaveBtn;
    private JLabel titleLabel;
    private JLabel AuthorLabel;
    private JLabel GenreLabel;
    Library library = new Library();


    public myLibrary() {
        setTitle("My Library");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(contentPane);
        setLocationRelativeTo(null);
        setVisible(true);
        pack();

        addItemsToGenreCombobox();


        CancelBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Clear our the inputs");
                System.out.println("System is active and ready to be transmitted!");

                cancelChanges();

            }
        });
        SaveBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Store Data in the Database");
                saveChanges();
            }
        });
    }

    public void addItemsToGenreCombobox() {
        DefaultComboBoxModel<Genre> comboModel = (DefaultComboBoxModel<Genre>) comboBox1.getModel();
        for (Genre genre: Genre.values()) {
            comboModel.addElement(genre);
        }
    }

    public void cancelChanges() {
        textField1.setText("");
        textField2.setText("");
        comboBox1.setSelectedIndex(0);
        checkBox1.setSelected(false);
    }
    public void saveChanges() {
        String title = textField1.getText();
        String author = textField2.getText();
        Genre genre = (Genre) comboBox1.getSelectedItem();
        boolean isAvailable = checkBox1.isSelected();

//        // save the chagne
//        System.out.println(title + " " + author + " " + genre + " " + isAvailable);

        Author newAuthor = new Author("", author);
        Book book = new Book(title, newAuthor, genre);
        book.setTaken(isAvailable);
        library.addBook(book);
        library.displayAllBooks();

        // clear the data
        cancelChanges();
    }



}




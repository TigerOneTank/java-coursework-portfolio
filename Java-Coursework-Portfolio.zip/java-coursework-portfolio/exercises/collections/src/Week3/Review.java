package Week3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

class Student {
    private String name;
    private String school;
    private int points;

    public Student(String name, String school, int points) {
        this.name = name;
        this.school = school;
        this.points = points;
    }

    public String getSchool() {
        return school;
    }

    public String getName() {
        return name;
    }

    public int getPoints() {
        return points;
    }

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", School='" + school + '\'' +
                ", points=" + points +
                '}';
    }
}


public class Review {
    public static void main(String[] args) {
        ArrayList<Student> examiners = new ArrayList<>();
        examiners.add(new Student("John","CIA",99));
        examiners.add(new Student("Joe","NGS",50));
        examiners.add(new Student("Sam","Western",10));

        Map<String, ArrayList<Student>> schools = new HashMap<>();

        for (Student s : examiners) {
            String school = s.getSchool();
            if (!schools.containsKey(school)) {
                schools.put(school, new ArrayList<>());
            }
            schools.get(school).add(s);
        }

        for(Map.Entry<String, ArrayList<Student>> entry : schools.entrySet()) {
            ArrayList<Student> participants = entry.getValue();
            System.out.println("School: " + entry.getKey());
            for (Student p : participants) {
                System.out.println(p.getName() + " : " + p.getPoints());
            }
            System.out.println("------------");
            System.out.println();
        }
    }


}

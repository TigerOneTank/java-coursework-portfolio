package VehicleRentalApp.view;

import VehicleRentalApp.controller.ReportController;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.sql.SQLException;

/**
 * VIEW: the shop report as a grid of cards. Every number comes from
 * ReportController -- this panel adds nothing up itself.
 */
public class ReportPanel extends JPanel {

    private final MainFrame frame;
    private final ReportController controller = new ReportController();

    private final JPanel grid = new JPanel(new GridLayout(0, 3, 14, 14));

    public ReportPanel(MainFrame frame) {
        this.frame = frame;
        setLayout(new BorderLayout(0, 14));
        setBackground(Theme.WHITE);
        setBorder(Theme.pagePadding());

        JPanel head = new JPanel(new BorderLayout(0, 4));
        head.setBackground(Theme.WHITE);
        head.add(Theme.title("Shop report"), BorderLayout.NORTH);
        head.add(Theme.subtitle(
                "Totals are recomputed from the pricing rules in the model classes, "
                        + "not stored in the database."),
                BorderLayout.SOUTH);
        add(head, BorderLayout.NORTH);

        grid.setBackground(Theme.WHITE);
        JPanel top = new JPanel(new BorderLayout());
        top.setBackground(Theme.WHITE);
        top.add(grid, BorderLayout.NORTH);
        add(Theme.scroll(top), BorderLayout.CENTER);

        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        bar.setBackground(Theme.WHITE);
        JButton reload = Theme.button("Reload");
        reload.addActionListener(e -> refresh());
        bar.add(reload);
        add(bar, BorderLayout.SOUTH);
    }

    /** One statistic: big black number, small grey caption. */
    private JPanel card(String caption, String value) {
        JPanel card = new JPanel(new BorderLayout(0, 6));
        card.setBackground(Theme.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Theme.GREY_LINE, 1),
                BorderFactory.createEmptyBorder(14, 16, 16, 16)));
        card.setPreferredSize(new Dimension(200, 92));

        JLabel head = new JLabel(caption.toUpperCase());
        head.setFont(Theme.FONT_SMALL);
        head.setForeground(Theme.GREY_MUTED);

        JLabel number = new JLabel(value);
        number.setFont(Theme.FONT_TITLE);
        number.setForeground(Theme.BLACK);

        card.add(head, BorderLayout.NORTH);
        card.add(number, BorderLayout.CENTER);
        return card;
    }

    public void refresh() {
        try {
            ReportController.ShopReport r = controller.build();

            grid.removeAll();
            grid.add(card("Total revenue", String.format("$%.2f", r.totalRevenue())));
            grid.add(card("Rentals made", String.valueOf(r.rentalCount())));
            grid.add(card("Currently out", String.valueOf(r.activeRentals())));
            grid.add(card("Loyalty discounts", String.format("$%.2f", r.totalDiscounts())));
            grid.add(card("Late fees charged", String.format("$%.2f", r.totalLateFees())));
            grid.add(card("Loyal customers", String.valueOf(r.loyalCustomers())));
            grid.add(card("Vehicles in fleet", String.valueOf(r.vehicleCount())));
            grid.add(card("Insurable vehicles", String.valueOf(r.insurableVehicles())));
            grid.add(card("Customers on file", String.valueOf(r.customerCount())));
            grid.revalidate();
            grid.repaint();

            frame.setStatus("Report updated.");
        } catch (SQLException e) {
            Dialogs.error(this, "Could not build the report.", e);
        }
    }
}

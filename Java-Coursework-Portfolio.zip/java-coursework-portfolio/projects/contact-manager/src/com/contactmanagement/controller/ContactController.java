package com.contactmanagement.controller;

import com.contactmanagement.model.Contact;
import com.contactmanagement.model.ContactDAO;
import com.contactmanagement.view.ContactFormDialog;
import com.contactmanagement.view.MainFrame;

import javax.swing.event.ListSelectionListener;
import java.sql.SQLException;

/**
 * Wires {@link MainFrame} events to {@link ContactDAO} operations. The view
 * knows nothing about SQL and the DAO knows nothing about Swing.
 */
public class ContactController {

    private final MainFrame view;
    private final ContactDAO dao;

    public ContactController(MainFrame view, ContactDAO dao) {
        this.view = view;
        this.dao = dao;
        attachListeners();
        loadContacts();
    }

    private void attachListeners() {
        view.getAddButton().addActionListener(e -> onAdd());
        view.getEditButton().addActionListener(e -> onEdit());
        view.getDeleteButton().addActionListener(e -> onDelete());
        view.getRefreshButton().addActionListener(e -> loadContacts());

        ListSelectionListener selectionListener = e -> {
            if (!e.getValueIsAdjusting()) {
                view.showImagePreview(view.getSelectedContact());
            }
        };
        view.getTable().getSelectionModel().addListSelectionListener(selectionListener);
    }

    private void loadContacts() {
        System.out.println("Loaded all contacts.");
        try {
            view.setContacts(dao.findAll());
            view.showImagePreview(null);
        } catch (SQLException e) {
            view.showError("Could not load contacts " + e.getMessage());
        }
    }

    private void onAdd() {
        ContactFormDialog dialog = new ContactFormDialog(view, "Add contact", null);
        dialog.setVisible(true);

        if (dialog.isConfirmed()) {
            try {
                Contact c = dialog.getResultContact();
                dao.insert(c);
                loadContacts();
            } catch (SQLException e) {
                view.showError("Could not save new contact" + e.getMessage());
            }
        }
    }

    private void onEdit() {
        Contact contact = view.getSelectedContact();
        if (contact == null) {
            view.showNoSelectionWarning();
            return;
        }
        ContactFormDialog dialog = new ContactFormDialog(view, "Update contact", contact);
        dialog.setVisible(true);
        if (dialog.isConfirmed()) {
            try {
                Contact c = dialog.getResultContact();
                dao.update(c);
                loadContacts();
            } catch (SQLException e) {
                view.showError("Could not update the contact" + e.getMessage());
            }
        }
    }

    private void onDelete() {
        Contact contact = view.getSelectedContact();
        if (contact == null) {
            view.showNoSelectionWarning();
            return;
        }
        if (view.confirmDelete(contact.getName())) {
            try {
                dao.delete(contact.getId());
                loadContacts();
            } catch (SQLException e) {
                view.showError("Could not delete contact. " + e.getMessage());
            }
        }
    }
}

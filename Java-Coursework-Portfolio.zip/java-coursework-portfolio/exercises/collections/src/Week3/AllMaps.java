package Week3;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class AllMaps {
    public static void main(String[] args) {
        Map<String, String> countryHashMap = new HashMap<>();
        Map<String, String> countryTreeMap = new TreeMap<>();

        countryHashMap.put("Cambodia","Kampuchea");
        countryHashMap.put("China","ZhongGuo");
        countryHashMap.put("Japan","Nippon");

        countryTreeMap.put("Cambodia","Kampuchea");
        countryTreeMap.put("China","ZhongGuo");
        countryTreeMap.put("Japan","Nippon");

        System.out.println("Country HashMap" + countryHashMap);
        System.out.println("Country HashMap" + countryTreeMap);
    }
}

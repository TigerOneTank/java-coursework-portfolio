package contactApp;


public class Main {
    public static void main(String[] args) {
        ContactManager db = new ContactManager();
        new WelcomeScreen(db);
    }
}

package com.library.model;

/** Lifecycle state of a loan. */
public enum LoanStatus {
    ACTIVE,
    RETURNED,
    OVERDUE
}

package com.contactmanagement.db;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Owns the single SQLite connection and makes sure the schema/data
 * directories exist before anything else touches the database.
 */
public final class Database {

    private static final String DATA_DIR = "data";
    private static final String IMAGES_DIR = DATA_DIR + File.separator + "images";
    private static final String DB_PATH = DATA_DIR + File.separator + "contacts.db";

    private static Connection connection;

    private Database() {
    }

    public static synchronized Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            new File(DATA_DIR).mkdirs();
            new File(IMAGES_DIR).mkdirs();
            connection = DriverManager.getConnection("jdbc:sqlite:" + DB_PATH);
            initSchema();
        }
        return connection;
    }

    public static String getImagesDir() {
        return IMAGES_DIR;
    }

    private static void initSchema() throws SQLException {
        String sql = "CREATE TABLE IF NOT EXISTS contacts (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT NOT NULL," +
                "phone TEXT," +
                "email TEXT," +
                "address TEXT," +
                "image_path TEXT" +
                ")";
        try (Statement statement = connection.createStatement()) {
            statement.execute(sql);
        }
    }
}

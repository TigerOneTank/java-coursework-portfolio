import javax.swing.*;
import java.util.Random;

public class myPasswordGenerator extends JFrame{
    private JPanel controlPanel;
    private JCheckBox includeNumbersCheckBox;
    private JCheckBox includeCharactersCheckBox;
    private JSpinner spinner1;
    private JCheckBox includeSymbolsCheckBox;
    private JProgressBar progressBar1;
    private JButton generateButton;
    private JLabel passwordLbl;

    private final String numbers = "0123456789";
    private final String characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private final String symbols = "!@#$%^&*~()_-+?";

    public myPasswordGenerator() {
        setTitle("My Password Generator");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(controlPanel);
        setLocationRelativeTo(null);
        setVisible(true);
        pack();

        includeNumbersCheckBox.setSelected(true);
        includeCharactersCheckBox.setSelected(true);
        includeSymbolsCheckBox.setSelected(true);
        progressBar1.setVisible(false);
        progressBar1.setStringPainted(true);
        SpinnerNumberModel numberModel = new SpinnerNumberModel(12,4,30,1);
        spinner1.setModel(numberModel);


        generateButton.addActionListener(e -> generateButton());
    }

    public void generateButton() {
        generateButton.setEnabled(false);
        progressBar1.setVisible(true);
        progressBar1.setValue(0);

        Timer loading = new Timer(25, null);
        loading.addActionListener(evt -> {
            int currentValue = progressBar1.getValue();
            if (currentValue < 100) {
                progressBar1.setValue(currentValue + 1);
                passwordLbl.setText("generating.....");
                // TODO: generate a random string
                StringBuilder allOptions = new StringBuilder();
                allOptions.append(numbers); allOptions.append(characters); allOptions.append(symbols);
                String randomString = getRandomString((int)spinner1.getValue(), allOptions);
                passwordLbl.setText(randomString);
            } else {
                loading.stop();
                progressBar1.setVisible(false);
                generateButton.setEnabled(true);
                passwordLbl.setText("Password is generated.");
                // TODO: generate the final password
                passwordLbl.setText(getFinalPassword());
            }
        });
        loading.start();
    }



    public String getRandomString(int length, StringBuilder allOptions) {
        Random random = new Random();

        StringBuilder pwd = new StringBuilder();
        for (int i = 0; i < length; i++) {
            pwd.append(allOptions.charAt(random.nextInt(allOptions.length())));
        }
        return pwd.toString();
    }

    public String getFinalPassword() {
        StringBuilder poll = new StringBuilder();
        if (includeNumbersCheckBox.isSelected()) poll.append(numbers);
        if (includeCharactersCheckBox.isSelected()) poll.append(characters);
        if (includeSymbolsCheckBox.isSelected()) poll.append(symbols);
        if (poll.length() == 0) return "You have to select at least one option.";
        return getRandomString((int)spinner1.getValue(), poll);
    }


}



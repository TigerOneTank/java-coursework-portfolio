package com.contactmanagement.model;

import com.contactmanagement.db.Database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Data-access layer for {@link Contact}. Talks to SQLite directly via JDBC,
 * no ORM.
 */
public class ContactDAO {

    public List<Contact> findAll() throws SQLException {
        String sql = "SELECT id, name, phone, email, address, image_path FROM contacts ORDER BY name COLLATE NOCASE";
        List<Contact> contacts = new ArrayList<>();
        try (Connection conn = Database.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                contacts.add(mapRow(rs));
            }
        }

        return contacts;
    }

    public Contact findById(int id) throws SQLException {
        String sql = "SELECT id, name, phone, email, address, image_path FROM contacts WHERE id = ?";

        return null;
    }

    public int insert(Contact contact) throws SQLException {
        String sql = "INSERT INTO contacts (name, phone, email, address, image_path) VALUES (?, ?, ?, ?, ?)";

        try (
                Connection conn = Database.getConnection();
                PreparedStatement pstmt = conn.prepareStatement(sql)
        ) {
            bindContact(pstmt, contact);
            pstmt.executeUpdate();
            try (Statement st = conn.createStatement();
                 ResultSet keys = st.executeQuery("SELECT last_insert_rowid()")) {
                if (keys.next()) {
                    return keys.getInt(1);
                }
            }
        }
        return -1;
    }

    public void update(Contact contact) throws SQLException {
        String sql = "UPDATE contacts SET name = ?, phone = ?, email = ?, address = ?, image_path = ? WHERE id = ?";
        try (Connection connection = Database.getConnection();
             PreparedStatement pstmt = connection.prepareStatement(sql)) {

            bindContact(pstmt, contact);
            pstmt.setInt(6, contact.getId());

            pstmt.executeUpdate();
        }
    }

    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM contacts WHERE id = ?";
        try (Connection connection = Database.getConnection();
             PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        }
    }

    private void bindContact(PreparedStatement statement, Contact contact) throws SQLException {
        statement.setString(1, contact.getName());
        statement.setString(2, contact.getPhone());
        statement.setString(3, contact.getEmail());
        statement.setString(4, contact.getAddress());
        statement.setString(5, contact.getImagePath());
    }

    private Contact mapRow(ResultSet resultSet) throws SQLException {
        return new Contact(
                resultSet.getInt("id"),
                resultSet.getString("name"),
                resultSet.getString("phone"),
                resultSet.getString("email"),
                resultSet.getString("address"),
                resultSet.getString("image_path")
        );
    }
}

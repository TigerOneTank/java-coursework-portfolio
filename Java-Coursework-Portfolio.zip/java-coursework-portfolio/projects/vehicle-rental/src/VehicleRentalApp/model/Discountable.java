package VehicleRentalApp.model;

/**
 * Contract signed by whoever can earn a discount. Currently only Customer,
 * but a future StudentCustomer could sign it with a different rule and
 * nothing in the controller layer would change.
 */
public interface Discountable {

    /** true once the loyalty rule has been met. */
    boolean qualifiesForDiscount();

    /** Fraction off the bill: 0.10 = 10%. Returns 0 when not yet earned. */
    double getDiscountRate();

    /** Text for the receipt, e.g. "Loyalty 10%". */
    String getDiscountLabel();
}

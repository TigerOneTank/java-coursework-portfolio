# Course Registration Form

Swing course registration exercise with course/shift choices, term cost calculation, progress feedback, and confirmation.

**Context:** Java coursework and guided learning. Original folder: `JavaGuiExam`.

## What the code demonstrates

Event listeners, timers, and form state. The original implementation and learning comments are retained; the portfolio packaging is documented in [provenance](../../docs/PROVENANCE.md).

## Run

From the repository root, with Python 3 and a JDK installed:

```sh
python3 tools/portfolio.py build course-registration
python3 tools/portfolio.py run course-registration
```

Windows users can use `py` instead of `python3`. 

Database examples also require the SQLite JDBC runtime described in [setup](../../docs/RUNNING.md). Run each collection separately: several use the same class names.

## Known limitations

Validation is incomplete and the shift radio buttons are not grouped. The form is a local demonstration; it does not register anyone for a real course.

## Learning notes

The useful code-reading focus here is event listeners, timers, and form state. This README describes the submitted implementation; it does not claim every component was written independently. Personal reflections can be added after reviewing the source.

See [validation](../../docs/VALIDATION.md) for the exact scope of checks.

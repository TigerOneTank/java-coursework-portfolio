package com.contactmanagement.view;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.UIManager;
import java.awt.Color;
import java.awt.Font;

final class UIStyle {

    static final Color BACKGROUND = Color.WHITE;
    static final Color FOREGROUND = Color.BLACK;
    static final Font BASE_FONT = new Font("SansSerif", Font.PLAIN, 13);
    static final Font BOLD_FONT = new Font("SansSerif", Font.BOLD, 13);

    private UIStyle() {
    }

    static void installGlobalDefaults() {
        UIManager.put("control", BACKGROUND);
        UIManager.put("info", BACKGROUND);
        UIManager.put("nimbusBase", BACKGROUND);
        UIManager.put("nimbusFocus", FOREGROUND);
        UIManager.put("Panel.background", BACKGROUND);
        UIManager.put("OptionPane.background", BACKGROUND);
        UIManager.put("OptionPane.messageForeground", FOREGROUND);
    }

    static void styleButton(JButton button) {
        button.setBackground(BACKGROUND);
        button.setForeground(FOREGROUND);
        button.setFont(BOLD_FONT);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createLineBorder(FOREGROUND, 1));
    }

    static void styleComponent(JComponent component) {
        component.setBackground(BACKGROUND);
        component.setForeground(FOREGROUND);
        component.setFont(BASE_FONT);
    }
}

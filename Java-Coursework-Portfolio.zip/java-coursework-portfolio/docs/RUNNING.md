# Running the collection

Use a JDK (Java Development Kit), not just a runtime. The non-JavaFX source collections compile with Java 17. Python 3 is only needed for the convenience helper; the applications themselves are Java.

From the repository root:

```sh
python3 tools/portfolio.py list
python3 tools/portfolio.py build vehicle-rental
python3 tools/portfolio.py run vehicle-rental
python3 tools/portfolio.py run collections --main Week1.WordCounter
```

On Windows, `py` can replace `python3`. The helper sets each application's working directory to its own project folder so separate databases do not collide. `.build/` contains generated classes and is ignored by Git. GUI applications need a desktop display.

## SQLite runtime

Database applications use Java's `java.sql` API, so their source can compile without the SQLite driver. To run them, put these external dependencies in a repository-root `lib/` directory:

- `org.xerial:sqlite-jdbc:3.43.2.0`
- `org.slf4j:slf4j-api:2.0.9`

These versions were included in the supplied coursework and used for the import's isolated checks; they are not a claim about current recommended versions. Obtain dependencies from their official project or Maven Central, keep their licenses, and assess updates before any wider use. Binaries are not redistributed here. Do not mix multiple versions of the same driver in `lib/`. SLF4J may report that no logging provider is installed; that warning alone does not prevent SQLite operations.

The helper adds `lib/*` to the classpath. Most apps create their schema on startup. Exceptions include the to-do app (missing initialization call) and the standalone JDBC exercises (run `CreateTable` first). See each README before running. Generated local databases are ignored; never commit real people or account data.

## Without Python

Create a list of Java source paths and compile one collection only. For example, on macOS/Linux from this repository's root:

```sh
mkdir -p .build/collections
find exercises/collections/src -name '*.java' > .build/collections-sources.txt
javac -encoding UTF-8 -d .build/collections @.build/collections-sources.txt
java -cp .build/collections Week4.BusRoute
```

Do not compile all folders into one output directory: many deliberately reuse names such as `Main`, `Book`, and `Database`.

## Form-backed Swing exercises

`exercises/swing-labs` and `references/swing-navigation` include IntelliJ GUI Designer `.form` files. Plain `javac` does not generate their bindings; compilation alone does not make these forms runnable. Open each as a separate project in an IntelliJ setup with GUI Designer support and configure form compilation. This IDE workflow has not been validated in the import environment.

## JavaFX starter

`exercises/javafx-starter/pom.xml` targets Java 24 and declares JavaFX 17.0.6. Use JDK 24 and Maven with the original configuration, then run `mvn clean javafx:run` inside that folder. This setup is retained, not certified as working. It was excluded from the Java 17 success count.

## Demo data and security

Use fictional data. Early authentication exercises contain known weaknesses; demo account passwords are classroom fixtures, not credentials for a real service. Do not reuse them. Original database files and contact photos were intentionally excluded. Missing image assets should be replaced only with images you own or may redistribute.

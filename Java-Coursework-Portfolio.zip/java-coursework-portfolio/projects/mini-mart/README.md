# Mini Mart

Swing shop prototype with product records, image storage, cashier selection, a shopping cart, and saved orders.

**Context:** Java coursework and guided learning. Original folder: `MiniMart`.

## What the code demonstrates

Swing events, JDBC, model objects, cart state, and order transactions. The original implementation and learning comments are retained; the portfolio packaging is documented in [provenance](../../docs/PROVENANCE.md).

## Run

From the repository root, with Python 3 and a JDK installed:

```sh
python3 tools/portfolio.py build mini-mart
python3 tools/portfolio.py run mini-mart
```

Windows users can use `py` instead of `python3`. 

Database examples also require the SQLite JDBC runtime described in [setup](../../docs/RUNNING.md). Run each collection separately: several use the same class names.

## Known limitations

Cart lookup always returns null and cart update is empty. Placing an order does not decrement product stock. Role/name selection is not secure authentication. Numeric input validation is incomplete.

## Learning notes

The useful code-reading focus here is swing events, jdbc, model objects, cart state, and order transactions. This README describes the submitted implementation; it does not claim every component was written independently. Personal reflections can be added after reviewing the source.

See [validation](../../docs/VALIDATION.md) for the exact scope of checks.

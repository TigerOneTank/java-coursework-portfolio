import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;


class Stock {
    String id;
    String name;
    int amount;

    public Stock(String id, String name, int amount) {
        this.id = id;
        this.name = name;
        this.amount = amount;
    }
}


public class stockManagementApp extends JFrame {

    private ArrayList<Stock> stocks = new ArrayList<>();
    private DefaultTableModel tableModel;
    private JTable table;
    private JTextField idTxt, nameTxt, amountTxt;

    public stockManagementApp() {
        setTitle("Stock Management App");
        setSize(600, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Create box components
        JPanel inputPanel = new JPanel(new GridLayout(3, 2, 5, 5));

        inputPanel.add(new JLabel("Stock ID"));
        idTxt = new JTextField();
        inputPanel.add(idTxt);

        inputPanel.add(new JLabel("Stock Name"));
        nameTxt = new JTextField();
        inputPanel.add(nameTxt);

        inputPanel.add(new JLabel("Stock Amount"));
        amountTxt = new JTextField();
        inputPanel.add(amountTxt);

        tableModel = new DefaultTableModel(new String[]{"ID", "Name", "Amount"}, 0);
        table = new JTable(tableModel);
        JScrollPane scrollpane = new JScrollPane(table);

        JPanel btnPanel = new JPanel();
        JButton addBtn = new JButton("Add");
        JButton deleteBtn = new JButton("Delete");
        JButton updateBtn = new JButton("Update");
        JButton searchBtn = new JButton("Search");

        btnPanel.add(addBtn);
        btnPanel.add(deleteBtn);
        btnPanel.add(updateBtn);
        btnPanel.add(searchBtn);

        // Add panel to window
        add(inputPanel, BorderLayout.NORTH);
        add(scrollpane, BorderLayout.CENTER);
        add(btnPanel, BorderLayout.SOUTH);

        pack();
        setVisible(true);


        table.getSelectionModel().addListSelectionListener(evt -> {
            int selectedRow = table.getSelectedRow();
            System.out.println(selectedRow);

            if (selectedRow != -1) {
                idTxt.setText(tableModel.getValueAt(selectedRow, 0).toString());
                nameTxt.setText(tableModel.getValueAt(selectedRow, 1).toString());
                amountTxt.setText(tableModel.getValueAt(selectedRow, 2).toString());

                idTxt.setEditable(false);
            }
        });


        addBtn.addActionListener(e -> {
            String id = idTxt.getText();
            String name = nameTxt.getText();
            int amount = Integer.parseInt(amountTxt.getText());

            Stock newStock = new Stock(id, name, amount);
            stocks.add(newStock);
            System.out.println("New stock is added");
            refreshTheTable();
        });
        updateBtn.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();

            if (selectedRow != -1) {
                String id = idTxt.getText();
                String name = nameTxt.getText();
                int amount = Integer.parseInt(amountTxt.getText());

                for (Stock stock : stocks) {
                    if (stock.id.equals(id)) {
                        stock.name = name;
                        stock.amount = amount;
                        break;
                    }
                }
                refreshTheTable();
                idTxt.setEditable(true);
                JOptionPane.showMessageDialog(this, "Row is updated");
            } else {
                JOptionPane.showMessageDialog(this, "Please select a row");
            }
        });
        deleteBtn.addActionListener(e -> {
            stocks.removeIf(stock -> stock.id.equals(idTxt.getText()));
            JOptionPane.showMessageDialog(this, "Row is deleted.");
            refreshTheTable();
        });
    }

    public void refreshTheTable() {
        tableModel.setRowCount(0);
        for (Stock stock: stocks) {
            tableModel.addRow(new Object[]{stock.id,stock.name, stock.amount});
        }
    }


    public static void main (String[] args) {
        new stockManagementApp();
    }
}

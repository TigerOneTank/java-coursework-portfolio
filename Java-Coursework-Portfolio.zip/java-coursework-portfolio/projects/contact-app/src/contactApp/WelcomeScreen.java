package contactApp;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class WelcomeScreen extends JFrame {
    private final ContactManager db;
    // ── Sign In widgets ───────────────────────────────────────────────────────
    private JTextField     tfSignInUser;
    private JPasswordField pfSignInPass;
    private JLabel         lblSignInMsg;

    // ── Sign Up widgets ───────────────────────────────────────────────────────
    private JTextField     tfSignUpUser;
    private JPasswordField pfSignUpPass;
    private JPasswordField pfSignUpConfirm;
    private JLabel         lblSignUpMsg;

    // ─────────────────────────────────────────────────────────────────────────
    public WelcomeScreen(ContactManager db) {
        this.db = db;
        setTitle("Contact App — Welcome");
        setSize(400, 520);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        initUI();
        setVisible(true);
    }

    private void initUI() {
        JPanel root = new JPanel(new BorderLayout(0, 10));
        root.setBorder(new EmptyBorder(14, 14, 14, 14));
        root.add(buildHeader(), BorderLayout.NORTH);
        root.add(buildForms(),  BorderLayout.CENTER);
        setContentPane(root);
    }

    private JPanel buildHeader() {
        JPanel panel = new JPanel(new GridLayout(2, 1, 0, 2));
        JLabel title = new JLabel("Contact App");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 18f));
        panel.add(title);
        panel.add(new JLabel("Please sign in or create an account to continue."));
        return panel;
    }

    private JPanel buildForms() {
        JPanel panel = new JPanel(new GridLayout(2, 1, 0, 12));
        panel.add(buildSignInPanel());
        panel.add(buildSignUpPanel());
        return panel;
    }

    // ── Sign In ───────────────────────────────────────────────────────────────
    private JPanel buildSignInPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Sign In"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 6, 4, 6);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0; gbc.gridy = 0; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        panel.add(new JLabel("Username:"), gbc);
        tfSignInUser = new JTextField(18);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1;
        panel.add(tfSignInUser, gbc);

        gbc.gridx = 0; gbc.gridy = 1; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        panel.add(new JLabel("Password:"), gbc);
        pfSignInPass = new JPasswordField(18);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1;
        panel.add(pfSignInPass, gbc);

        JButton btnSignIn = new JButton("Sign In");
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.NONE; gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(8, 6, 2, 6);
        panel.add(btnSignIn, gbc);

        lblSignInMsg = new JLabel(" ");
        lblSignInMsg.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridy = 3;
        gbc.insets = new Insets(2, 6, 4, 6);
        panel.add(lblSignInMsg, gbc);

        // TODO1: add even to sign in button
        btnSignIn.addActionListener(e -> handleSignIn());
        return panel;


    }

    // ── Sign Up ───────────────────────────────────────────────────────────────
    private JPanel buildSignUpPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Sign Up"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 6, 4, 6);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0; gbc.gridy = 0; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        panel.add(new JLabel("Username:"), gbc);
        tfSignUpUser = new JTextField(18);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1;
        panel.add(tfSignUpUser, gbc);

        gbc.gridx = 0; gbc.gridy = 1; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        panel.add(new JLabel("Password:"), gbc);
        pfSignUpPass = new JPasswordField(18);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1;
        panel.add(pfSignUpPass, gbc);

        gbc.gridx = 0; gbc.gridy = 2; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        panel.add(new JLabel("Confirm:"), gbc);
        pfSignUpConfirm = new JPasswordField(18);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1;
        panel.add(pfSignUpConfirm, gbc);

        JButton btnSignUp = new JButton("Sign Up");
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.NONE; gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(8, 6, 2, 6);
        panel.add(btnSignUp, gbc);

        lblSignUpMsg = new JLabel(" ");
        lblSignUpMsg.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridy = 4;
        gbc.insets = new Insets(2, 6, 4, 6);
        panel.add(lblSignUpMsg, gbc);

        // TODO: add event to sign up button
        btnSignUp.addActionListener(e -> handleSignUp());

        return panel;
    }

    public void handleSignUp() {
        System.out.println("Handle sign up");
        String username = tfSignUpUser.getText();
        String password = new String(pfSignUpPass.getPassword());

        int newId = db.signUp(username, password);
        if (newId != -1) {
            lblSignUpMsg.setText("Account is created. you can now sign in.");
            tfSignUpUser.setText("");
            pfSignUpPass.setText("");
            pfSignUpConfirm.setText("");
        } else {
            lblSignUpMsg.setText("User may already exist.");
        }

    }

    private void handleSignIn() {
        String username = tfSignInUser.getText();
        String password = new String(pfSignInPass.getPassword());

        if (username.isEmpty() || password.isEmpty()) {
            lblSignInMsg.setText("Please enter your username and password.");
            return;
        }

        int userId = db.signIn(username, password);
        if (userId != -1) {
            System.out.println("Sign in successful");
            dispose();
            new ContactAppDemo(db,userId,username);
        } else {
            lblSignInMsg.setText("Invalid username or password.");
        }

    }
}


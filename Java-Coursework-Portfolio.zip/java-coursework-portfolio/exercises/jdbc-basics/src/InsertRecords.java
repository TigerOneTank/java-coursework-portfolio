import java.sql.DriverManager;
import java.sql.SQLException;


public class InsertRecords {
    public static void main(String[] args) {
        String url = "jdbc:sqlite:java_db.db";

        String sql = "INSERT INTO products(name, amount, price) VALUES (?, ?, ?)";

        try (var conn = DriverManager.getConnection(url)) {

            var statement = conn.prepareStatement(sql);
            statement.setString(1, "iphone 15 pro max");
            statement.setInt(2, 200);
            statement.setDouble(3, 1199.99);
            statement.executeUpdate();
            System.out.println("New Record is Added");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}

package VehicleRentalApp.view;

import VehicleRentalApp.controller.RentalController;
import VehicleRentalApp.controller.VehicleController;
import VehicleRentalApp.model.Rental;
import VehicleRentalApp.model.Vehicle;
import VehicleRentalApp.model.VehicleNotAvailableException;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.sql.SQLException;
import java.util.List;

/**
 * VIEW: the till. Rent a vehicle on the left, see the history and take
 * returns on the right.
 *
 * Everything this panel knows about pricing it learned by asking a Rental
 * object; it never adds up a bill itself.
 */
public class RentalPanel extends JPanel {

    private final MainFrame frame;
    private final RentalController rentalController = new RentalController();
    private final VehicleController vehicleController = new VehicleController();

    private final JComboBox<Vehicle> vehicleBox = new JComboBox<>();
    private final JTextField customerField = Theme.textField(16);
    private final JTextField daysField = Theme.textField(6);
    private final JTextArea receiptArea = new JTextArea(12, 34);

    private final String[] columns =
            {"Rental", "Customer", "Vehicle", "Booked", "Kept", "Total", "Status"};
    private final DefaultTableModel model = new DefaultTableModel(columns, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    private final JTable table = Theme.table(model);

    public RentalPanel(MainFrame frame) {
        this.frame = frame;
        setLayout(new BorderLayout(0, 14));
        setBackground(Theme.WHITE);
        setBorder(Theme.pagePadding());

        JPanel head = new JPanel(new BorderLayout(0, 4));
        head.setBackground(Theme.WHITE);
        head.add(Theme.title("Rentals"), BorderLayout.NORTH);
        head.add(Theme.subtitle(
                "Only available vehicles appear in the list. Select a rental to return it."),
                BorderLayout.SOUTH);
        add(head, BorderLayout.NORTH);

        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
                buildLeft(), buildRight());
        split.setBorder(BorderFactory.createEmptyBorder());
        split.setDividerLocation(360);
        split.setDividerSize(14);
        split.setBackground(Theme.WHITE);
        add(split, BorderLayout.CENTER);
    }

    private JPanel buildLeft() {
        JPanel form = new JPanel();
        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));
        form.setBackground(Theme.WHITE);
        form.setBorder(Theme.groupBorder("New rental"));

        form.add(row("Vehicle", vehicleBox));
        form.add(Box.createVerticalStrut(8));
        form.add(row("Customer", customerField));
        form.add(Box.createVerticalStrut(8));
        form.add(row("Days", daysField));
        form.add(Box.createVerticalStrut(12));

        JButton rent = Theme.primaryButton("Rent vehicle");
        rent.addActionListener(e -> rent());
        JPanel action = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        action.setBackground(Theme.WHITE);
        action.add(rent);
        action.setAlignmentX(LEFT_ALIGNMENT);
        form.add(action);
        form.add(Box.createVerticalStrut(14));

        receiptArea.setEditable(false);
        receiptArea.setFont(Theme.FONT_MONO);
        receiptArea.setForeground(Theme.BLACK);
        receiptArea.setBackground(Theme.WHITE);
        receiptArea.setText("The receipt for the last rental\nor return appears here.");
        receiptArea.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));
        var receiptScroll = Theme.scroll(receiptArea);
        receiptScroll.setAlignmentX(LEFT_ALIGNMENT);
        receiptScroll.setPreferredSize(new Dimension(320, 260));
        form.add(receiptScroll);

        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setBackground(Theme.WHITE);
        wrapper.add(form, BorderLayout.CENTER);
        return wrapper;
    }

    private JPanel row(String labelText, java.awt.Component field) {
        JPanel r = new JPanel(new BorderLayout(10, 0));
        r.setBackground(Theme.WHITE);
        r.setAlignmentX(LEFT_ALIGNMENT);
        r.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        var label = Theme.label(labelText);
        label.setPreferredSize(new Dimension(72, 26));
        r.add(label, BorderLayout.WEST);
        r.add(field, BorderLayout.CENTER);
        return r;
    }

    private JPanel buildRight() {
        JPanel right = new JPanel(new BorderLayout(0, 10));
        right.setBackground(Theme.WHITE);
        right.add(Theme.scroll(table), BorderLayout.CENTER);

        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        bar.setBackground(Theme.WHITE);
        JButton ret = Theme.primaryButton("Return selected");
        JButton receipt = Theme.button("Show receipt");
        JButton reload = Theme.button("Reload");
        ret.addActionListener(e -> returnSelected());
        receipt.addActionListener(e -> showReceipt());
        reload.addActionListener(e -> refresh());
        bar.add(ret);
        bar.add(receipt);
        bar.add(reload);
        right.add(bar, BorderLayout.SOUTH);
        return right;
    }

    // ---- actions ----------------------------------------------------------

    private void rent() {
        Vehicle selected = (Vehicle) vehicleBox.getSelectedItem();
        if (selected == null) {
            Dialogs.warn(this, "There are no available vehicles to rent.");
            return;
        }
        String customer = customerField.getText().trim();
        String daysText = daysField.getText().trim();

        try {
            int days = Integer.parseInt(daysText);
            Rental r = rentalController.rentVehicle(selected.getId(), customer, days);

            receiptArea.setText(r.toReceipt());
            receiptArea.setCaretPosition(0);
            customerField.setText("");
            daysField.setText("");
            frame.refreshAll();
            frame.setStatus(String.format("%s rented %s for %d day(s) - total $%.2f",
                    r.getCustomerName(), selected.getId(), days, r.getTotalCost()));

        } catch (NumberFormatException e) {
            Dialogs.warn(this, "'" + daysText + "' is not a whole number of days.");
        } catch (VehicleNotAvailableException e) {
            // the checked exception the compiler forced us to handle
            Dialogs.warn(this, "Sorry -- " + e.getMessage()
                    + "\nUse 'Available only' on the Vehicles tab to see what is free.");
            refresh();
        } catch (IllegalArgumentException e) {
            Dialogs.warn(this, e.getMessage());
        } catch (SQLException e) {
            Dialogs.error(this, "The rental could not be saved. Nothing was changed.", e);
        }
    }

    private void returnSelected() {
        String rentalId = selectedRentalId();
        if (rentalId == null) {
            Dialogs.warn(this, "Select a rental in the table first.");
            return;
        }
        try {
            Rental r = rentalController.find(rentalId);
            if (r == null) {
                Dialogs.warn(this, "Rental not found: " + rentalId);
                return;
            }
            if (r.isReturned()) {
                Dialogs.warn(this, rentalId + " has already been returned.");
                return;
            }

            String answer = javax.swing.JOptionPane.showInputDialog(this,
                    "Days actually kept (booked " + r.getDays() + "):",
                    String.valueOf(r.getDays()));
            if (answer == null) {
                return;   // cancelled
            }
            int actualDays;
            try {
                actualDays = Integer.parseInt(answer.trim());
            } catch (NumberFormatException e) {
                Dialogs.warn(this, "Not a number -- nothing was returned.");
                return;
            }

            Rental updated = rentalController.returnVehicle(rentalId, actualDays);
            if (updated == null) {
                Dialogs.warn(this, "That rental could not be returned.");
                return;
            }

            receiptArea.setText(updated.toReceipt());
            receiptArea.setCaretPosition(0);
            frame.refreshAll();
            if (updated.getExtraDays() > 0) {
                frame.setStatus(String.format("%s returned %d day(s) late - penalty $%.2f",
                        rentalId, updated.getExtraDays(), updated.getLateFee()));
            } else {
                frame.setStatus(rentalId + " returned on time. Thank you!");
            }

        } catch (SQLException e) {
            Dialogs.error(this, "The return could not be saved. Nothing was changed.", e);
        }
    }

    private void showReceipt() {
        String rentalId = selectedRentalId();
        if (rentalId == null) {
            Dialogs.warn(this, "Select a rental in the table first.");
            return;
        }
        try {
            Rental r = rentalController.find(rentalId);
            if (r != null) {
                receiptArea.setText(r.toReceipt());
                receiptArea.setCaretPosition(0);
            }
        } catch (SQLException e) {
            Dialogs.error(this, "Could not read that rental.", e);
        }
    }

    private String selectedRentalId() {
        int row = table.getSelectedRow();
        if (row < 0) {
            return null;
        }
        return (String) model.getValueAt(table.convertRowIndexToModel(row), 0);
    }

    /** Reload both the combo box and the history table from the database. */
    public void refresh() {
        try {
            Vehicle previous = (Vehicle) vehicleBox.getSelectedItem();
            vehicleBox.removeAllItems();
            for (Vehicle v : vehicleController.listAvailable()) {
                vehicleBox.addItem(v);
                if (previous != null && previous.getId().equals(v.getId())) {
                    vehicleBox.setSelectedItem(v);
                }
            }

            List<Rental> rentals = rentalController.listAll();
            model.setRowCount(0);
            for (Rental r : rentals) {
                model.addRow(new Object[]{
                        r.getRentalId(),
                        r.getCustomerName(),
                        r.getVehicle().getId() + " " + r.getVehicle().getType(),
                        r.getDays() + "d",
                        r.isReturned() ? r.getActualDays() + "d" : "-",
                        String.format("$%.2f", r.getTotalCost()),
                        r.isReturned()
                                ? (r.getExtraDays() > 0 ? "Returned late" : "Returned")
                                : "Out"
                });
            }
        } catch (SQLException e) {
            Dialogs.error(this, "Could not read the rentals table.", e);
        }
    }
}

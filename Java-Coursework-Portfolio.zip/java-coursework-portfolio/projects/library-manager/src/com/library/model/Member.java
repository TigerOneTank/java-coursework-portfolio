package com.library.model;

import java.time.LocalDate;

/** A library member who can borrow books. Extends Person. */
public class Member extends Person {
    private LocalDate membershipDate;
    private MemberStatus status;
    private int borrowedCount; // number of books currently on loan

    public Member(int id, String name, String email,
                  LocalDate membershipDate, MemberStatus status, int borrowedCount) {
        super(id, name, email);
        this.membershipDate = membershipDate;
        this.status = status;
        this.borrowedCount = borrowedCount;
    }

    public LocalDate getMembershipDate() { return membershipDate; }
    public void setMembershipDate(LocalDate membershipDate) { this.membershipDate = membershipDate; }

    public MemberStatus getStatus() { return status; }
    public void setStatus(MemberStatus status) { this.status = status; }

    public int getBorrowedCount() { return borrowedCount; }
    public void setBorrowedCount(int borrowedCount) { this.borrowedCount = borrowedCount; }

    public boolean isActive() { return status == MemberStatus.ACTIVE; }

    @Override
    public String describe() {
        return "Member #" + getId() + " " + getName() + " (" + status + ")";
    }

    /** Shown in combo boxes. */
    @Override
    public String toString() {
        return getName() + " (#" + getId() + ")";
    }
}

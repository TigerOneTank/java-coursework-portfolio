package com.library.dao;

import java.util.List;
import java.util.Optional;

public interface GenericDAO<T> {
    int insert(T entity);
    void update(T entity);
    void delete(int id);
    Optional<T> findById(int id);
    List<T> findAll();
}

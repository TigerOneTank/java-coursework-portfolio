package com.library.dao;

import com.library.util.PasswordUtil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public final class Database {

    private static final String URL = "jdbc:sqlite:library.db";

    private Database() { }

    public static Connection getConnection() throws SQLException {
        Connection conn = DriverManager.getConnection(URL);
        try (Statement st = conn.createStatement()) {
            st.execute("PRAGMA foreign_keys = ON");
        }
        return conn;
    }

    public static void initialize() {
        try (Connection conn = getConnection();
             Statement st = conn.createStatement()) {

            st.execute(
                "CREATE TABLE IF NOT EXISTS users (" +
                "  id            INTEGER PRIMARY KEY AUTOINCREMENT," +
                "  name          TEXT NOT NULL," +
                "  email         TEXT," +
                "  username      TEXT NOT NULL UNIQUE," +
                "  password_hash TEXT NOT NULL," +
                "  role          TEXT NOT NULL CHECK (role IN ('LIBRARIAN','ADMIN'))" +
                ")");

            st.execute(
                "CREATE TABLE IF NOT EXISTS members (" +
                "  id              INTEGER PRIMARY KEY AUTOINCREMENT," +
                "  name            TEXT NOT NULL," +
                "  email           TEXT UNIQUE," +
                "  phone           TEXT," +
                "  membership_date TEXT NOT NULL," +
                "  status          TEXT NOT NULL DEFAULT 'ACTIVE'" +
                "                  CHECK (status IN ('ACTIVE','SUSPENDED'))" +
                ")");

            st.execute(
                "CREATE TABLE IF NOT EXISTS books (" +
                "  id               INTEGER PRIMARY KEY AUTOINCREMENT," +
                "  title            TEXT NOT NULL," +
                "  author           TEXT NOT NULL," +
                "  isbn             TEXT UNIQUE," +
                "  category         TEXT," +
                "  total_copies     INTEGER NOT NULL DEFAULT 1," +
                "  available_copies INTEGER NOT NULL DEFAULT 1" +
                ")");

            st.execute(
                "CREATE TABLE IF NOT EXISTS loans (" +
                "  id          INTEGER PRIMARY KEY AUTOINCREMENT," +
                "  book_id     INTEGER," +
                "  member_id   INTEGER," +
                "  issue_date  TEXT NOT NULL," +
                "  due_date    TEXT NOT NULL," +
                "  return_date TEXT," +
                "  fine        REAL NOT NULL DEFAULT 0," +
                "  status      TEXT NOT NULL DEFAULT 'ACTIVE'" +
                "              CHECK (status IN ('ACTIVE','RETURNED','OVERDUE'))," +
                "  FOREIGN KEY (book_id)   REFERENCES books(id)   ON DELETE SET NULL," +
                "  FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE SET NULL" +
                ")");

            if (loansTableNeedsMigration(conn)) {
                migrateLoansTableToNullableForeignKeys(conn);
            }

            seedIfEmpty(conn);

        } catch (SQLException e) {
            throw new RuntimeException("Database initialization failed", e);
        }
    }

    private static boolean loansTableNeedsMigration(Connection conn) throws SQLException {
        try (Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery("PRAGMA table_info(loans)")) {
            while (rs.next()) {
                if ("book_id".equals(rs.getString("name"))) {
                    return rs.getInt("notnull") == 1;
                }
            }
        }
        return false;
    }

    private static void migrateLoansTableToNullableForeignKeys(Connection conn) throws SQLException {
        try (Statement st = conn.createStatement()) {
            st.execute("PRAGMA foreign_keys = OFF");
            st.execute("BEGIN TRANSACTION");
            st.execute(
                "CREATE TABLE loans_new (" +
                "  id          INTEGER PRIMARY KEY AUTOINCREMENT," +
                "  book_id     INTEGER," +
                "  member_id   INTEGER," +
                "  issue_date  TEXT NOT NULL," +
                "  due_date    TEXT NOT NULL," +
                "  return_date TEXT," +
                "  fine        REAL NOT NULL DEFAULT 0," +
                "  status      TEXT NOT NULL DEFAULT 'ACTIVE'" +
                "              CHECK (status IN ('ACTIVE','RETURNED','OVERDUE'))," +
                "  FOREIGN KEY (book_id)   REFERENCES books(id)   ON DELETE SET NULL," +
                "  FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE SET NULL" +
                ")");
            st.execute(
                "INSERT INTO loans_new (id, book_id, member_id, issue_date, due_date, return_date, fine, status) " +
                "SELECT id, book_id, member_id, issue_date, due_date, return_date, fine, status FROM loans");
            st.execute("DROP TABLE loans");
            st.execute("ALTER TABLE loans_new RENAME TO loans");
            st.execute("COMMIT");
        } catch (SQLException e) {
            try (Statement rollback = conn.createStatement()) {
                rollback.execute("ROLLBACK");
            } catch (SQLException ignored) { }
            throw e;
        } finally {
            try (Statement st = conn.createStatement()) {
                st.execute("PRAGMA foreign_keys = ON");
            } catch (SQLException ignored) { }
        }
    }

    private static void seedIfEmpty(Connection conn) throws SQLException {
        if (count(conn, "users") == 0) {
            String adminPw = PasswordUtil.hash("admin123");
            String libPw = PasswordUtil.hash("lib123");
            try (Statement st = conn.createStatement()) {
                st.execute("INSERT INTO users(name,email,username,password_hash,role) VALUES " +
                        "('Administrator','demo1@example.com','admin','" + adminPw + "','ADMIN')");
                st.execute("INSERT INTO users(name,email,username,password_hash,role) VALUES " +
                        "('Librarian One','demo3@example.com','lib1','" + libPw + "','LIBRARIAN')");
            }
        }

        if (count(conn, "members") == 0) {
            try (Statement st = conn.createStatement()) {
                st.execute("INSERT INTO members(name,email,phone,membership_date,status) VALUES " +
                        "('Demo Member 1','member1@example.com','','2026-07-01','ACTIVE')");
                st.execute("INSERT INTO members(name,email,phone,membership_date,status) VALUES " +
                        "('Demo Member 2','member2@example.com','','2026-07-05','ACTIVE')");
                st.execute("INSERT INTO members(name,email,phone,membership_date,status) VALUES " +
                        "('Demo Member 3','member3@example.com','','2026-06-05','ACTIVE')");
            }
        }

        if (count(conn, "books") == 0) {
            try (Statement st = conn.createStatement()) {
                st.execute("INSERT INTO books(title,author,isbn,category,total_copies,available_copies) VALUES " +
                        "('Clean Code','Robert C. Martin','978-0132350884','Programming',3,3)");
                st.execute("INSERT INTO books(title,author,isbn,category,total_copies,available_copies) VALUES " +
                        "('Effective Java','Joshua Bloch','978-0134685991','Programming',2,2)");
                st.execute("INSERT INTO books(title,author,isbn,category,total_copies,available_copies) VALUES " +
                        "('Head First Java','Kathy Sierra','978-0596009205','Programming',4,4)");
            }
        }
    }

    private static int count(Connection conn, String table) throws SQLException {
        try (Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM " + table)) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }
}

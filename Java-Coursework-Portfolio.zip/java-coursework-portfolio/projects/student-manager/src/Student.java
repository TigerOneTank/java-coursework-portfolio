

public class Student {
    private String id;
    private String fullname;
    private int age;
    private int grade;


    public Student(String id, String fullname, int age, int grade) {
        this.id = id;
        this.fullname = fullname;
        this.age = age;
        this.grade = grade;
    }

    public String getId() {
        return id;
    }

    public String getFullname() {
        return fullname;
    }

    public int getAge() {
        return age;
    }

    public int getGrade() {
        return grade;
    }

    @Override
    public String toString() {
        return "Student{" +
                "id='" + id + '\'' +
                ", fullname='" + fullname + '\'' +
                ", age=" + age +
                ", grade=" + grade +
                '}';
    }


}
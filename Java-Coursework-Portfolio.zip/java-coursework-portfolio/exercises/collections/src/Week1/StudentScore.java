package Week1;

import java.util.HashMap;
import java.util.Map;

public class StudentScore {
    public static void main(String[] args) {
        Map<String, Double> scores = new HashMap<>();
        scores.put("Math", 95.5);
        scores.put("Physics", 99.9);
        scores.put("English", 100.0);
        scores.put("Coding", 95.0);
        // Get only keys: map.keySet()
        System.out.println("Display all subjects");
        for (String subject : scores.keySet()) {
            System.out.println(subject);
        }

//        System.out.println("Display All Values");
//        for (Double totalScores: scores.values()) {
//            System.out.println(totalScores);
//        }

        double total = 0.0;
        for (Double score : scores.values()) {
            total += score;
        }
        System.out.println("Total Scores is: " + total);

        System.out.println("Results");
        for (Map.Entry<String, Double> entry: scores.entrySet()) {
            System.out.println(entry.getKey() + " " + entry.getValue());
        }
    }
}

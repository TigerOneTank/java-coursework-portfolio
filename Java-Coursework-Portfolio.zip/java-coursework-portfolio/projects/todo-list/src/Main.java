import java.sql.SQLException;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) throws SQLException {

        System.out.println("Welcome to my TODO APP");
        TodoDB.getConnection();

        String command = "";
        while (!command.equals("exit")) {
            displayMenu();
            command = Console.getString("Enter your command: ");

            switch (command) {
                case "list" -> displayAllTodos();
                case "add" -> addNewTodo();
                case "mark" -> markTodo();
                case "delete" -> deleteATodo();
                case "exit" -> System.out.println("Bye bye!!");
                default -> System.out.println("Invalid command.");
            }

        }
    }

    public static void displayMenu() {
        System.out.println("MY TODO APP");
        System.out.println("- list: list all todos");
        System.out.println("- add: add a new todo");
        System.out.println("- mark: mark a todo");
        System.out.println("- delete: delete a todo");
        System.out.println("- exit: exit the program");
    }

    public static void displayAllTodos() {
        System.out.println("Here is your todo list.");
        ArrayList<Todo> todos = TodoDB.getAllTodos();
        System.out.printf("|%4s|%16s|%20s|%10s|\n", "ID", "ITEM", "DESCRIPTION", "DONE");
        for (Todo todo : todos) {
            int id = todo.getId();
            String item = todo.getName();
            String description = todo.getDescription();
            String done = todo.getDone() ? "YES" : "NO";
            System.out.printf("|%4d|%16s|%20s|%10s|\n", id, item, description, done);
        }
        System.out.println("----------------------------------------------------------");
        System.out.println();
    }

    public static void addNewTodo(){
        System.out.println("Add a new Todo.");
        int id = Console.getInt("Enter the id: ");
        String name = Console.getString("Enter the item: ");
        String description = Console.getString("Enter the description: ");
        Todo newTodo = new Todo(id, name, description, false);
        TodoDB.addTodo(newTodo);
        System.out.println("New Todo has been added!");
    }

    public static void markTodo() {
        System.out.println("Mark a Todo");
        int id = Console.getInt("Enter the id: ");
        Todo todo = TodoDB.getOneTodo(id);
        if (todo != null) {
            todo.setDone(true);
            TodoDB.updateTodo(todo);
            System.out.println("Todo has been marked");
        } else {
            System.out.println("Todo does not exist.");
        }
    }

    public static void deleteATodo() {
        System.out.println("Delete a Todo");
        int id = Console.getInt("Enter the id of the todo: ");
        Todo todo = TodoDB.getOneTodo(id);
        if (todo != null ) {
            TodoDB.deleteTodo(id);
            System.out.println("ToDo has been deleted");
        } else {
            System.out.println("Todo does not exist");
        }
    }

}
package Week2;

import java.util.HashMap;
import java.util.Map;

class Product {
    private String code;
    private String name;
    private int stock;
    private double price;

    public Product(String name, String code, int stock, double price) {
        this.name = name;
        this.code = code;
        this.stock = stock;
        this.price = price;
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public int getStock() {
        return stock;
    }

    public double getPrice() {
        return price;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public double stockValue() {
        return stock * price;
    }

    @Override
    public String toString() {
        return "Product{" +
                "code='" + code + '\'' +
                ", name='" + name + '\'' +
                ", stock=" + stock +
                ", price=" + price +
                '}';
    }
}




public class shopInventory {
    public static void main(String[] args) {
        Map<String, Product> inventory = new HashMap<>();
        addProduct(inventory, new Product("P001","Notebook",100,1.25));
        addProduct(inventory, new Product("P002","Pencil",50,0.25));
        addProduct(inventory, new Product("P003","Desk",20,12.5));

//        Sell the product
        sellProduct(inventory, "Notebook",5);
        sellProduct(inventory, "Chair",5);
        sellProduct(inventory, "Desk",100);

    }

    static void addProduct(Map<String, Product> inventory, Product product ){
        inventory.put(product.getCode(), product);
    }

    static void sellProduct(Map<String, Product> inventory, String code, int qty) {
        Product product = inventory.get(code);
        if (product == null) {
            System.out.println("No Product with Code " + code +"\n" );
            return;
        }
        if (qty > product.getStock()) {
            System.out.println("There are only " + product.getStock() + " in our stock");
            System.out.println("Sorry, we don't have enough stock! \n");
            return;
        }

        product.setStock(product.getStock() - qty);
        double subTotal = product.getPrice() * qty;
        System.out.println("Subtotal of the product " + code + " is  $" + subTotal);
        System.out.println("Remained " + product.getStock() + " in our stock");
        System.out.println();
    }
}

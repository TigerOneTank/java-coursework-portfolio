import javax.swing.*;

public class SecondScreen extends JFrame{
    private JPanel contentPanel;
    private JTextField usernameTextField;
    private JTextField passwordTextField;
    private JLabel usernameLable;
    private JLabel passwordLable;
    private JButton CancelBtn;
    private JButton LoginBtn;

    public SecondScreen() {
        setContentPane(contentPanel);
        setTitle("MainScreen");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(400,200);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
